@echo off
rem Opens the panel in Edge (Chrome also works). No server needed.
start "" msedge "%~dp0public\index.html" || start "" chrome "%~dp0public\index.html"
