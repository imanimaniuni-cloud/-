// لایه‌ی داده: SQLite (sql.js) روی پوشه‌ی اشتراکی + کاربران + ذخیره‌ی فایل‌ها (بدون سرور)
(function(){
const enc=new TextEncoder(),hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join(''),rnd=()=>hex(crypto.getRandomValues(new Uint8Array(16)));
async function hash(pw,salt){const k=await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveBits']);
 return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(salt),iterations:100000},k,256))}
const idb=()=>new Promise((ok,no)=>{const r=indexedDB.open('em',1);r.onupgradeneeded=()=>r.result.createObjectStore('h');r.onsuccess=()=>ok(r.result);r.onerror=no});
const hget=async()=>{const d=await idb();return new Promise(ok=>{const r=d.transaction('h').objectStore('h').get('dir');r.onsuccess=()=>ok(r.result)})};
const hset=async h=>{const d=await idb();return new Promise(ok=>{const t=d.transaction('h','readwrite');t.objectStore('h').put(h,'dir');t.oncomplete=ok})};
let dir=null,SQL=null;
async function nav(path,create){const p=path.split('/'),f=p.pop();let d=dir;for(const x of p)d=await d.getDirectoryHandle(x,{create});return[d,f]}
async function rd(path){try{const[d,f]=await nav(path);return await(await d.getFileHandle(f)).getFile()}catch(e){return null}}
async function wr(path,data){const[d,f]=await nav(path,true);const w=await(await d.getFileHandle(f,{create:true})).createWritable();await w.write(data);await w.close()}
async function rm(path){try{const[d,f]=await nav(path);await d.removeEntry(f)}catch(e){}}
async function connect(mode){ // 'silent' | 'ask' | 'pick'
 let h=null;try{h=await hget()}catch(e){}
 if(mode==='pick'||(!h&&mode==='ask')){h=await showDirectoryPicker({mode:'readwrite'});try{await hset(h)}catch(e){}}
 if(!h)return false;const o={mode:'readwrite'};
 if(await h.queryPermission(o)!=='granted'){if(mode==='silent')return 'perm';if(await h.requestPermission(o)!=='granted')return false}
 dir=h;if(!SQL)SQL=await initSqlJs({wasmBinary:Uint8Array.from(atob(window.SQLJS_B64),c=>c.charCodeAt(0))});
 if(!await rd('data/data.sqlite'))await tx(()=>{});return true}
async function open(){const f=await rd('data/data.sqlite'),db=f?new SQL.Database(new Uint8Array(await f.arrayBuffer())):new SQL.Database();
 db.run(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,name TEXT,salt TEXT,hash TEXT,role TEXT,perms TEXT,active INT DEFAULT 1,must INT DEFAULT 0);
 CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY,orig TEXT,stored TEXT,size INT,uploader TEXT,ts TEXT,kind TEXT,src TEXT)`);
 const cols=rows(db,'PRAGMA table_info(files)').map(c=>c.name);
 if(!cols.includes('cat'))db.run("ALTER TABLE files ADD COLUMN cat TEXT DEFAULT 'daily'");
 if(!cols.includes('srcids'))db.run("ALTER TABLE files ADD COLUMN srcids TEXT DEFAULT ''");
 const uc=rows(db,'PRAGMA table_info(users)').map(c=>c.name);
 if(!uc.includes('email'))db.run("ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''");
 db.run('CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)');
 if(!db.exec('SELECT 1 FROM users LIMIT 1').length)db.run("INSERT INTO users(username,name,salt,hash,role,perms,active,must) VALUES('admin','مدیر سیستم',?,?,'admin','merge,files,viewall,delete',1,1)",['96684034650836f5ed437f915efa8db8','f75987d35a137e63e699d5312d0855167bc4a66a5389045f913eaa6466ae46a9']);
 return db}
function rows(db,sql,p=[]){const s=db.prepare(sql);s.bind(p);const o=[];while(s.step())o.push(s.getAsObject());s.free();return o}
async function q(sql,p){const db=await open();try{return rows(db,sql,p)}finally{db.close()}}
// نوشتن: ابتدا صف داخلی (هر نوشتن بعد از قبلی)، بعد قفل کوتاه‌مدت روی پوشه برای کاربران هم‌زمان،
// خواندن تازه‌ترین نسخه، و پشتیبان روزانه
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function lock(){
 const me=Date.now()+'-'+rnd().slice(0,8);
 for(let i=0;i<60;i++){
  const l=await rd('data/lock');
  if(l){const t=parseInt((await l.text()).split('-')[0],10);if(t&&Date.now()-t<20000){await sleep(300+Math.random()*400);continue}}
  await wr('data/lock',me);await sleep(120);
  const c=await rd('data/lock');if(c&&await c.text()===me)return me}
 throw new Error('پوشه در دست کاربر دیگری است؛ چند لحظه بعد دوباره تلاش کنید')}
async function txRaw(fn){
 await lock();
 try{const db=await open(),r=await fn(db),bytes=db.export();db.close();
  const old=await rd('data/data.sqlite'),day='backup/data-'+new Date().toISOString().slice(0,10)+'.sqlite';
  if(old&&!await rd(day))await wr(day,await old.arrayBuffer());
  await wr('data/data.sqlite',bytes);return r}
 finally{await rm('data/lock')}}
let chain=Promise.resolve();
function tx(fn){const p=chain.then(()=>txRaw(fn));chain=p.catch(()=>{});return p}
// ===== دیتابیس جداگانه‌ی گزارشات: data/reports.sqlite (ماندگار؛ هیچ ردیفی حذف نمی‌شود) =====
const RFILE='data/reports.sqlite';
async function openR(){const f=await rd(RFILE),db=f?new SQL.Database(new Uint8Array(await f.arrayBuffer())):new SQL.Database();
 db.run(`CREATE TABLE IF NOT EXISTS rpt_batches(id INTEGER PRIMARY KEY,cat TEXT,file_id INT,fname TEXT,ts TEXT,uploader TEXT,sheet TEXT,header TEXT,nrows INT,added INT,changed INT,missing INT);
 CREATE TABLE IF NOT EXISTS rpt_rows(id INTEGER PRIMARY KEY,cat TEXT,rkey TEXT,rno INT,data TEXT,first_batch INT,last_batch INT,UNIQUE(cat,rkey));
 CREATE INDEX IF NOT EXISTS rr_cat ON rpt_rows(cat,last_batch)`);return db}
async function rq(sql,p){if(!await rd(RFILE))return[];const db=await openR();try{return rows(db,sql,p)}finally{db.close()}}
async function prune(prefix,keep){try{const[d]=await nav('backup/_',true),n=[];for await(const[k]of d.entries())if(k.startsWith(prefix))n.push(k);
 n.sort();for(const k of n.slice(0,Math.max(0,n.length-keep)))await d.removeEntry(k)}catch(e){}}
// opt.backup=true → قبل از تغییر، یک نسخه‌ی کامل با زمان در پوشه‌ی backup ذخیره می‌شود (۳۰ تای آخر)؛
// به‌علاوه همیشه اولین تغییرِ هر روز، نسخه‌ی قبل از آن را به‌عنوان بکاپ روزانه نگه می‌دارد
async function rtxRaw(fn,opt){
 await lock();
 try{const db=await openR(),old=await rd(RFILE);
  if(old){const ab=await old.arrayBuffer(),iso=new Date().toISOString(),day='backup/reports-'+iso.slice(0,10)+'.sqlite';
   if(!await rd(day))await wr(day,ab);
   if(opt&&opt.backup){await wr('backup/reports-import-'+iso.replace(/[:.]/g,'-')+'.sqlite',ab);await prune('reports-import-',30)}}
  const r=await fn(db),bytes=db.export();db.close();await wr(RFILE,bytes);return r}
 finally{await rm('data/lock')}}
let rchain=Promise.resolve();
function rtx(fn,opt){const p=rchain.then(()=>rtxRaw(fn,opt));rchain=p.catch(()=>{});return p}
async function backups(){try{const[d]=await nav('backup/_',true),n=[];for await(const[k,h]of d.entries())if(k.startsWith('reports-')){const f=await h.getFile();n.push({name:k,size:f.size,ts:f.lastModified})}
 return n.sort((a,b)=>b.name.localeCompare(a.name))}catch(e){return[]}}
// ===== لوگ و ردیابی: data/audit.sqlite (فقط‌افزودنی، زنجیره‌ی هش) + حضور آنلاین: presence/<نشست>.json =====
const AFILE='data/audit.sqlite',APEND=[],SID=rnd().slice(0,12);
const UA=(()=>{const u=navigator.userAgent||'',m=r=>(r.exec(u)||[])[1];
 const b=m(/Edg\/(\d+)/)?'Edge '+m(/Edg\/(\d+)/):m(/OPR\/(\d+)/)?'Opera '+m(/OPR\/(\d+)/):m(/Chrome\/(\d+)/)?'Chrome '+m(/Chrome\/(\d+)/):m(/Firefox\/(\d+)/)?'Firefox '+m(/Firefox\/(\d+)/):m(/Version\/(\d+).*Safari/)?'Safari '+m(/Version\/(\d+).*Safari/):'Browser';
 const o=/Windows/.test(u)?'Windows':/Android/.test(u)?'Android':/iPhone|iPad/.test(u)?'iOS':/Mac OS/.test(u)?'macOS':/Linux/.test(u)?'Linux':'?';return b+' / '+o})();
const ACAT={login_ok:'auth',login_fail:'auth',logout:'auth',timeout:'auth',pw_self:'auth',pw_admin:'auth',pw_forgot:'auth',forgot_req:'auth',forgot_fail:'auth',
 user_add:'user',user_upd:'user',user_del:'user',user_email:'user',cfg_mail:'user',mail_test:'user',upload:'file',merge:'file',file_del:'file',download:'file',
 rpt_sync:'report',rpt_purge:'report',stops_cfg:'report',view:'view'};
const shaHex=async t=>hex(await crypto.subtle.digest('SHA-256',enc.encode(t)));
async function openA(){const f=await rd(AFILE),db=f?new SQL.Database(new Uint8Array(await f.arrayBuffer())):new SQL.Database();
 db.run(`CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,ts TEXT,sid TEXT,uid INT,user TEXT,name TEXT,role TEXT,act TEXT,cat TEXT,detail TEXT,ua TEXT,prev TEXT,h TEXT);
 CREATE INDEX IF NOT EXISTS au_ts ON audit(ts);CREATE INDEX IF NOT EXISTS au_u ON audit(user,ts);CREATE INDEX IF NOT EXISTS au_s ON audit(sid)`);return db}
async function atxRaw(fn){await lock();
 try{const db=await openA(),old=await rd(AFILE);
  if(old){const day='backup/audit-'+new Date().toISOString().slice(0,10)+'.sqlite';if(!await rd(day))await wr(day,await old.arrayBuffer())}
  const r=await fn(db),bytes=db.export();db.close();await wr(AFILE,bytes);return r}
 finally{await rm('data/lock')}}
let achain=Promise.resolve();
async function aflush(){if(!APEND.length||!dir||!SQL)return;const batch=APEND.slice();
 try{await atxRaw(async db=>{let prev=(rows(db,'SELECT h FROM audit ORDER BY id DESC LIMIT 1')[0]||{}).h||'';
   for(const e of batch){const h=await shaHex([prev,e.ts,e.sid,e.uid,e.user,e.act,e.detail].join('|'));
    db.run('INSERT INTO audit(ts,sid,uid,user,name,role,act,cat,detail,ua,prev,h) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',[e.ts,e.sid,e.uid,e.user,e.name,e.role,e.act,e.cat,e.detail,e.ua,prev,h]);prev=h}});
  APEND.splice(0,batch.length)}catch(e){console.warn('audit',e)}}
// who: بازیگر رویداد (پیش‌فرض کاربر واردشده)؛ over: {sid,ts} برای رویدادهایی که از طرف نشستی دیگر ثبت می‌شوند (قطع ارتباط)
function alog(act,detail,who,over){const u=who||App.user||{};
 APEND.push({ts:(over&&over.ts)||new Date().toISOString(),sid:(over&&over.sid)||SID,uid:u.id||0,user:u.username||'',name:u.name||'',role:u.role||'',act,cat:ACAT[act]||'sys',detail:String(detail??'').slice(0,1500),ua:UA});
 if(APEND.length>1000)APEND.splice(0,APEND.length-1000);
 achain=achain.then(aflush).catch(()=>{});return achain}
async function aq(sql,p){if(!await rd(AFILE))return[];const db=await openA();try{return rows(db,sql,p)}finally{db.close()}}
async function presPut(sid,o){await wr('presence/'+sid+'.json',JSON.stringify(o))}
async function presDel(sid){await rm('presence/'+sid+'.json')}
async function presList(){const out=[];try{const d=await dir.getDirectoryHandle('presence');
 for await(const[k,h]of d.entries()){if(!k.endsWith('.json'))continue;try{out.push(JSON.parse(await(await h.getFile()).text()))}catch(e){}}}catch(e){}return out}
const App={user:null,connected:()=>!!dir&&!!SQL,sid:SID,ua:UA,alog,aq,presPut,presDel,presList,connect,q,tx,rq,rtx,backups,rfile:()=>rd(RFILE),getBackup:n=>rd('backup/'+n),
 can:p=>!!App.user&&(App.user.role==='admin'||(App.user.perms||'').split(',').includes(p)),
 async login(u,p){const un=u.trim().toLowerCase(),r=(await q('SELECT * FROM users WHERE username=? AND active=1',[un]))[0];
  if(!r||await hash(p,r.salt)!==r.hash){const ex=un?(await q('SELECT active FROM users WHERE username=?',[un]))[0]:null;
   alog('login_fail',!un?'نام کاربری خالی':!ex?'نام کاربری وجود ندارد':ex.active?'رمز اشتباه':'کاربر غیرفعال',{username:un.slice(0,60)});return null}
  delete r.salt;delete r.hash;App.user=r;return r},
 async setPw(id,pw,must){const t=(await q('SELECT username,name FROM users WHERE id=?',[id]))[0]||{},s=rnd(),h=await hash(pw,s);
  await tx(db=>db.run('UPDATE users SET salt=?,hash=?,must=? WHERE id=?',[s,h,must?1:0,id]));
  const me=App.user;
  if(!me)alog('pw_forgot','بازیابی رمز با کد ایمیل',{id,username:t.username,name:t.name});
  else if(me.id===id)alog('pw_self','تغییر رمز توسط خود کاربر');
  else alog('pw_admin','ریست رمز کاربر «'+t.username+'»'+(must?' (در ورود بعدی باید عوض کند)':''))},
 async addUser(u,name,pw,role,perms){const s=rnd(),h=await hash(pw,s);await tx(db=>db.run('INSERT INTO users(username,name,salt,hash,role,perms,active,must) VALUES(?,?,?,?,?,?,1,1)',[u.trim().toLowerCase(),name,s,h,role,perms]));
  alog('user_add','«'+u.trim().toLowerCase()+'» نقش: '+role+' | دسترسی‌ها: '+(perms||'—'))},
 users:()=>q('SELECT id,username,name,role,perms,active,email FROM users ORDER BY id'),
 async setEmail(id,em){const o=(await q('SELECT username,email FROM users WHERE id=?',[id]))[0]||{};
  await tx(db=>db.run('UPDATE users SET email=? WHERE id=?',[em,id]));alog('user_email','«'+o.username+'»: '+(o.email||'—')+' ← '+(em||'—'))},
 async findForReset(k){k=String(k||'').trim().toLowerCase();return(await q('SELECT id,username,name,email FROM users WHERE active=1 AND (username=? OR lower(email)=?)',[k,k]))[0]||null},
 async getCfg(){const o={};(await q('SELECT k,v FROM settings')).forEach(x=>o[x.k]=x.v);return o},
 async setCfg(o){await tx(db=>{for(const k in o)db.run('INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)',[k,o[k]])});alog('cfg_mail','تنظیمات ذخیره شد: '+Object.keys(o).join('، '))},
 async updUser(id,role,perms,act){const o=(await q('SELECT username,role,perms,active FROM users WHERE id=?',[id]))[0]||{};
  await tx(db=>db.run('UPDATE users SET role=?,perms=?,active=? WHERE id=?',[role,perms,act,id]));
  const ch=[];if(o.role!==role)ch.push('نقش از '+o.role+' به '+role);if((o.perms||'')!==perms)ch.push('دسترسی از ['+(o.perms||'')+'] به ['+perms+']');if(!!o.active!==!!act)ch.push(act?'فعال شد':'غیرفعال شد');
  alog('user_upd','«'+o.username+'» — '+(ch.length?ch.join('، '):'بدون تغییر'))},
 async delUser(id){const o=(await q('SELECT username,name FROM users WHERE id=?',[id]))[0]||{};
  await tx(db=>db.run('DELETE FROM users WHERE id=?',[id]));alog('user_del','«'+o.username+'» ('+(o.name||'')+') حذف شد')},
 async save(kind,name,blob,src,cat,srcIds){const ts=new Date().toISOString(),sf=s=>s.replace(/[\\/:*?"<>|]/g,'_'),
  stored=(kind==='merged'?'merged/':'files/')+ts.replace(/[:.]/g,'-')+'_'+sf(App.user.username)+'_'+sf(name);
  await wr(stored,blob);
  const _id=await tx(db=>{db.run('INSERT INTO files(orig,stored,size,uploader,ts,kind,src,cat,srcids) VALUES(?,?,?,?,?,?,?,?,?)',[name,stored,blob.size,App.user.username,ts,kind,(src||[]).join(' | '),cat||'daily',JSON.stringify(srcIds||[])]);
   return rows(db,'SELECT last_insert_rowid() AS id')[0].id});
  alog(kind==='merged'?'merge':'upload','«'+name+'» | '+Math.ceil(blob.size/1024)+' KB | دسته: '+(cat||'daily')+((src||[]).length?' | مبدأ: '+src.join('، '):'')+' | شناسه: '+_id);return _id},
 list:kind=>q('SELECT * FROM files WHERE kind=? ORDER BY id DESC',[kind]),
 get:stored=>rd(stored),
 async del(id,stored){const o=(await q('SELECT orig,kind,uploader,cat FROM files WHERE id=?',[id]))[0]||{};
  await tx(db=>db.run('DELETE FROM files WHERE id=?',[id]));await rm(stored);
  alog('file_del','«'+(o.orig||stored)+'» ('+(o.kind==='merged'?'ادغام‌شده':'آپلودی')+(o.uploader?'، آپلودکننده: '+o.uploader:'')+') | شناسه: '+id)}};
window.App=App;
})();
