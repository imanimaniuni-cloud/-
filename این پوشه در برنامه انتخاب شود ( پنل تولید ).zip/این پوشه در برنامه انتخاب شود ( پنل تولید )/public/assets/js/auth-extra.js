// بازیابی رمز با کد ایمیل + ایمیل کاربران + تنظیمات ارسال (بدون سرور؛ ارسال از طریق EmailJS)
(function(){
const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
const sha=async t=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)));
const mask=e=>{const[a,d]=e.split('@');return a.slice(0,2)+'•••@'+d};
const fa=s=>String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const OKMAIL=/^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const TMO=(ms,msg)=>new Promise((_,no)=>setTimeout(()=>no(new Error(msg)),ms));
async function sendMail(cfg,to,name,code){
  if(navigator.onLine===false)throw new Error('اتصال اینترنت برقرار نیست');
  const ac=new AbortController(),t=setTimeout(()=>ac.abort(),20000);let r;
  try{r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},signal:ac.signal,
    body:JSON.stringify({service_id:cfg.ej_service,template_id:cfg.ej_template,user_id:cfg.ej_key,template_params:{to_email:to,to_name:name,code,minutes:10,app_name:'پنل ادغام اکسل'}})})}
  catch(e){throw new Error(e.name==='AbortError'?'سرویس ایمیل (emailjs.com) پاسخ نداد؛ اینترنت یا فیلترشکن را بررسی کنید و دوباره امتحان کنید':'ارتباط با سرویس ایمیل (emailjs.com) برقرار نشد؛ اینترنت یا فیلترشکن را بررسی کنید')}
  finally{clearTimeout(t)}
  if(!r.ok){let tx='';try{tx=(await r.text()).slice(0,160)}catch(e){}
    throw new Error(r.status===400&&/service|template/i.test(tx)?'Service ID یا Template ID اشتباه است ('+tx+')':r.status===401||r.status===403?'Public Key اشتباه است یا دسترسی رد شد ('+(tx||r.status)+')':(tx||('خطا '+r.status)))}}
// ---------- پنجره‌ی بازیابی ----------
const m=document.createElement('div');m.id='fp';
m.innerHTML='<div class="fp-box"><button class="fp-x" aria-label="بستن">×</button><h5>بازیابی رمز عبور</h5><div id="fp-b"></div></div>';document.body.appendChild(m);
let S=null;const body=h=>{$('#fp-b').innerHTML=h};
const close=()=>{m.classList.remove('on');S=null};
function step1(msg){body(`<p class="small text-muted">نام کاربری یا ایمیل خود را وارد کنید؛ کد ۶ رقمی به ایمیل ثبت‌شده‌ی شما ارسال می‌شود.</p>
 <input id="fp-k" class="form-control mb-2" placeholder="نام کاربری یا ایمیل" dir="ltr" value="${E(($('#lu')||{}).value||'')}">
 <button class="btn btn-primary w-100" id="fp-s">ارسال کد</button><div class="fp-m" id="fp-e">${msg||''}</div>`);$('#fp-k').focus()}
function step2(msg){body(`<p class="small">کد به <b dir="ltr">${E(mask(S.email))}</b> ارسال شد و ۱۰ دقیقه اعتبار دارد.</p>
 <input id="fp-c" class="form-control mb-2 fp-code" inputmode="numeric" maxlength="6" placeholder="••••••" dir="ltr" autocomplete="one-time-code">
 <input id="fp-p" type="password" class="form-control mb-2" placeholder="رمز جدید (حداقل ۶ کاراکتر)" autocomplete="new-password">
 <input id="fp-p2" type="password" class="form-control mb-2" placeholder="تکرار رمز جدید" autocomplete="new-password">
 <button class="btn btn-success w-100" id="fp-v">تغییر رمز</button><button class="btn btn-link btn-sm w-100 mt-1" id="fp-r">ارسال دوباره‌ی کد</button>
 <div class="fp-m" id="fp-e">${msg||''}</div>`);$('#fp-c').focus()}
async function sendCode(){const e=$('#fp-e'),b=$('#fp-s'),k=$('#fp-k').value.trim();e.textContent='';
  if(!k)return e.textContent='نام کاربری یا ایمیل را وارد کنید';b.disabled=true;const b0=b.textContent;b.innerHTML='<span class="spinner-border spinner-border-sm"></span> در حال ارسال…';e.style.color='';
  let U=null;try{if(!App.connected()&&!await Promise.race([App.connect('ask'),TMO(60000,'دسترسی به پوشه تایید نشد')])){e.textContent='ابتدا دسترسی به پوشه را تایید (Allow) کنید.';return}
    const cfg=await Promise.race([App.getCfg(),TMO(10000,'خواندن تنظیمات از پوشه طول کشید؛ پوشه‌ی اشتراکی را بررسی کنید')]);
    if(!cfg.ej_service||!cfg.ej_template||!cfg.ej_key){e.textContent='ارسال ایمیل هنوز تنظیم نشده؛ مدیر باید آن را در «کاربران ← تنظیمات ایمیل» وارد کند.';return}
    const u=await App.findForReset(k);U=u;if(!u){App.alog('forgot_fail','کاربری با «'+k.slice(0,60)+'» پیدا نشد',{username:k.slice(0,60)});e.textContent='کاربری با این مشخصات پیدا نشد';return}
    if(!u.email){App.alog('forgot_fail','کاربر ایمیل ثبت‌شده ندارد',{id:u.id,username:u.username,name:u.name});e.textContent='برای این کاربر ایمیلی ثبت نشده؛ از مدیر بخواهید در بخش کاربران ثبت کند.';return}
    const code=String(crypto.getRandomValues(new Uint32Array(1))[0]%1000000).padStart(6,'0'),nonce=crypto.randomUUID();
    await sendMail(cfg,u.email,u.name,code);App.alog('forgot_req','کد بازیابی به '+mask(u.email)+' ارسال شد',{id:u.id,username:u.username,name:u.name});
    S={uid:u.id,un:u.username,email:u.email,nonce,h:await sha(code+':'+u.id+':'+nonce),exp:Date.now()+6e5,tries:0,t0:Date.now(),k};step2()}
  catch(x){e.textContent='ارسال ایمیل ناموفق: '+(x.message||x);App.alog('forgot_fail','ارسال ایمیل ناموفق: '+String(x.message||x).slice(0,120),U?{id:U.id,username:U.username,name:U.name}:{username:k.slice(0,60)})}finally{b.disabled=false;if(b.isConnected)b.textContent=b0}}
async function verify(){const e=$('#fp-e');e.textContent='';
  if(!S)return step1();
  if(Date.now()>S.exp){S=null;return step1('کد منقضی شد؛ دوباره درخواست دهید.')}
  const c=$('#fp-c').value.replace(/\D/g,''),p=$('#fp-p').value;
  if(c.length!==6)return e.textContent='کد ۶ رقمی را وارد کنید';
  if(p.length<6)return e.textContent='رمز جدید باید حداقل ۶ کاراکتر باشد';
  if(p!==$('#fp-p2').value)return e.textContent='تکرار رمز مطابقت ندارد';
  if(++S.tries>5){App.alog('forgot_fail','تلاش بیش‌ازحد برای کد بازیابی',{id:S.uid,username:S.un});S=null;return step1('تلاش‌ها زیاد بود؛ کد جدید بگیرید.')}
  if(await sha(c+':'+S.uid+':'+S.nonce)!==S.h){App.alog('forgot_fail','کد بازیابی اشتباه وارد شد (تلاش '+S.tries+' از ۵)',{id:S.uid,username:S.un});return e.textContent='کد اشتباه است ('+fa(5-S.tries)+' تلاش باقی مانده)'}
  try{await App.setPw(S.uid,p,0)}catch(x){return e.textContent='ثبت رمز ناموفق: '+x.message}
  const un=S.un;S=null;body('<div class="fp-ok"><i class="fa-solid fa-circle-check"></i><p>رمز عبور تغییر کرد. حالا وارد شوید.</p></div>');
  const lu=$('#lu'),lp=$('#lp');if(lu)lu.value=un;if(lp)lp.value='';setTimeout(()=>{close();if(lp)lp.focus()},1400)}
document.addEventListener('click',e=>{const t=e.target;
  if(t.closest('#fgt')){e.preventDefault();m.classList.add('on');step1()}
  else if(t.closest('#fp-s'))sendCode();else if(t.closest('#fp-v'))verify();
  else if(t.closest('#fp-r')){const w=S?Math.ceil((6e4-(Date.now()-S.t0))/1000):0;if(w>0)return $('#fp-e').textContent='بعد از '+fa(w)+' ثانیه می‌توانید دوباره بفرستید';const k=S&&S.k;S=null;step1();if(k){$('#fp-k').value=k;sendCode()}}
  else if(t.closest('.fp-x')||t===m)close()});
m.addEventListener('keydown',e=>{if(e.key==='Escape')close();if(e.key==='Enter'){const b=$('#fp-s')||$('#fp-v');if(b)b.click()}});
// ---------- صفحه‌ی کاربران: ایمیل هر کاربر + تنظیمات ارسال ----------
const uv=$('#v-users');let busy=false,tm;
async function enhance(){if(!uv||busy||uv.querySelector('.em')||!uv.querySelector('tr[data-u]'))return;busy=true;
  try{const l=await App.users(),c=await App.getCfg();if(uv.querySelector('.em'))return;
    uv.querySelectorAll('tr[data-u]').forEach(tr=>{const u=l.find(x=>x.id===+tr.dataset.u);if(u)tr.querySelector('td').insertAdjacentHTML('beforeend',`<input class="form-control form-control-sm mt-1 em" dir="ltr" placeholder="ایمیل (برای بازیابی رمز)" value="${E(u.email||'')}">`)});
    uv.insertAdjacentHTML('beforeend',`<div class="card" id="ejc"><div class="card-header"><i class="fa-solid fa-envelope-circle-check"></i> تنظیمات ایمیل (کد بازیابی رمز)</div><div class="card-body row g-2">
     <div class="col-md-4"><input id="ej1" class="form-control" dir="ltr" placeholder="Service ID" value="${E(c.ej_service||'')}"></div>
     <div class="col-md-4"><input id="ej2" class="form-control" dir="ltr" placeholder="Template ID" value="${E(c.ej_template||'')}"></div>
     <div class="col-md-4"><input id="ej3" class="form-control" dir="ltr" placeholder="Public Key" value="${E(c.ej_key||'')}"></div>
     <div class="col-12 small text-muted">در emailjs.com حساب رایگان بسازید، یک Email Service (مثلاً Gmail) اضافه کنید و یک Template بسازید که گیرنده‌اش <code dir="ltr">{{to_email}}</code> و متنش شامل <code dir="ltr">{{code}}</code> باشد؛ سه مقدار بالا را از همان‌جا کپی کنید.</div>
     <div class="col-12"><button class="btn btn-primary" id="ejs">ذخیره</button> <button class="btn btn-light" id="ejt">ارسال ایمیل آزمایشی به ایمیل من</button> <span class="small" id="ejm"></span></div></div></div>`)}
  finally{busy=false}}
if(uv)new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(enhance,40)}).observe(uv,{childList:true});
const note=(t,ok)=>{const x=$('#ejm');if(x){x.textContent=t;x.style.color=ok?'#15803d':'#c0392b'}};
if(uv){uv.addEventListener('change',e=>{const i=e.target.closest('.em');if(!i)return;const v=i.value.trim();
    if(v&&!OKMAIL.test(v)){i.classList.add('is-invalid');return}i.classList.remove('is-invalid');
    App.setEmail(+i.closest('tr').dataset.u,v).then(()=>{i.classList.add('is-valid');setTimeout(()=>i.classList.remove('is-valid'),1500)}).catch(x=>alert(x.message))});
  uv.addEventListener('click',async e=>{const b=e.target.closest('#ejs,#ejt');if(!b)return;
    const cfg={ej_service:$('#ej1').value.trim(),ej_template:$('#ej2').value.trim(),ej_key:$('#ej3').value.trim()};
    try{if(b.id==='ejs'){await App.setCfg(cfg);note('ذخیره شد',1)}
      else{if(!cfg.ej_service||!cfg.ej_template||!cfg.ej_key)return note('هر سه مقدار را وارد کنید');
        const me=(await App.users()).find(u=>u.id===App.user.id);if(!me||!me.email)return note('اول ایمیل خودتان را در جدول بالا ثبت کنید');
        note('در حال ارسال…',1);await sendMail(cfg,me.email,me.name,'000000');note('ایمیل آزمایشی ارسال شد؛ صندوق ورودی را ببینید',1);App.alog('mail_test','ارسال ایمیل آزمایشی به ایمیل ادمین')}}
    catch(x){note('ناموفق: '+(x.message||x))}})}
})();
