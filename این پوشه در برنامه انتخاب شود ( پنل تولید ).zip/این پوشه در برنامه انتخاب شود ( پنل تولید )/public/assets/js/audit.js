// لوگ و ردیابی (فقط ادمین): کاربران آنلاین به‌صورت زنده + تاریخچه‌ی کامل ورود/خروج/عملیات (بدون سرور؛ روی پوشه‌ی اشتراکی)
(function(){
const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=n=>Number(n).toLocaleString('fa-IR'),dt=s=>s?new Date(s).toLocaleString('fa-IR'):'—',tm=s=>s?new Date(s).toLocaleTimeString('fa-IR'):'—';
const dur=ms=>{const m=Math.max(0,Math.floor(ms/60000));if(m<1)return'کمتر از ۱ دقیقه';const h=Math.floor(m/60);return(h?faN(h)+' ساعت و ':'')+faN(m%60)+' دقیقه'};
const sha=async t=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const LBL={login_ok:['ورود','g'],login_fail:['ورود ناموفق','r'],logout:['خروج','b'],timeout:['قطع ارتباط','y'],pw_self:['تغییر رمز (خود کاربر)','b'],pw_admin:['ریست رمز توسط ادمین','y'],pw_forgot:['بازیابی رمز','y'],
 forgot_req:['درخواست بازیابی رمز','b'],forgot_fail:['بازیابی ناموفق','r'],user_add:['افزودن کاربر','p'],user_upd:['ویرایش کاربر','p'],user_del:['حذف کاربر','r'],user_email:['ثبت ایمیل کاربر','p'],
 cfg_mail:['تنظیمات ایمیل','p'],mail_test:['ایمیل آزمایشی','p'],upload:['آپلود فایل','g'],merge:['ادغام فایل','g'],file_del:['حذف فایل','r'],download:['دانلود','b'],view:['مشاهده‌ی صفحه','n'],
 rpt_sync:['همگام‌سازی گزارشات','b'],rpt_purge:['پاکسازی ردیف قدیمی','y'],stops_cfg:['تنظیم دسته‌ی توقفات','p']};
const CATL={auth:'ورود و امنیت',user:'کاربران و تنظیمات',file:'فایل‌ها',report:'گزارشات',view:'مشاهده‌ی صفحات'};
const badge=a=>{const l=LBL[a]||[a,'n'];return`<span class="au-bd au-${l[1]}">${E(l[0])}</span>`};
{const st=document.createElement('style');st.textContent=`.au-bd{display:inline-block;padding:2px 9px;border-radius:10px;font-size:12px;white-space:nowrap;font-weight:600}
.au-g{background:#dcfce7;color:#166534}.au-r{background:#fee2e2;color:#991b1b}.au-b{background:#dbeafe;color:#1e40af}.au-y{background:#fef3c7;color:#92400e}.au-p{background:#f3e8ff;color:#7e22ce}.au-n{background:#e5e7eb;color:#374151}
.au-dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.7);animation:aup 1.6s infinite}
@keyframes aup{70%{box-shadow:0 0 0 9px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
#v-log .au-lk{cursor:pointer;color:#2563eb;text-decoration:underline dotted}#v-log td{vertical-align:top}#v-log .au-dt{max-width:520px;word-break:break-word}`;document.head.appendChild(st)}
const PG={files:'فایل‌ها',merge:'ادغام',users:'کاربران',log:'لوگ'};
const pageName=(t,c)=>t==='reports'?'گزارشات'+(window.Reports&&Reports.CATS&&Reports.CATS[c]?': '+Reports.CATS[c].n:''):(PG[t]||t);
const HB=15000,POLL=12000;
let me=null,beat=0,lastAct=Date.now(),hb=null,poll=null,curPage='',SUB='online',ON=[];const seen=new Map();
['click','keydown','input','touchstart'].forEach(ev=>document.addEventListener(ev,()=>{lastAct=Date.now()},true));
const visible=sub=>{const v=$('#v-log');return!!v&&v.style.display!=='none'&&SUB===sub};
// ---------- حضور (heartbeat) ----------
async function put(){if(!me)return;beat++;
 try{await App.presPut(me.sid,{sid:me.sid,uid:me.id,user:me.username,name:me.name,role:me.role,login:me.login,n:beat,ts:new Date().toISOString(),act:new Date(lastAct).toISOString(),page:curPage,ua:App.ua})}catch(e){}}
function start(r){stopTimers();me={sid:App.sid,id:r.id,username:r.username,name:r.name,role:r.role,login:new Date().toISOString()};beat=0;curPage='';
 App.alog('login_ok','ورود موفق | دستگاه: '+App.ua);put();hb=setInterval(put,HB);
 if(r.role==='admin'){poll=setInterval(refresh,POLL);refresh()}}
function stopTimers(){clearInterval(hb);clearInterval(poll);hb=poll=null}
async function stop(){if(!me)return;stopTimers();const m=me;me=null;
 try{await App.alog('logout','خروج از سیستم | مدت حضور: '+dur(Date.now()-new Date(m.login)));await App.presDel(m.sid)}catch(e){}}
function view(t,c){const p=pageName(t,c);if(p===curPage)return;curPage=p;if(me){App.alog('view',p);put()}}
// نشستی که دیگر ضربان نمی‌زند: «قطع ارتباط» ثبت می‌شود (فقط یک‌بار برای هر نشست)
async function reap(s){try{
 const ex=await App.aq("SELECT 1 FROM audit WHERE sid=? AND act IN('logout','timeout') LIMIT 1",[s.sid]);
 if(!ex.length)await App.alog('timeout','ارتباط بدون خروج قطع شد (بستن صفحه یا قطع اینترنت) | آخرین فعالیت: '+dt(s.act||s.ts)+' | آخرین صفحه: '+(s.page||'—'),{id:s.uid,username:s.user,name:s.name,role:s.role},{sid:s.sid,ts:s.ts});
 await App.presDel(s.sid)}catch(e){}}
async function refresh(){if(!me||me.role!=='admin')return;
 let L;try{L=await App.presList()}catch(e){return}
 const now=Date.now(),on=[];
 for(const s of L){const p=seen.get(s.sid);
  if(!p)seen.set(s.sid,{n:s.n,at:now,first:true});else if(p.n!==s.n){p.n=s.n;p.at=now;p.first=false}
  const q=seen.get(s.sid),age=now-new Date(s.ts).getTime();
  // «زنده» بودن بر اساس تغییر شمارنده‌ی ضربان است، نه ساعت سیستم‌ها (تا اختلاف ساعت کامپیوترها مشکل نسازد)
  const alive=now-q.at<50000&&(!q.first||age<60000);
  if(alive)on.push(s);else if(now-q.at>120000||(q.first&&age>3600000))await reap(s)}
 for(const k of[...seen.keys()])if(!L.some(s=>s.sid===k))seen.delete(k);
 ON=on.sort((a,b)=>new Date(a.login)-new Date(b.login));
 const b=$('#onb');if(b)b.textContent=ON.length?faN(ON.length):'';
 if(visible('online')){paintOnline();paintRecent()}}
// ---------- صفحه‌ی آنلاین‌ها ----------
function paintOnline(){const el=$('#au-on');if(!el)return;const now=Date.now();
 el.innerHTML=`<div class="card"><div class="card-header d-flex align-items-center gap-2"><span class="au-dot"></span> کاربران آنلاین <span class="au-bd au-g">${faN(ON.length)}</span>
 <span class="small text-muted ms-auto">به‌روزرسانی خودکار هر ${faN(POLL/1000)} ثانیه — آخرین: ${tm(new Date())}</span></div>`+
 (ON.length?`<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>کاربر</th><th>نقش</th><th>ورود</th><th>مدت حضور</th><th>آخرین فعالیت</th><th>صفحه‌ی فعلی</th><th>دستگاه</th><th>وضعیت</th><th></th></tr></thead><tbody>`+
 ON.map(s=>{const idle=now-new Date(s.act||s.ts)>300000;
  return`<tr><td>${E(s.name)}${me&&s.sid===me.sid?' <span class="small text-muted">(شما)</span>':''}<div class="small text-muted" dir="ltr">${E(s.user)}</div></td><td>${s.role==='admin'?'ادمین':'کاربر'}</td><td>${dt(s.login)}</td><td>${dur(now-new Date(s.login))}</td><td>${tm(s.act||s.ts)}</td><td>${E(s.page||'—')}</td><td class="small" dir="ltr">${E(s.ua||'')}</td>
  <td><span class="au-bd ${idle?'au-y':'au-g'}">${idle?'بیکار':'فعال'}</span></td><td><button class="btn btn-sm btn-light" data-trk="${E(s.sid)}">رهگیری</button></td></tr>`}).join('')+`</tbody></table></div>`:'<div class="card-body text-muted">اکنون کاربری آنلاین نیست.</div>')+`</div>`}
async function paintRecent(){const el=$('#au-rec');if(!el)return;
 const rows=await App.aq("SELECT * FROM audit WHERE cat<>'view' ORDER BY id DESC LIMIT 15");if(!$('#au-rec'))return;
 $('#au-rec').innerHTML=rows.length?`<table class="table align-middle mb-0"><tbody>`+rows.map(r=>`<tr><td class="text-nowrap small">${dt(r.ts)}</td><td>${E(r.name||r.user||'—')}<div class="small text-muted" dir="ltr">${E(r.user)}</div></td><td>${badge(r.act)}</td><td class="au-dt small">${E(r.detail)}</td></tr>`).join('')+`</tbody></table>`:'<div class="card-body text-muted">هنوز رویدادی ثبت نشده.</div>'}
// ---------- تاریخچه ----------
const H={q:'',user:'',cat:'',act:'',rng:'7',sid:'',hideView:true,page:0},PS=50;
function where(){const w=[],p=[];
 if(H.user){w.push('user=?');p.push(H.user)}if(H.cat){w.push('cat=?');p.push(H.cat)}if(H.act){w.push('act=?');p.push(H.act)}if(H.sid){w.push('sid=?');p.push(H.sid)}
 if(H.hideView&&H.cat!=='view')w.push("cat<>'view'");
 if(H.rng!=='all'){const d=H.rng==='0'?(x=>{x.setHours(0,0,0,0);return x})(new Date()):new Date(Date.now()-(+H.rng)*864e5);w.push('ts>=?');p.push(d.toISOString())}
 if(H.q){w.push('(detail LIKE ? OR user LIKE ? OR name LIKE ?)');const l='%'+H.q+'%';p.push(l,l,l)}
 return[w.length?'WHERE '+w.join(' AND '):'',p]}
async function history(){const v=$('#v-log');
 const us=(await App.aq("SELECT DISTINCT user FROM audit WHERE user<>'' ORDER BY user")).map(x=>x.user);
 if(H.user&&!us.includes(H.user))us.push(H.user);
 const opt=(a,sel)=>a.map(([v,t])=>`<option value="${E(v)}" ${v===sel?'selected':''}>${E(t)}</option>`).join('');
 v.innerHTML=`<div class="card" id="au-f"><div class="card-body row g-2 align-items-end">
  <div class="col-md-3"><label class="small text-muted">جستجو در جزئیات</label><input id="au-q" class="form-control form-control-sm" value="${E(H.q)}" placeholder="نام فایل، کاربر، …"></div>
  <div class="col-md-2"><label class="small text-muted">کاربر</label><select id="au-u" class="form-select form-select-sm">${opt([['','همه'],...us.map(u=>[u,u])],H.user)}</select></div>
  <div class="col-md-2"><label class="small text-muted">دسته</label><select id="au-c" class="form-select form-select-sm">${opt([['','همه'],...Object.entries(CATL)],H.cat)}</select></div>
  <div class="col-md-2"><label class="small text-muted">نوع رویداد</label><select id="au-a" class="form-select form-select-sm">${opt([['','همه'],...Object.entries(LBL).map(([k,l])=>[k,l[0]])],H.act)}</select></div>
  <div class="col-md-2"><label class="small text-muted">بازه</label><select id="au-r" class="form-select form-select-sm">${opt([['0','امروز'],['7','۷ روز اخیر'],['30','۳۰ روز اخیر'],['90','۹۰ روز اخیر'],['all','همه']],H.rng)}</select></div>
  <div class="col-12 d-flex flex-wrap gap-3 align-items-center"><label class="small"><input type="checkbox" id="au-hv" ${H.hideView?'checked':''}> پنهان‌کردن «مشاهده‌ی صفحه»</label><span id="au-chip"></span>
   <span class="ms-auto d-flex gap-2"><button class="btn btn-sm btn-light" id="au-rs">پاک‌کردن فیلترها</button><button class="btn btn-sm btn-primary" id="au-xl"><i class="fa-solid fa-file-excel"></i> خروجی اکسل</button><button class="btn btn-sm btn-light" id="au-vf"><i class="fa-solid fa-shield-halved"></i> بررسی صحت لوگ</button></span></div>
  <div class="col-12 small" id="au-vm"></div></div></div><div class="card"><div id="au-h"></div></div>`;
 chip();await loadH()}
const chip=()=>{const c=$('#au-chip');if(c)c.innerHTML=H.sid?`<span class="au-bd au-p">نشست ${E(H.sid)} <a href="#" data-clr="sid" style="color:inherit">×</a></span>`:''};
async function loadH(){const el=$('#au-h');if(!el)return;const[wh,p]=where();
 const c=(await App.aq('SELECT COUNT(*) n FROM audit '+wh,p))[0]||{n:0},rows=await App.aq('SELECT * FROM audit '+wh+' ORDER BY id DESC LIMIT '+PS+' OFFSET '+H.page*PS,p),pages=Math.max(1,Math.ceil(c.n/PS));
 if(!$('#au-h'))return;
 $('#au-h').innerHTML=`<div class="card-header d-flex align-items-center">رویدادها <span class="au-bd au-n ms-2">${faN(c.n)}</span></div>`+
 (rows.length?`<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>زمان</th><th>کاربر</th><th>رویداد</th><th>جزئیات</th><th>نشست</th><th>دستگاه</th></tr></thead><tbody>`+
 rows.map(r=>`<tr><td class="text-nowrap small">${dt(r.ts)}</td><td>${E(r.name||'—')}<div class="small au-lk" dir="ltr" data-fu="${E(r.user)}">${E(r.user||'—')}</div></td><td>${badge(r.act)}</td><td class="au-dt small">${E(r.detail)}</td>
  <td class="small au-lk" dir="ltr" data-fs="${E(r.sid)}" title="همه‌ی رویدادهای این نشست">${E(r.sid)}</td><td class="small" dir="ltr">${E(r.ua||'')}</td></tr>`).join('')+`</tbody></table></div>
  <div class="d-flex gap-2 align-items-center p-3"><button class="btn btn-light btn-sm" data-pg="-1" ${H.page?'':'disabled'}>قبلی</button><button class="btn btn-light btn-sm" data-pg="1" ${H.page<pages-1?'':'disabled'}>بعدی</button><span class="small text-muted">صفحه ${faN(H.page+1)} از ${faN(pages)}</span></div>`:'<div class="card-body text-muted">رویدادی با این فیلتر پیدا نشد.</div>')}
async function exportXl(){const[wh,p]=where();const rows=await App.aq('SELECT * FROM audit '+wh+' ORDER BY id LIMIT 50000',p);
 const head=['شماره','زمان','زمان (UTC)','نام کاربری','نام','نقش','رویداد','دسته','جزئیات','نشست','دستگاه','هش'];
 const ws=XLSX.utils.aoa_to_sheet([head].concat(rows.map(r=>[r.id,dt(r.ts),r.ts,r.user,r.name,r.role,(LBL[r.act]||[r.act])[0],CATL[r.cat]||r.cat,r.detail,r.sid,r.ua,r.h])));
 ws['!cols']=[8,22,24,14,16,8,18,14,60,14,22,20].map(w=>({wch:w}));const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'لوگ');wb.Workbook={Views:[{RTL:true}]};
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([XLSX.write(wb,{type:'array',bookType:'xlsx'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
 a.download='audit-log-'+new Date().toISOString().slice(0,10)+'.xlsx';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
 App.alog('download','خروجی اکسل لوگ ('+rows.length+' رکورد)')}
// هر رکورد هشِ رکورد قبلی را در خود دارد؛ حذف یا ویرایش دستی یک رکورد، زنجیره را می‌شکند
async function verify(){const m=$('#au-vm');m.textContent='در حال بررسی…';
 const all=await App.aq('SELECT id,ts,sid,uid,user,act,detail,prev,h FROM audit ORDER BY id');let prev='',bad=null;
 for(const r of all){if(r.prev!==prev||await sha([r.prev,r.ts,r.sid,r.uid,r.user,r.act,r.detail].join('|'))!==r.h){bad=r;break}prev=r.h}
 m.innerHTML=bad?`<span class="au-bd au-r">زنجیره از رکورد شماره‌ی ${faN(bad.id)} (${dt(bad.ts)}) مخدوش است؛ لوگ بعد از این نقطه دست‌کاری یا حذف شده.</span>`:`<span class="au-bd au-g">سالم — ${faN(all.length)} رکورد، بدون هیچ حذف یا ویرایشی.</span>`}
async function show(sub){if(!App.user||App.user.role!=='admin')return;SUB=sub||'online';const v=$('#v-log');
 if(SUB==='online'){v.innerHTML=`<div id="au-on"></div><div class="card"><div class="card-header">آخرین رویدادها</div><div id="au-rec" class="table-responsive"></div></div>`;await refresh();paintOnline();paintRecent()}
 else await history()}
const goHist=()=>{const b=document.querySelector('#subnav [data-c=history]');if(b)b.click();else show('history')};
document.addEventListener('click',async e=>{const v=e.target.closest('#v-log');if(!v)return;const t=e.target;let x;
 try{
 if(x=t.closest('[data-trk]')){e.preventDefault();Object.assign(H,{sid:x.dataset.trk,user:'',cat:'',act:'',q:'',rng:'all',page:0});goHist()}
 else if(x=t.closest('[data-fu]')){if(!x.dataset.fu)return;Object.assign(H,{user:x.dataset.fu,page:0});await history()}
 else if(x=t.closest('[data-fs]')){Object.assign(H,{sid:x.dataset.fs,rng:'all',page:0});await history()}
 else if(t.closest('[data-clr]')){e.preventDefault();H.sid='';H.page=0;await history()}
 else if(x=t.closest('[data-pg]')){H.page=Math.max(0,H.page+ +x.dataset.pg);await loadH()}
 else if(t.closest('#au-rs')){Object.assign(H,{q:'',user:'',cat:'',act:'',rng:'7',sid:'',hideView:true,page:0});await history()}
 else if(t.closest('#au-xl'))await exportXl();
 else if(t.closest('#au-vf'))await verify()}
 catch(x){console.error(x);if(window.toast)toast('خطا: '+x.message)}});
let tq;document.addEventListener('input',e=>{if(e.target.id!=='au-q')return;clearTimeout(tq);tq=setTimeout(()=>{H.q=e.target.value.trim();H.page=0;loadH()},350)});
document.addEventListener('change',e=>{const t=e.target,m={'au-u':'user','au-c':'cat','au-a':'act','au-r':'rng'}[t.id];
 if(m){H[m]=t.value;H.page=0;loadH()}else if(t.id==='au-hv'){H.hideView=t.checked;H.page=0;loadH()}});
window.Audit={start,stop,show,view,refresh,online:()=>ON.slice(),log:(a,d)=>window.App&&App.alog(a,d)};
})();
