// گزارش توقفات: نمودار دایره‌ای سهم دقیقه‌ی هر توقف + فهرست دقیقه‌ها + نمودار میله‌ای تعداد وقوع
// ورودی: ردیف‌های فیلترشده‌ی پنل (ردیف‌های داده برای توقفات برنامه‌ریزی‌شده، لاگ برای دلیل‌های پیش‌بینی‌نشده)
(function(){
const E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=(n,d=0)=>Number(n).toLocaleString('fa-IR',{maximumFractionDigits:d});
const PAL=['#ff7a2e','#2fd46a','#fbbf24','#38bdf8','#a78bfa','#f472b6','#34d399','#fb7185','#60a5fa','#f59e0b','#22d3ee','#c084fc'];
const colr=i=>'hsl('+Math.round((i*137.508)%360)+',68%,60%)',GRAY='#94a3b8',PLAN='#38bdf8',UNPL='#ff7a2e';
const PLANNED=[/^تعویض فویل/,/^تعویض PS/,/^صرف وعده/,/^نظافت دستگاه/];
const clean=h=>h.replace(/\s*\(.*?\)\s*/g,' ').replace(/\s+/g,' ').trim();
const num=v=>{const n=typeof v==='number'?v:parseFloat(String(v).replace(/[^\d.\-]/g,''));return isFinite(n)?n:0};
function collect(rows,ctx){const m=new Map(),add=(t,type,min)=>{const k=type+'|'+t;let x=m.get(k);if(!x)m.set(k,x={t,type,min:0,cnt:0});x.min+=min;x.cnt++};
 // توقفات برنامه‌ریزی‌شده: ستون‌های دقیقه‌ای ردیف داده
 const pc=ctx.head.filter(h=>PLANNED.some(re=>re.test(h)));
 for(const r of rows)for(const h of pc){const v=num(r.o[h]);if(v>0)add(clean(h),'p',v)}
 // توقفات پیش‌بینی‌نشده: لاگ دلایل توقف
 const lc=ctx.logCols||{};
 if(lc.reason)for(const r of ctx.log){const t=String(r.o[lc.reason]??'').trim();if(!t)continue;add(t,'u',lc.min?num(r.o[lc.min]):0)}
 return[...m.values()]}

// ===== جمع‌کردن ریزها در «سایر» + پاپ‌آپ جزئیات =====
const MORE={};let MID=0;
const OTHER_C='#94a3b8';
function mkOther(rest,all){const id='m'+(++MID);
 MORE[id]={list:rest,tm:all.reduce((a,x)=>a+x.min,0),tc:all.reduce((a,x)=>a+x.cnt,0)};
 return{t:'سایر ('+faN(rest.length)+' مورد)',type:'o',c:OTHER_C,min:rest.reduce((a,x)=>a+x.min,0),cnt:rest.reduce((a,x)=>a+x.cnt,0),rest:id}}
// نمودار دایره‌ای: برش‌های کوچک (زیر ۳٪) و بیش از ۸ برش در «سایر» جمع می‌شوند
function groupMin(items,total){const s=items.filter(x=>x.min>0).sort((a,b)=>b.min-a.min||b.cnt-a.cnt);let k=0;
 while(k<s.length&&(k<5||(k<8&&s[k].min/total>=.03)))k++;
 const rest=s.slice(k);if(rest.length<2)return s;return s.slice(0,k).concat([mkOther(rest,items)])}
// نمودار میله‌ای: N مورد اول + «سایر»
function groupCnt(items,n){const s=items.slice().sort((a,b)=>b.cnt-a.cnt||b.min-a.min);
 if(s.length<=n+1)return s;return s.slice(0,n).concat([mkOther(s.slice(n),items)])}
function morePop(id,mode){const m=MORE[id];if(!m)return;
 const L=m.list.slice().sort(mode==='cnt'?(a,b)=>b.cnt-a.cnt||b.min-a.min:(a,b)=>b.min-a.min||b.cnt-a.cnt);
 const sm=L.reduce((a,x)=>a+x.min,0),sc=L.reduce((a,x)=>a+x.cnt,0),pc=(a,b)=>b>0?faN(a/b*100,1)+'٪':'—';
 document.querySelectorAll('.sx-pop').forEach(x=>x.remove());
 const o=document.createElement('div');o.className='sx-pop';
 o.style.cssText='position:fixed;inset:0;z-index:6000;background:rgba(30,50,80,.38);display:grid;place-items:center;padding:16px';
 const rows=L.map((x,i)=>`<tr><td>${faN(i+1)}</td><td>${E(x.t)}</td><td><span class="badge ${x.type==='p'?'b-g':'b-o'}">${x.type==='p'?'برنامه‌ریزی‌شده':'پیش‌بینی‌نشده'}</span></td><td class="text-nowrap">${faN(x.min,1)}</td><td class="text-nowrap">${pc(x.min,m.tm)}</td><td>${faN(x.cnt)}</td><td class="text-nowrap">${pc(x.cnt,m.tc)}</td></tr>`).join('');
 o.innerHTML=`<div style="background:#fff;border:1px solid #d7e1ee;border-radius:16px;max-width:760px;width:100%;max-height:82vh;overflow:auto;padding:18px;color:#1f2d3d;box-shadow:0 30px 70px rgba(30,64,110,.28);direction:rtl">
  <div class="d-flex align-items-center mb-2"><b class="flex-fill">ریز موارد «سایر» <span class="small text-muted fw-normal">(${faN(L.length)} عنوان · ${faN(sm,1)} دقیقه = ${pc(sm,m.tm)} از کل · ${faN(sc)} بار = ${pc(sc,m.tc)} از کل وقوع)</span></b><button class="btn btn-sm btn-light" data-x>بستن</button></div>
  <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>#</th><th>عنوان توقف</th><th>نوع</th><th>دقیقه</th><th>٪ از کل دقیقه</th><th>تعداد</th><th>٪ از کل وقوع</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
 const close=()=>{o.remove();document.removeEventListener('keydown',kd)},kd=e=>{if(e.key==='Escape')close()};
 o.addEventListener('click',e=>{if(e.target===o||e.target.closest('[data-x]'))close()});document.addEventListener('keydown',kd);document.body.appendChild(o)}
document.addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('[data-more]');if(t)morePop(t.dataset.more,t.dataset.mode||'min')});
if(!document.getElementById('sx-more-css')){const st=document.createElement('style');st.id='sx-more-css';st.textContent='[data-more]{cursor:pointer}';document.head.appendChild(st)}
// ===================== نمودارهای سه‌بعدی =====================
let UID=0;
const q1=v=>+Number(v).toFixed(1);
function rgbOf(c){c=String(c).trim();let m;
 if(m=/^#([0-9a-f]{3})$/i.exec(c))return m[1].split('').map(h=>parseInt(h+h,16));
 if(m=/^#([0-9a-f]{6})$/i.exec(c))return[0,2,4].map(i=>parseInt(m[1].substr(i,2),16));
 if(m=/^hsl\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%/i.exec(c)){const h=+m[1]/360,s=+m[2]/100,l=+m[3]/100,Q=l<.5?l*(1+s):l+s-l*s,p=2*l-Q;
  const f=t=>{if(t<0)t+=1;if(t>1)t-=1;return t<1/6?p+(Q-p)*6*t:t<.5?Q:t<2/3?p+(Q-p)*(2/3-t)*6:p};return[f(h+1/3),f(h),f(h-1/3)].map(v=>Math.round(v*255))}
 return[120,140,170]}
// k<1 تیره‌تر، k>1 روشن‌تر
function tone(c,k){const[r,g,b]=rgbOf(c),f=v=>Math.max(0,Math.min(255,Math.round(k<1?v*k:v+(255-v)*(k-1))));return`rgb(${f(r)},${f(g)},${f(b)})`}
const gradDef=(id,c)=>`<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${tone(c,1.28)}"/><stop offset=".55" stop-color="${tone(c,1)}"/><stop offset="1" stop-color="${tone(c,.8)}"/></linearGradient>`;
// مکعب‌مستطیل سه‌بعدی: روبه‌رو + کناره + بالا (عمق: dx به راست، dy به بالا)
function cub(x,y,w,h,c,dx,dy,gid,top){
 x=q1(x);y=q1(y);w=q1(w);h=q1(h);if(h<=0)return'';
 return`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#${gid})"/><rect x="${q1(x+3)}" y="${q1(y+3)}" width="${q1(w*.16)}" height="${q1(Math.max(0,h-6))}" rx="2" fill="#fff" opacity=".22"/>`+
 `<polygon points="${q1(x+w)},${y} ${q1(x+w+dx)},${q1(y+dy)} ${q1(x+w+dx)},${q1(y+h+dy)} ${q1(x+w)},${q1(y+h)}" fill="${tone(c,.62)}"/>`+
 (top?`<polygon points="${x},${y} ${q1(x+dx)},${q1(y+dy)} ${q1(x+w+dx)},${q1(y+dy)} ${q1(x+w)},${y}" fill="${tone(c,1.38)}"/>`:'')}
// راهنمای شناور (tooltip) و برجسته شدن برش‌های دونات؛ فقط یک‌بار برای کل صفحه
if(!window.__ch3d){window.__ch3d=1;
 const tip=document.createElement('div');tip.className='ch-tip';tip.style.cssText='position:fixed;pointer-events:none;z-index:5000;display:none';document.body.appendChild(tip);
 let cur=null;
 const hot=(svg,i,on)=>svg.querySelectorAll('.pz[data-sl="'+i+'"]').forEach(e=>{e.style.translate=on?e.dataset.dx+'px '+e.dataset.dy+'px':'';e.classList.toggle('hot',on)});
 document.addEventListener('mousemove',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');
  if(t){tip.textContent=t.dataset.tip;tip.style.display='block';const w=tip.offsetWidth;let x=e.clientX+16;if(x+w>innerWidth-8)x=e.clientX-w-16;tip.style.left=x+'px';tip.style.top=(e.clientY+16)+'px'}else tip.style.display='none';
  const z=e.target.closest&&e.target.closest('.pz[data-sl]'),svg=z&&z.closest('svg'),key=z?z.dataset.sl:null;
  if(cur&&(cur.svg!==svg||cur.key!==key)){hot(cur.svg,cur.key,false);cur=null}
  if(z&&!cur){hot(svg,key,true);cur={svg,key}}})}

function pie(items,total){
 const sl=items.map((x,i)=>({t:x.t,min:x.min,c:x.c||colr(i),rest:x.rest}));
 const id='p'+(++UID),R=118,r=66,K=.54,D=22,cx=290,W=580,H=Math.max(300,16*Math.ceil(sl.length/2)+60)+D+16,cy=(H-D)/2-2,ry=q1(R*K),rr=q1(r*K);
 const P=(R_,a,dd=0)=>[q1(cx+R_*Math.cos(a)),q1(cy+K*R_*Math.sin(a)+dd)];
 const wall=(R_,s,e,dd)=>{const[a,b]=P(R_,s),[c,d]=P(R_,e),y=q1(R_*K);return`M${a},${b} A${R_},${y} 0 0 1 ${c},${d} L${c},${q1(d+dd)} A${R_},${y} 0 0 0 ${a},${q1(b+dd)}Z`};
 let a0=-Math.PI/2,defs='',outer='',inner='',tops='',lab=[],i=0;
 for(const s of sl){const f=Math.min(.9999,s.min/total),a1=a0+f*2*Math.PI,am=(a0+a1)/2,lg=f>.5?1:0,mx=q1(Math.cos(am)*12),my=q1(Math.sin(am)*12*K);
  const gid=id+'g'+i,at=`class="pz" data-sl="${i}" data-dx="${mx}" data-dy="${my}" style="--i:${i}"`,tip=`${E(s.t)}: ${faN(s.min,1)} دقیقه (${faN(f*100,1)}٪)${s.rest?' — برای دیدن ریز کلیک کنید':''}`;
  defs+=gradDef(gid,s.c);
  const o0=Math.max(a0,0),o1=Math.min(a1,Math.PI);if(o0<o1)outer+=`<path ${at} d="${wall(R,o0,o1,D)}" fill="${tone(s.c,.6)}"/>`;
  for(const[lo,hi]of[[-Math.PI,0],[Math.PI,2*Math.PI]]){const u0=Math.max(a0,lo),u1=Math.min(a1,hi);if(u0<u1)inner+=`<path ${at} d="${wall(r,u0,u1,D)}" fill="${tone(s.c,.48)}"/>`}
  const[x0,y0]=P(R,a0),[x1,y1]=P(R,a1),[x2,y2]=P(r,a1),[x3,y3]=P(r,a0);
  tops+=`<path ${at}${s.rest?` data-more="${s.rest}" data-mode="min"`:''} data-tip="${tip}" d="M${x0},${y0} A${R},${ry} 0 ${lg} 1 ${x1},${y1} L${x2},${y2} A${r},${rr} 0 ${lg} 0 ${x3},${y3}Z" fill="url(#${gid})" stroke="#fff" stroke-width="1.2" stroke-opacity=".9"/>`;
  lab.push({s,f,am,i,right:Math.cos(am)>=0});a0=a1;i++}
 // برچسب عنوان بیرون هر برش، با خط راهنما؛ در هر سمت فاصله‌ی عمودی حداقل ۱۵ حفظ می‌شود
 let lh='';
 for(const side of [true,false]){const L=lab.filter(x=>x.right===side).map(x=>({...x,y:cy+K*(R+22)*Math.sin(x.am)+(Math.sin(x.am)>0?D*.6:0)})).sort((p,q)=>p.y-q.y);
  for(let k=1;k<L.length;k++)if(L[k].y-L[k-1].y<15)L[k].y=L[k-1].y+15;
  const over=L.length?L[L.length-1].y-(H-10):0;if(over>0)L.forEach(x=>x.y-=over);
  for(const x of L){const dd=Math.sin(x.am)>0?D*.5:0,[px,py]=P(R,x.am,dd),[ex,ey]=P(R+12,x.am,dd),tx=cx+(side?1:-1)*(R+34),t=x.s.t.length>24?x.s.t.slice(0,23)+'…':x.s.t;
   lh+=`<g class="pl"${x.s.rest?` data-more="${x.s.rest}" data-mode="min"`:''} style="--i:${x.i}"><polyline points="${px},${py} ${ex},${ey} ${tx-(side?6:-6)},${q1(x.y)}" fill="none" stroke="${x.s.c}" stroke-width="1.4"/><circle cx="${px}" cy="${py}" r="2.6" fill="${x.s.c}"/><text x="${tx}" y="${q1(x.y+4)}" text-anchor="${side?'start':'end'}" fill="#1f2d3d" font-size="12">\u202B${E(t)}\u202C <tspan fill="#64748b">\u202B${faN(x.f*100,1)}٪\u202C</tspan></text></g>`}}
 const ell=(a,b)=>`M${cx-a},${cy} A${a},${b} 0 1 0 ${cx+a},${cy} A${a},${b} 0 1 0 ${cx-a},${cy}Z`;
 defs+=`<filter id="${id}b" x="-20%" y="-40%" width="140%" height="180%"><feGaussianBlur stdDeviation="9"/></filter><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".16"/></linearGradient>`;
 return`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:${W}px;direction:ltr" role="img" aria-label="سهم دقیقه‌ای توقفات"><defs>${defs}</defs>
 <ellipse cx="${cx}" cy="${q1(cy+D+12)}" rx="${R+8}" ry="${q1(R*K+8)}" fill="#0f2a4a" opacity=".2" filter="url(#${id}b)"/>${inner}${outer}${tops}
 <path d="${ell(R,ry)} ${ell(r,rr)}" fill="url(#${id}s)" fill-rule="evenodd" pointer-events="none"/>${lh}
 <text class="pl" style="--i:0" x="${cx}" y="${q1(cy+11)}" text-anchor="middle" fill="#1f2d3d" font-size="21" font-weight="800">${faN(total)}</text><text class="pl" style="--i:0" x="${cx}" y="${q1(cy+27)}" text-anchor="middle" fill="#64748b" font-size="11">دقیقه توقف</text></svg>`}

function totalBar(items){
 const p=items.filter(x=>x.type==='p').reduce((a,x)=>a+x.cnt,0),u=items.filter(x=>x.type==='u').reduce((a,x)=>a+x.cnt,0),t=p+u,T=44,H=226,bw=78,W=200,L=44,dx=22,dy=-14,
  step=(()=>{for(const k of [1,2,5,10,20,50,100,200,500,1000,2000,5000])if(t/k<=5)return k;return 10000})(),ymax=Math.max(step,Math.ceil(t/step)*step),y=v=>T+H-(v/ymax)*H,y0=T+H,id='t'+(++UID);
 let g='',defs=gradDef(id+'p',PLAN)+gradDef(id+'u',UNPL);
 for(let v=0;v<=ymax;v+=step)g+=`<line x1="${L}" x2="${W}" y1="${q1(y(v))}" y2="${q1(y(v))}" stroke="rgba(30,64,110,.12)"/><text x="${L-6}" y="${q1(y(v)+4)}" text-anchor="end" fill="#64748b" font-size="11">${faN(v)}</text>`;
 const bx=L+(W-L-bw-dx)/2;
 g+=`<polygon points="${L},${y0} ${W-dx},${y0} ${W},${y0+dy} ${L+dx},${y0+dy}" fill="#dbe6f3"/><rect x="${L}" y="${y0}" width="${W-dx-L}" height="9" fill="#b9c9dc"/>`;
 if(p>0)g+=`<g class="b3" style="--i:0;transform-origin:${q1(bx+bw/2)}px ${y0}px" data-tip="برنامه‌ریزی‌شده: ${faN(p)}">${cub(bx,y(p),bw,y0-y(p),PLAN,dx,dy,id+'p',u<=0)}</g>`;
 if(u>0)g+=`<g class="b3" style="--i:2;transform-origin:${q1(bx+bw/2)}px ${q1(y(p))}px" data-tip="پیش‌بینی‌نشده: ${faN(u)}">${cub(bx,y(t),bw,y(p)-y(t),UNPL,dx,dy,id+'u',true)}</g>`;
 g+=`<text class="bl" style="--i:3;--h:${q1(y0-y(t))}px" x="${q1(bx+(bw+dx)/2)}" y="${q1(y(t)+dy-8)}" text-anchor="middle" fill="#1f2d3d" font-size="16" font-weight="700">${faN(t)}</text><text class="bn" x="${q1(bx+(bw+dx)/2)}" y="${y0+28}" text-anchor="middle" fill="#475569" font-size="12">کل توقفات</text>`;
 return`<svg viewBox="0 0 ${W} ${T+H+38}" style="width:100%;max-width:240px;direction:ltr" role="img" aria-label="تعداد کل توقفات"><defs>${defs}</defs>${g}</svg><div class="small text-muted">برنامه‌ریزی‌شده ${faN(p)} · پیش‌بینی‌نشده ${faN(u)}</div>`}

function bars(items,limit){
 const l=items.slice().sort((a,b)=>(a.rest?1:0)-(b.rest?1:0)||b.cnt-a.cnt||b.min-a.min).slice(0,limit),mx=Math.max(1,...l.map(x=>x.cnt));
 let step=1;for(const k of [1,2,5,10,20,50,100,200,500,1000]){step=k;if(mx/k<=5)break}
 const id='b'+(++UID),dx=9,dy=-8,bw=34,gap=16,L=46,T=28,plotH=230,B=150,W=Math.max(L+l.length*(bw+gap)+14,320),ymax=Math.ceil(mx/step)*step,y=v=>T+plotH-(v/ymax)*plotH,y0=T+plotH;
 let g='',defs='';for(let v=0;v<=ymax;v+=step)g+=`<line x1="${L}" x2="${W}" y1="${q1(y(v))}" y2="${q1(y(v))}" stroke="rgba(30,64,110,.12)"/><text x="${L-6}" y="${q1(y(v)+4)}" text-anchor="end" fill="#64748b" font-size="11">${faN(v)}</text>`;
 g+=`<polygon points="${L},${y0} ${W-dx},${y0} ${W},${y0+dy} ${L+dx},${y0+dy}" fill="#dbe6f3"/><rect x="${L}" y="${y0}" width="${W-dx-L}" height="9" fill="#b9c9dc"/>`;
 // اولین (بیشترین) میله سمت راست، مناسب جهت راست‌به‌چپ
 l.forEach((x,i)=>{const bx=W-10-(i+1)*(bw+gap)+gap,by=y(x.cnt),col=x.c||(x.type==='p'?PLAN:UNPL),lbl=x.t.length>22?x.t.slice(0,21)+'…':x.t,gid=id+'g'+i;
  defs+=gradDef(gid,col);
  g+=`<g class="b3"${x.rest?` data-more="${x.rest}" data-mode="cnt"`:''} style="--i:${i};transform-origin:${q1(bx+bw/2)}px ${y0}px" data-tip="${E(x.t)}: ${faN(x.cnt)} بار · ${faN(x.min,1)} دقیقه${x.rest?' — برای دیدن ریز کلیک کنید':''}">${cub(bx,by,bw,y0-by,col,dx,dy,gid,true)}</g>
   <text class="bl" style="--i:${i};--h:${q1(y0-by)}px" x="${q1(bx+(bw+dx)/2)}" y="${q1(by+dy-6)}" text-anchor="middle" fill="#1f2d3d" font-size="11.5" font-weight="700">${faN(x.cnt)}</text>
   <text class="bn"${x.rest?` data-more="${x.rest}" data-mode="cnt"`:''} transform="translate(${q1(bx+bw/2+4)},${y0+22}) rotate(-90)" text-anchor="end" fill="#475569" font-size="11.5">${E(lbl)}</text>`});
 return`<div style="overflow-x:auto;direction:ltr"><svg viewBox="0 0 ${W} ${T+plotH+B}" width="${W}" height="${T+plotH+B}" style="min-width:100%" role="img" aria-label="تعداد وقوع توقفات"><defs>${defs}</defs>${g}</svg></div>`}
function render(body,rows,ctx){
 const items=collect(rows,ctx).sort((a,b)=>b.min-a.min||b.cnt-a.cnt),total=items.reduce((a,x)=>a+x.min,0);
 if(!items.length){body.innerHTML='<div class="text-muted">با فیلترهای فعلی توقفی پیدا نشد.</div>';return}
 const st={lim:10};
 const paint=()=>{
  Object.keys(MORE).forEach(k=>delete MORE[k]);
  const gp=total>0?groupMin(items,total):[],gb=st.lim===999?items:groupCnt(items,st.lim),inTop=new Set(gp.filter(x=>!x.rest));
  const list=items.map((x,i)=>`<tr><td><span class="dot" style="background:${x.min>0&&inTop.has(x)?colr(items.indexOf(x)):GRAY}"></span>${E(x.t)}</td>
   <td><span class="badge ${x.type==='p'?'b-g':'b-o'}">${x.type==='p'?'برنامه‌ریزی‌شده':'پیش‌بینی‌نشده'}</span></td><td class="text-nowrap">${faN(x.min,1)}</td><td class="text-nowrap">${total?faN(x.min/total*100,1):'۰'}٪</td><td>${faN(x.cnt)}</td></tr>`).join('');
  body.innerHTML=`<div class="row g-3"><div class="col-12 col-lg-7 text-center"><div class="fw-bold mb-2">سهم دقیقه‌ای هر توقف از کل توقفات</div>${total>0?pie(gp,total):'<div class="text-muted">دقیقه‌ای ثبت نشده</div>'}${gp.some(x=>x.rest)?'<div class="small text-muted"><i class="fa-solid fa-hand-pointer"></i> برش‌های کوچک در «سایر» جمع شده‌اند؛ روی آن بزنید تا ریز موارد در پاپ‌آپ باز شود.</div>':''}</div>
   <div class="col-12 col-lg-5"><div class="fw-bold mb-2">مدت هر توقف <span class="small text-muted fw-normal">(مجموع ${faN(total)} دقیقه · ${faN(items.length)} عنوان)</span></div>
    <div class="table-responsive" style="max-height:290px;overflow:auto"><table class="table table-sm align-middle mb-0"><thead><tr><th>عنوان توقف</th><th>نوع</th><th>دقیقه</th><th>درصد</th><th>تعداد</th></tr></thead><tbody>${list}</tbody></table></div></div></div>
   <hr><div class="row g-3"><div class="col-12 col-lg-3 text-center"><div class="fw-bold mb-2">تعداد کل توقفات</div>${totalBar(items)}</div>
   <div class="col-12 col-lg-9"><div class="d-flex align-items-center flex-wrap gap-2 mb-2"><div class="fw-bold">تعداد وقوع هر توقف</div>
    <span class="small"><span class="dot" style="background:${PLAN}"></span>برنامه‌ریزی‌شده <span class="dot ms-2" style="background:${UNPL}"></span>پیش‌بینی‌نشده</span>
    <span class="ms-auto d-flex gap-2"><button class="chip ${st.lim===10?'on':''}" data-lim="10">۱۰ مورد اول + سایر</button><button class="chip ${st.lim===999?'on':''}" data-lim="999">همه (${faN(items.length)})</button></span></div>
   ${bars(gb,999)}${gb.some(x=>x.rest)?'<div class="small text-muted"><i class="fa-solid fa-hand-pointer"></i> روی میله‌ی «سایر» بزنید تا ریز آن دیده شود.</div>':''}</div></div>
   <div class="small text-muted mt-2">توقفات پیش‌بینی‌نشده از لاگ همه‌ی فایل‌های توقفات جمع می‌شود و با همان فیلترها (تاریخ، ماه، محصول، تجهیز، جستجو) هماهنگ است. «تعداد» برای توقفات برنامه‌ریزی‌شده = تعداد ردیف‌هایی است که آن توقف در آن‌ها ثبت شده.</div>`;
  body.querySelectorAll('[data-lim]').forEach(b=>b.onclick=()=>{st.lim=+b.dataset.lim;paint()})};
 paint()}
Reports.register({id:'stops-mix',cats:['stops'],title:'توقفات: سهم دقیقه‌ای و تعداد وقوع',icon:'fa-chart-pie',render});

// ===== نمودار روند: محور افقی = ماه، محور عمودی = تعداد (یا دقیقه) هر توقف؛ هر عنوان یک خط نقطه‌دار =====
const TS={shown:null,metric:'cnt',q:''},LSK='stopsTrendSel.v1';
// انتخاب کاربر روی نمودار روند در مرورگر ذخیره می‌شود تا با رفرش/ورود دوباره، موارد پیش‌فرض خودشان تیک نخورند
try{const j=JSON.parse(localStorage.getItem(LSK)||'null');if(j&&Array.isArray(j.shown)){TS.shown=new Set(j.shown);if(j.metric==='min'||j.metric==='cnt')TS.metric=j.metric}}catch(e){}
const saveTS=()=>{try{localStorage.setItem(LSK,JSON.stringify({shown:[...TS.shown],metric:TS.metric}))}catch(e){}};
function trendData(rows,ctx){
 const S=new Map(),yms=new Set();let skipped=0;
 const add=(t,type,r,min)=>{if(!r.d){skipped++;return}const ym=Math.floor(r.d/100);yms.add(ym);const k=type+'|'+t;let x=S.get(k);if(!x)S.set(k,x={k,t,type,by:new Map(),cnt:0,min:0});
  const b=x.by.get(ym)||{cnt:0,min:0};b.cnt++;b.min+=min;x.by.set(ym,b);x.cnt++;x.min+=min};
 const pc=ctx.head.filter(h=>PLANNED.some(re=>re.test(h)));
 for(const r of rows)for(const h of pc){const v=num(r.o[h]);if(v>0)add(clean(h),'p',r,v)}
 const lc=ctx.logCols||{};
 if(lc.reason)for(const r of ctx.log){const t=String(r.o[lc.reason]??'').trim();if(t)add(t,'u',r,lc.min?num(r.o[lc.min]):0)}
 const months=[];if(yms.size){let a=Math.min(...yms),b=Math.max(...yms);while(a<=b){months.push(a);a=a%100===12?(Math.floor(a/100)+1)*100+1:a+1}}
 return{S,months,skipped}}
function renderTrend(body,rows,ctx){
 const D=trendData(rows,ctx),MN=ctx.months,order=collect(rows,ctx).sort((a,b)=>b.min-a.min||b.cnt-a.cnt),ci=new Map(order.map((x,i)=>[x.type+'|'+x.t,i]));
 const all=[...D.S.values()].sort((a,b)=>b.cnt-a.cnt||b.min-a.min);
 if(!all.length){body.innerHTML='<div class="text-muted">با فیلترهای فعلی توقفی با تاریخ پیدا نشد.</div>';return}
 const keys=new Set(all.map(x=>x.k));
 if(!TS.shown)TS.shown=new Set(all.slice(0,5).map(x=>x.k));      // پیش‌فرض: ۵ توقف پرتکرار
 const unit=()=>TS.metric==='cnt'?'بار':'دقیقه',val=b=>b?(TS.metric==='cnt'?b.cnt:b.min):0;
 const mlab=ym=>MN[ym%100-1]+' '+faN(Math.floor(ym/100)).replace(/٬/g,'');
 body.innerHTML=`<div class="d-flex flex-wrap gap-2 align-items-center mb-2"><span class="small text-muted">محور عمودی:</span>
   <button class="chip" data-m="cnt">تعداد توقف</button><button class="chip" data-m="min">دقیقه‌ی توقف</button><span class="small text-muted ms-auto" id="tr-n"></span></div>
  <div id="tr-chart" style="overflow-x:auto;direction:ltr;overflow-anchor:none;min-height:400px"></div>
  <hr><div class="d-flex flex-wrap gap-2 align-items-center mb-2"><b>کدام توقف‌ها روی نمودار باشند؟</b>
   <button class="chip" data-pre="all">همه</button><button class="chip" data-pre="none">هیچ‌کدام</button><button class="chip" data-pre="top5">۵ پرتکرار</button><button class="chip" data-pre="p">فقط برنامه‌ریزی‌شده</button><button class="chip" data-pre="u">فقط پیش‌بینی‌نشده</button>
   <input class="form-control form-control-sm ms-auto" id="tr-q" style="max-width:220px" placeholder="جستجوی عنوان…" value="${E(TS.q)}"></div>
  <div class="tr-leg">${all.map(x=>`<label class="d-flex gap-2 align-items-center py-1" data-ttl="${E(x.t)}"><input type="checkbox" data-k="${E(x.k)}"><span class="dot" style="background:${colr(ci.get(x.k)??0)}"></span><span class="flex-fill">${E(x.t)}</span><span class="badge ${x.type==='p'?'b-g':'b-o'}">${x.type==='p'?'برنامه‌ریزی‌شده':'پیش‌بینی‌نشده'}</span><span class="small text-muted" style="min-width:34px;text-align:left">${faN(x.cnt)}</span></label>`).join('')}</div>
  <div class="small text-muted mt-2">هر نقطه = مجموع آن توقف در همان ماه (با فیلترهای بالای صفحه هماهنگ است). ماه‌های بدون توقف داخل بازه با مقدار صفر نشان داده می‌شوند، قدیمی‌ترین ماه سمت راست است.${D.skipped?` ${faN(D.skipped)} ثبت بدون تاریخ نمایش داده نشد.`:''}</div>`;
 const draw=()=>{
  const vis=all.filter(x=>TS.shown.has(x.k)),n=D.months.length,L=54,Rp=34,T=24,H=300,B=58,cw=body.querySelector('#tr-chart').clientWidth||900,PW=Math.max(560,n*96,cw-L-Rp-4),W=L+PW+Rp;
  body.querySelector('#tr-n').textContent=faN(vis.length)+' از '+faN(all.length)+' توقف روی نمودار';
  body.querySelectorAll('[data-m]').forEach(b=>b.classList.toggle('on',b.dataset.m===TS.metric));
  body.querySelectorAll('.tr-leg input').forEach(c=>c.checked=TS.shown.has(c.dataset.k));
  if(!vis.length){body.querySelector('#tr-chart').innerHTML='<div class="text-muted py-5 text-center" style="direction:rtl">هیچ توقفی انتخاب نشده؛ از فهرست پایین انتخاب کنید.</div>';return}
  let mx=1;for(const x of vis)for(const ym of D.months)mx=Math.max(mx,val(x.by.get(ym)));
  let step=1;for(const k of [1,2,5,10,20,50,100,200,500,1000,2000,5000,10000])if(mx/(step=k)<=6)break;
  const ymax=Math.ceil(mx/step)*step,y=v=>T+H-(v/ymax)*H,xi=i=>n===1?L+PW/2:W-Rp-i*((PW-Rp)/(n-1));
  let g='';for(let v=0;v<=ymax;v+=step)g+=`<line x1="${L}" x2="${W-Rp+10}" y1="${y(v)}" y2="${y(v)}" stroke="rgba(30,64,110,.12)"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="#64748b" font-size="11">${faN(v)}</text>`;
  D.months.forEach((ym,i)=>{g+=`<line x1="${xi(i)}" x2="${xi(i)}" y1="${T}" y2="${T+H}" stroke="rgba(30,64,110,.07)"/><text x="${xi(i)}" y="${T+H+20}" text-anchor="middle" fill="#475569" font-size="12">‫${E(mlab(ym))}‬</text>`});
  const lab=vis.length<=2,uid='t'+(++UID);let defs=`<filter id="${uid}b" x="-10%" y="-30%" width="120%" height="170%"><feGaussianBlur stdDeviation="4"/></filter><linearGradient id="${uid}pl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef4fb"/><stop offset="1" stop-color="#fff"/></linearGradient>`;
  let sh='',ar='',dp='',mn='',dt='';
  g=`<rect x="${L}" y="${T}" width="${W-Rp+10-L}" height="${H}" rx="8" fill="url(#${uid}pl)"/>`+g;
  vis.forEach((x,si)=>{const c=colr(ci.get(x.k)??0),pts=D.months.map((ym,i)=>[q1(xi(i)),q1(y(val(x.by.get(ym)))),val(x.by.get(ym)),ym]),
   d='M'+pts.map(p=>p[0]+','+p[1]).join(' L'),dl=si*160;
   defs+=`<linearGradient id="${uid}a${si}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c}" stop-opacity=".32"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></linearGradient>`;
   if(vis.length<=3&&pts.length>1)ar+=`<path class="ln-a" style="animation-delay:${dl+700}ms" d="${d} L${pts[pts.length-1][0]},${T+H} L${pts[0][0]},${T+H}Z" fill="url(#${uid}a${si})"/>`;
   sh+=`<path class="ln-d" pathLength="1" style="animation-delay:${dl}ms" d="${d}" transform="translate(7,16)" fill="none" stroke="#0f2a4a" stroke-opacity=".28" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" filter="url(#${uid}b)"/>`;
   dp+=`<path class="ln-d" pathLength="1" style="animation-delay:${dl}ms" d="${d}" transform="translate(4,6)" fill="none" stroke="${tone(c,.55)}" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round"/>`;
   mn+=`<path class="ln-d" pathLength="1" style="animation-delay:${dl}ms" d="${d}" fill="none" stroke="${c}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>`;
   pts.forEach((p,i)=>{dt+=`<circle class="ln-p" style="animation-delay:${dl+500+i*70}ms" cx="${p[0]}" cy="${p[1]}" r="5.5" fill="${c}" stroke="#fff" stroke-width="2" data-tip="${E(x.t)} — ${E(mlab(p[3]))}: ${faN(p[2],1)} ${unit()}"/>${lab?`<text class="ln-t" style="animation-delay:${dl+700+i*70}ms" x="${p[0]}" y="${p[1]-12}" text-anchor="middle" fill="#1f2d3d" font-size="11.5" font-weight="700">${faN(p[2],1)}</text>`:''}`})});
  g+=sh+ar+dp+mn+dt;
  body.querySelector('#tr-chart').innerHTML=`<svg viewBox="0 0 ${W} ${T+H+B}" width="${W}" height="${T+H+B}" style="display:block" role="img" aria-label="روند ماهانه توقفات"><defs>${defs}</defs>${g}<text x="12" y="${T-8}" fill="#64748b" font-size="11" transform="rotate(0)">${TS.metric==='cnt'?'تعداد':'دقیقه'}</text></svg>`};
 const chart=()=>{const bx=body.querySelector('#tr-chart'),sx=window.scrollX,sy=window.scrollY,sl=bx.scrollLeft;draw();bx.scrollLeft=sl;window.scrollTo({left:sx,top:sy,behavior:'instant'})};
 body.onclick=e=>{const m=e.target.closest('[data-m]'),p=e.target.closest('[data-pre]');
  if(m){TS.metric=m.dataset.m;saveTS();chart()}
  else if(p){const k=p.dataset.pre;TS.shown=new Set(k==='all'?all.map(x=>x.k):k==='none'?[]:k==='top5'?all.slice(0,5).map(x=>x.k):all.filter(x=>x.type===k).map(x=>x.k));saveTS();chart()}};
 body.onchange=e=>{const c=e.target.closest('.tr-leg input');if(!c)return;c.checked?TS.shown.add(c.dataset.k):TS.shown.delete(c.dataset.k);saveTS();chart()};
 body.querySelector('#tr-q').oninput=e=>{TS.q=e.target.value;const q=TS.q.trim();body.querySelectorAll('.tr-leg label').forEach(l=>l.classList.toggle('d-none',!!q&&!l.dataset.ttl.includes(q)))};
 body.querySelector('#tr-q').dispatchEvent(new Event('input'));
 chart()}
Reports.register({id:'stops-trend',cats:['stops'],title:'روند ماهانه‌ی توقفات (قابل فیلتر روی نمودار)',icon:'fa-chart-line',render:renderTrend});
window.StopsWidgets={renderTrend,renderMix:render,pie,bars,colr,GRAY,PLAN,UNPL};
})();
