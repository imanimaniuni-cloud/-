// گزارش‌های تکمیلی توقفات:
//  ۱) فهرست جمع‌شونده‌ی عناوین دلایل توقف + توضیح هر کدام   ۲) فهرست فراوانی توقفات
//  ۳) مجموع توقفات و زمان توقف نسبت به کارکرد تجهیز (با درصد)   ۴) زمان توقف نسبت به تولید از دست رفته (درصد زمان و کیلوگرم)
// ستون‌ها خودکار حدس زده می‌شوند و از بخش «تنظیم ستون‌ها» در هر گزارش قابل تغییرند (در مرورگر ذخیره می‌شود).
(function(){
const E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=(n,d=0)=>Number(n).toLocaleString('fa-IR',{maximumFractionDigits:d});
const pct=(a,b)=>b>0?faN(a/b*100,1)+'٪':'—';
const colr=i=>'hsl('+Math.round((i*137.508)%360)+',68%,60%)';
const PLANNED=[/^تعویض فویل/,/^تعویض PS/,/^صرف وعده/,/^نظافت دستگاه/];
const clean=h=>h.replace(/\s*\(.*?\)\s*/g,' ').replace(/\s+/g,' ').trim();
const num=v=>{const n=typeof v==='number'?v:parseFloat(String(v).replace(/[^\d.\-]/g,''));return isFinite(n)?n:0};
// زمان به‌صورت «ساعت:دقیقه» (مثل 7:12 یا 30:15:00) → دقیقه؛ عدد ساده بر اساس واحد انتخابی (ساعت/دقیقه)
const runMin=(v,unit)=>{if(v==null||v==='')return 0;if(typeof v==='string'){const m=/^\s*(\d+):(\d{1,2})(?::(\d{1,2}))?\s*$/.exec(v);if(m)return +m[1]*60+ +m[2]+(m[3]?+m[3]/60:0)}
 const n=num(v);return unit==='h'?n*60:n};
const LSC='stopsCols.v1',LSD='stopsDesc.v1';
const ld=k=>{try{return JSON.parse(localStorage.getItem(k)||'{}')||{}}catch(e){return{}}};
const sv=(k,o)=>{try{localStorage.setItem(k,JSON.stringify(o))}catch(e){}};
let CFG=ld(LSC),DESC=ld(LSD);
const logKeys=ctx=>{const s=new Set();for(const r of ctx.log.slice(0,300))Object.keys(r.o).forEach(k=>s.add(k));return[...s]};
const getCol=(k,list,guess)=>{const v=CFG[k];if(v==='')return null;if(v&&list.includes(v))return v;return guess()||null};

function aggregate(rows,ctx){
 const keys=logKeys(ctx),lc=ctx.logCols||{};
 const runC=getCol('run',ctx.head,()=>ctx.head.find(h=>/^زمان کارکرد/.test(h)&&!/فقط/.test(h))||ctx.head.find(h=>/^زمان کارکرد/.test(h)));
 const kgC0=getCol('kg',keys,()=>keys.find(h=>/(کیلو|kg)/i.test(h))||keys.find(h=>/تولید/.test(h)&&h!==lc.min));
 const kgC=kgC0&&kgC0!==lc.min&&kgC0!==lc.reason?kgC0:null;
 const dsC=getCol('desc',keys,()=>keys.find(h=>h!==lc.reason&&/^(توضیح|شرح|علت|ملاحظات)/.test(h)));
 const unit=CFG.runUnit||(runC&&/دقیقه/.test(runC)?'min':'h');
 const idC=ctx.cols&&ctx.cols.id,rtC=ctx.cols&&ctx.cols.rate,lid=lc.id;let rate=null;
 if(!kgC&&idC&&rtC&&lid){rate=new Map();for(const r of(ctx.all||rows)){const k=r.o[idC],v=num(r.o[rtC]);if(k!=null&&k!==''&&v>0)rate.set(String(k),v)}}
 const items=new Map(),eqs=new Map();
 const I=(t,type)=>{const k=type+'|'+t;let x=items.get(k);if(!x)items.set(k,x={t,type,min:0,cnt:0,kg:0,desc:new Map()});return x};
 const Q=e=>{e=e||'(نامشخص)';let x=eqs.get(e);if(!x)eqs.set(e,x={eq:e,run:0,pmin:0,pcnt:0,umin:0,ucnt:0});return x};
 const pc=ctx.head.filter(h=>PLANNED.some(re=>re.test(h)));
 for(const r of rows){const q=Q(r.e);if(runC)q.run+=runMin(r.o[runC],unit);
  for(const h of pc){const v=num(r.o[h]);if(v>0){const x=I(clean(h),'p');x.min+=v;x.cnt++;q.pmin+=v;q.pcnt++}}}
 if(lc.reason)for(const r of ctx.log){const t=String(r.o[lc.reason]??'').trim();if(!t)continue;
  const m=lc.min?num(r.o[lc.min]):0,x=I(t,'u'),q=Q(r.e);x.min+=m;x.cnt++;q.umin+=m;q.ucnt++;
  if(kgC)x.kg+=num(r.o[kgC]);else if(rate){const v=rate.get(String(r.o[lid]));if(v)x.kg+=m*v}
  if(dsC){const d=String(r.o[dsC]??'').trim();if(d)x.desc.set(d,(x.desc.get(d)||0)+1)}}
 return{items:[...items.values()],eqs:[...eqs.values()],runC,kgC,kgDerived:!kgC&&!!rate,dsC,unit,keys,head:ctx.head,lc}}
window.StopsAgg={aggregate,runMin,num,PLANNED,clean};

const sel=(k,label,list,cur,extra)=>`<label class="small d-flex align-items-center gap-2">${label}<select class="form-select form-select-sm" style="max-width:260px" data-sx-cfg="${k}"><option value="">— هیچ‌کدام —</option>${list.map(h=>`<option value="${E(h)}" ${h===cur?'selected':''}>${E(h)}</option>`).join('')}</select></label>${extra||''}`;
const cfgBox=inner=>`<details class="mt-2"><summary class="small text-muted" style="cursor:pointer"><i class="fa-solid fa-sliders"></i> تنظیم ستون‌ها</summary><div class="d-flex flex-wrap gap-3 mt-2">${inner}</div></details>`;
const tbl=(th,body,foot)=>`<div class="table-responsive" style="max-height:380px;overflow:auto"><table class="table table-sm align-middle mb-0"><thead><tr>${th.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${body}</tbody>${foot?`<tfoot>${foot}</tfoot>`:''}</table></div>`;
const badge=t=>`<span class="badge ${t==='p'?'b-g':'b-o'}">${t==='p'?'برنامه‌ریزی‌شده':'پیش‌بینی‌نشده'}</span>`;

function mk(id,title,icon,draw,after){
 Reports.register({id,cats:['stops'],collapse:true,title,icon,render(body,rows,ctx){
  const paint=()=>{const a=aggregate(rows,ctx);if(!a.items.length&&!a.eqs.length){body.innerHTML='<div class="text-muted">با فیلترهای فعلی توقفی پیدا نشد.</div>';return}body.innerHTML=draw(a)};
  body.addEventListener('change',e=>{const s=e.target.closest('[data-sx-cfg]');if(!s)return;CFG[s.dataset.sxCfg]=s.value;sv(LSC,CFG);window.dispatchEvent(new Event('stops-cfg'))});
  if(after)body.addEventListener('input',e=>after(e));
  const on=()=>{if(!body.isConnected){window.removeEventListener('stops-cfg',on);return}paint()};
  window.addEventListener('stops-cfg',on);
  body.addEventListener('click',e=>{const t=e.target.closest('[data-sx-p]');if(t){try{popup(t.dataset.sxN,JSON.parse(t.dataset.sxP))}catch(x){console.error(x)}}});
  paint()}})}

// ۱) دلایل توقف؛ با کلیک روی هر عنوان، توضیحات ثبت‌شده در لاگ در یک پاپ‌آپ نمایش داده می‌شود
function popup(title,list){
 document.querySelectorAll('.sx-pop').forEach(x=>x.remove());
 const o=document.createElement('div');o.className='sx-pop';
 o.style.cssText='position:fixed;inset:0;z-index:3000;background:rgba(30,50,80,.38);display:grid;place-items:center;padding:16px';
 o.innerHTML=`<div style="background:#ffffff;border:1px solid #d7e1ee;border-radius:16px;max-width:560px;width:100%;max-height:80vh;overflow:auto;padding:18px;color:#1f2d3d;box-shadow:0 30px 70px rgba(30,64,110,.28)">
  <div class="d-flex align-items-center mb-2"><b class="flex-fill">${E(title)}</b><button class="btn btn-sm btn-light" data-x>بستن</button></div>
  ${list.length?`<div class="small text-muted mb-2">${faN(list.length)} توضیح ثبت‌شده در لاگ</div>`+list.map(([d,c])=>`<div class="py-2" style="border-top:1px solid #e5ecf5">${E(d)}${c>1?` <span class="badge bg-secondary">${faN(c)} بار</span>`:''}</div>`).join(''):'<div class="text-muted">برای این عنوان توضیحی در لاگ ثبت نشده است.</div>'}</div>`;
 const close=()=>{o.remove();document.removeEventListener('keydown',kd)},kd=e=>{if(e.key==='Escape')close()};
 o.addEventListener('click',e=>{if(e.target===o||e.target.closest('[data-x]'))close()});document.addEventListener('keydown',kd);document.body.appendChild(o)}
mk('stops-reasons','عناوین دلایل توقف و توضیح آنها','fa-list-ul',a=>{
 const l=a.items.slice().sort((x,y)=>(x.type<y.type?1:x.type>y.type?-1:0)||y.min-x.min);
 const rowsH=l.map((x,i)=>{const ds=JSON.stringify([...x.desc.entries()].sort((p,q)=>q[1]-p[1]));
  return`<div class="d-flex flex-wrap gap-2 align-items-center py-2" style="cursor:pointer;border-bottom:1px solid #e5ecf5" data-sx-p="${E(ds)}" data-sx-n="${E(x.t)}"><span class="dot" style="background:${colr(i)}"></span><b>${E(x.t)}</b>${badge(x.type)}<span class="small text-muted ms-auto">${faN(x.cnt)} بار · ${faN(x.min,1)} دقیقه · <i class="fa-regular fa-comment-dots"></i> ${faN(x.desc.size)}</span></div>`}).join('');
 return`<div class="small text-muted mb-2">${faN(l.length)} عنوان · روی هر عنوان بزنید تا توضیحاتش نمایش داده شود</div>${rowsH}
  ${cfgBox(sel('desc','ستون توضیح در لاگ:',a.keys,a.dsC))}`},
 e=>{});

// ۲) فهرست فراوانی توقفات
mk('stops-freq','فهرست فراوانی توقفات','fa-ranking-star',a=>{
 const l=a.items.slice().sort((x,y)=>y.cnt-x.cnt||y.min-x.min),T=l.reduce((s,x)=>s+x.cnt,0),M=l.reduce((s,x)=>s+x.min,0);
 const b=l.map((x,i)=>`<tr><td>${faN(i+1)}</td><td>${E(x.t)}</td><td>${badge(x.type)}</td><td>${faN(x.cnt)}</td><td>${pct(x.cnt,T)}</td><td>${faN(x.min,1)}</td><td>${x.cnt?faN(x.min/x.cnt,1):'—'}</td></tr>`).join('');
 return tbl(['#','عنوان توقف','نوع','تعداد وقوع','٪ از کل وقوع','مجموع دقیقه','میانگین دقیقه در هر وقوع'],b,`<tr class="fw-bold"><td></td><td>جمع</td><td></td><td>${faN(T)}</td><td>${T?'۱۰۰٪':'—'}</td><td>${faN(M,1)}</td><td>${T?faN(M/T,1):'—'}</td></tr>`)});

// ۳) مجموع توقفات و زمان توقف نسبت به کارکرد تجهیز
mk('stops-vs-runtime','توقفات نسبت به کارکرد تجهیز','fa-gauge-high',a=>{
 const l=a.eqs.filter(x=>x.run||x.pmin||x.umin||x.pcnt||x.ucnt).sort((x,y)=>(y.pmin+y.umin)-(x.pmin+x.umin)),S=k=>l.reduce((s,x)=>s+x[k],0);
 const tc=S('pcnt')+S('ucnt'),tm=S('pmin')+S('umin'),tr=S('run');
 const fmt=m=>a.unit==='h'?faN(m/60,1)+' ساعت':faN(m,0)+' دقیقه';
 const b=l.map(x=>{const c=x.pcnt+x.ucnt,m=x.pmin+x.umin;return`<tr><td>${E(x.eq)}</td><td>${faN(c)}</td><td>${faN(m,1)}</td><td>${x.run?fmt(x.run):'—'}</td><td class="fw-bold">${pct(m,x.run)}</td><td class="text-muted">${faN(x.pmin,1)}</td><td class="text-muted">${faN(x.umin,1)}</td></tr>`}).join('');
 const warn=a.runC?'':'<div class="alert alert-warning py-1 small">ستون «کارکرد» پیدا نشد؛ از «تنظیم ستون‌ها» انتخاب کنید.</div>';
 return warn+`<div class="row g-2 mb-2 text-center"><div class="col-6 col-md-3"><div class="small text-muted">مجموع توقفات</div><div class="fs-5 fw-bold">${faN(tc)}</div></div><div class="col-6 col-md-3"><div class="small text-muted">مجموع زمان توقف</div><div class="fs-5 fw-bold">${faN(tm,1)} <span class="small">دقیقه</span></div></div><div class="col-6 col-md-3"><div class="small text-muted">مجموع کارکرد</div><div class="fs-5 fw-bold">${tr?fmt(tr):'—'}</div></div><div class="col-6 col-md-3"><div class="small text-muted">زمان توقف ÷ کارکرد</div><div class="fs-5 fw-bold">${pct(tm,tr)}</div></div></div>`
  +tbl(['تجهیز','تعداد توقف','زمان توقف (دقیقه)','کارکرد','٪ توقف نسبت به کارکرد','برنامه‌ریزی‌شده (دقیقه)','پیش‌بینی‌نشده (دقیقه)'],b,`<tr class="fw-bold"><td>جمع</td><td>${faN(tc)}</td><td>${faN(tm,1)}</td><td>${tr?fmt(tr):'—'}</td><td>${pct(tm,tr)}</td><td>${faN(S('pmin'),1)}</td><td>${faN(S('umin'),1)}</td></tr>`)
  +`<div class="small text-muted mt-2">درصد = مجموع زمان توقف ÷ مجموع کارکرد همان تجهیز. توقفات پیش‌بینی‌نشده با ستون «تجهیز» لاگ به تجهیز نسبت داده می‌شود.</div>`
  +cfgBox(sel('run','ستون کارکرد (ردیف داده):',a.head,a.runC)+`<label class="small d-flex align-items-center gap-2">واحد کارکرد<select class="form-select form-select-sm" style="max-width:120px" data-sx-cfg="runUnit"><option value="h" ${a.unit==='h'?'selected':''}>ساعت</option><option value="min" ${a.unit==='min'?'selected':''}>دقیقه</option></select></label>`)});

// ۴) زمان توقف نسبت به تولید از دست رفته
mk('stops-vs-loss','زمان توقف نسبت به تولید از دست رفته','fa-weight-scale',a=>{
 const l=a.items.slice().sort((x,y)=>y.min-x.min),M=l.reduce((s,x)=>s+x.min,0),K=l.reduce((s,x)=>s+x.kg,0);
 const hk=!!(a.kgC||a.kgDerived);
 const b=l.map(x=>`<tr><td>${E(x.t)}</td><td>${badge(x.type)}</td><td>${faN(x.min,1)}</td><td>${pct(x.min,M)}</td><td>${x.type==='u'&&hk?faN(x.kg,1):'—'}</td><td>${x.type==='u'&&hk?pct(x.kg,K):'—'}</td><td>${x.type==='u'&&hk&&x.min>0?faN(x.kg/x.min,2):'—'}</td></tr>`).join('');
 const warn=hk?'':'<div class="alert alert-warning py-1 small">ستون «کیلوگرم تولید از دست رفته» در لاگ توقفات پیدا نشد و «شناسه ردیف / نرخ تولید» هم برای محاسبه موجود نبود؛ از «تنظیم ستون‌ها» انتخاب کنید.</div>';
 return warn+tbl(['عنوان توقف','نوع','زمان توقف (دقیقه)','٪ از کل زمان','تولید از دست رفته (کیلوگرم)','٪ از کل کیلوگرم','کیلوگرم به‌ازای هر دقیقه'],b,`<tr class="fw-bold"><td>جمع</td><td></td><td>${faN(M,1)}</td><td>${M?'۱۰۰٪':'—'}</td><td>${hk?faN(K,1):'—'}</td><td>${hk&&K?'۱۰۰٪':'—'}</td><td></td></tr>`)
  +`<div class="small text-muted mt-2">${a.kgDerived?'کیلوگرم هر توقف = مدت توقف × نرخ تولید در دقیقه‌ی همان ردیف دیتابیس (اتصال با «شناسه ردیف»). ':'کیلوگرم از ستون انتخاب‌شده‌ی لاگ توقفات پیش‌بینی‌نشده جمع می‌شود. '}برای توقفات برنامه‌ریزی‌شده کیلوگرمی محاسبه نمی‌شود (—).</div>`
  +cfgBox(sel('kg','ستون کیلوگرم تولید از دست رفته (لاگ):',a.keys,a.kgC))});
})();
