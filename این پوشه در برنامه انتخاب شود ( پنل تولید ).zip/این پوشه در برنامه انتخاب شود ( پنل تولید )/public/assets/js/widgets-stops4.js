// دسته‌بندی توقفات: پاپ‌آپِ مدیریت موضوع (کتگوری) + نسبت دادن همه‌ی عنوان‌های توقف به آن‌ها
// ذخیره در دیتابیس ماندگار گزارشات (data/reports.sqlite): جدول‌های stop_cats و stop_map؛ مشترک بین همه‌ی کاربران
(function(){
const E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=(n,d=0)=>Number(n).toLocaleString('fa-IR',{maximumFractionDigits:d});
const PAL=['#2563a8','#e08a2c','#2f9e6b','#0f9aa8','#8b5cf6','#d9467a','#c0392b','#64748b','#a3a52a','#3b82f6'];
const nf=t=>String(t).replace(/[۰-۹]/g,d=>d.charCodeAt(0)-0x6F0).replace(/ي|ى/g,'ی').replace(/ك/g,'ک').replace(/\s+/g,' ').trim().toLowerCase();
const toast=m=>{if(window.toast)window.toast(m)};
const SCHEMA='CREATE TABLE IF NOT EXISTS stop_cats(id INTEGER PRIMARY KEY,name TEXT UNIQUE,color TEXT,sort INT DEFAULT 0);CREATE TABLE IF NOT EXISTS stop_map(title TEXT PRIMARY KEY,cat_id INT)';
const W=fn=>App.rtx(db=>{db.run(SCHEMA);return fn(db)});
const LG=(t,p)=>p.then(r=>{App.alog('stops_cfg',t);return r});
async function load(){try{const cats=await App.rq('SELECT id,name,color FROM stop_cats ORDER BY sort,id'),mp=await App.rq('SELECT title,cat_id FROM stop_map');
 return{cats,map:new Map(mp.map(x=>[x.title,x.cat_id]))}}catch(e){return{cats:[],map:new Map()}}}
const ops={
 add:(name,color)=>LG('افزودن دسته‌ی «'+name+'»',W(db=>db.run('INSERT INTO stop_cats(name,color,sort) VALUES(?,?,COALESCE((SELECT MAX(sort)+1 FROM stop_cats),0))',[name,color]))),
 upd:(id,name,color)=>LG('ویرایش دسته‌ی «'+name+'» (شناسه '+id+')',W(db=>db.run('UPDATE stop_cats SET name=?,color=? WHERE id=?',[name,color,id]))),
 del:id=>LG('حذف دسته‌ی توقف (شناسه '+id+')',W(db=>{db.run('DELETE FROM stop_map WHERE cat_id=?',[id]);db.run('DELETE FROM stop_cats WHERE id=?',[id])})),
 assign:(titles,cid)=>LG((cid==null?'خارج‌کردن از دسته':'انتساب به دسته (شناسه '+cid+')')+': '+titles.slice(0,8).join('، ')+(titles.length>8?' و '+(titles.length-8)+' مورد دیگر':''),W(db=>{for(const t of titles){if(cid==null)db.run('DELETE FROM stop_map WHERE title=?',[t]);else db.run('INSERT OR REPLACE INTO stop_map(title,cat_id) VALUES(?,?)',[t,cid])}}))};
const changed=()=>window.dispatchEvent(new Event('stops-cats-changed'));
const typeB=t=>t==='p'?'<span class="badge b-g">برنامه‌ریزی‌شده</span>':'<span class="badge b-o">پیش‌بینی‌نشده</span>';
function allTitles(){const D=Reports.data(),A=window.StopsAgg;if(!A)return[];
 const ctx={cat:'stops',head:D.head,cols:D.cm,months:[],total:D.rows.length,log:D.log,logCols:D.lcm,all:D.rows};
 return A.aggregate(D.rows,ctx).items.slice().sort((a,b)=>(a.type<b.type?1:a.type>b.type?-1:0)||b.min-a.min)}

// ---------- پاپ‌آپ ----------
async function open(){
 document.querySelectorAll('.sc-pop').forEach(x=>x.remove());
 const can=App.can('merge'),dis=can?'':' disabled';
 let st=await load();const titles=allTitles(),F={q:'',only:false},sel=new Set();let view=[];
 const o=document.createElement('div');o.className='sc-pop';
 o.style.cssText='position:fixed;inset:0;z-index:3000;background:rgba(30,50,80,.4);display:grid;place-items:center;padding:14px';
 o.innerHTML=`<div style="background:#fff;border:1px solid #d7e1ee;border-radius:18px;width:100%;max-width:1020px;max-height:92vh;display:flex;flex-direction:column;color:#1e2f45;box-shadow:0 30px 70px rgba(30,64,110,.3)">
  <div class="d-flex align-items-center px-3 py-2" style="border-bottom:1px solid #e5ecf5"><b style="font-size:16px"><i class="fa-solid fa-tags" style="color:#2563a8"></i> دسته‌بندی توقفات</b>
   <span class="small text-muted ms-2" id="sc-cnt"></span><button class="btn btn-light btn-sm ms-auto" data-sc="x"><i class="fa-solid fa-xmark"></i></button></div>
  <div style="overflow:auto;padding:14px" class="row g-3">
   <div class="col-12 col-lg-4"><div class="fw-bold mb-2">موضوع‌ها (دسته‌ها)</div><div id="sc-cats"></div></div>
   <div class="col-12 col-lg-8"><div class="fw-bold mb-2">عنوان‌های توقف شناسایی‌شده</div>
    <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
     <input id="sc-q" class="form-control form-control-sm" style="max-width:220px" placeholder="جستجوی عنوان...">
     <label class="small d-flex align-items-center gap-1"><input type="checkbox" id="sc-only"> فقط بدون دسته</label>
     <span class="ms-auto d-flex gap-1 align-items-center"><select id="sc-bulk" class="form-select form-select-sm" style="max-width:170px"${dis}></select>
     <button class="btn btn-primary btn-sm" data-sc="bulk"${dis}>اعمال روی انتخاب‌شده‌ها</button></span></div>
    <div id="sc-list" style="max-height:52vh;overflow:auto;border:1px solid #e5ecf5;border-radius:12px"></div></div>
  </div></div>`;
 const $=s=>o.querySelector(s);
 const cnt=c=>titles.filter(t=>st.map.get(t.t)===c).length;
 const catOpts=(cur,none)=>`<option value="">${none}</option>`+st.cats.map(c=>`<option value="${c.id}"${c.id===cur?' selected':''}>${E(c.name)}</option>`).join('');
 function drawCats(){
  $('#sc-cats').innerHTML=(st.cats.length?st.cats.map(c=>`<div class="d-flex align-items-center gap-2 mb-2"><input type="color" value="${E(c.color)}" data-cc="${c.id}" style="width:34px;height:34px;border:0;padding:0;background:none"${dis}>
   <input class="form-control form-control-sm" value="${E(c.name)}" data-cn="${c.id}"${dis}><span class="badge bg-secondary" title="تعداد عنوان‌ها">${faN(cnt(c.id))}</span>
   <button class="btn btn-outline-danger btn-sm" data-sc="del" data-id="${c.id}"${dis}><i class="fa-solid fa-trash"></i></button></div>`).join(''):'<div class="small text-muted mb-2">هنوز موضوعی تعریف نشده است.</div>')+
  `<div class="d-flex align-items-center gap-2 mt-3 pt-3" style="border-top:1px dashed #cfdbe8"><input type="color" id="sc-nc" value="${PAL[st.cats.length%PAL.length]}" style="width:34px;height:34px;border:0;padding:0;background:none"${dis}>
   <input id="sc-nn" class="form-control form-control-sm" placeholder="نام موضوع جدید"${dis}><button class="btn btn-success btn-sm" data-sc="add"${dis}><i class="fa-solid fa-plus"></i></button></div>
   ${can?'':'<div class="small text-muted mt-2">فقط کاربران دارای دسترسی «ادغام» می‌توانند ویرایش کنند.</div>'}`;
  $('#sc-bulk').innerHTML=catOpts(null,'— بدون دسته —')}
 function drawList(){
  const q=nf(F.q).split(' ').filter(Boolean);
  view=titles.filter(t=>(!F.only||!st.cats.some(c=>c.id===st.map.get(t.t)))&&q.every(w=>nf(t.t).includes(w)));
  const un=titles.filter(t=>!st.cats.some(c=>c.id===st.map.get(t.t))).length;
  $('#sc-cnt').textContent=faN(titles.length)+' عنوان · '+faN(un)+' بدون دسته';
  $('#sc-list').innerHTML=view.length?`<table class="table table-sm align-middle mb-0"><thead><tr><th style="width:34px"><input type="checkbox" data-sc="all"${view.length&&view.every(t=>sel.has(t.t))?' checked':''}></th><th>عنوان</th><th>نوع</th><th>تعداد</th><th>دقیقه</th><th style="min-width:170px">موضوع</th></tr></thead><tbody>`+
   view.map((t,i)=>{const cur=st.map.get(t.t),c=st.cats.find(x=>x.id===cur);
    return`<tr><td><input type="checkbox" data-sel="${i}"${sel.has(t.t)?' checked':''}></td><td>${c?`<span class="dot" style="background:${E(c.color)}"></span>`:''}${E(t.t)}</td><td>${typeB(t.type)}</td><td>${faN(t.cnt)}</td><td>${faN(t.min,1)}</td>
     <td><select class="form-select form-select-sm" data-asg="${i}"${dis}>${catOpts(c?c.id:null,'— بدون دسته —')}</select></td></tr>`}).join('')+'</tbody></table>':'<div class="p-3 text-muted small">عنوانی پیدا نشد.</div>'}
 const draw=()=>{drawCats();drawList()};
 const run=async fn=>{try{await fn();st=await load();draw();changed()}catch(e){console.error(e);toast(/UNIQUE/i.test(e.message)?'این نام قبلاً وجود دارد':'ذخیره نشد: '+e.message)}};
 const close=()=>{o.remove();document.removeEventListener('keydown',kd)},kd=e=>{if(e.key==='Escape')close()};
 o.addEventListener('click',async e=>{
  if(e.target===o)return close();
  const b=e.target.closest('[data-sc]');if(!b)return;const a=b.dataset.sc;
  if(a==='x')close();
  else if(a==='add'){const n=$('#sc-nn').value.trim();if(!n)return toast('نام موضوع را بنویسید');await run(()=>ops.add(n,$('#sc-nc').value))}
  else if(a==='del'){const id=+b.dataset.id,c=st.cats.find(x=>x.id===id);if(confirm('موضوع «'+c.name+'» حذف شود؟ عنوان‌های آن «بدون دسته» می‌شوند.'))await run(()=>ops.del(id))}
  else if(a==='all'){view.forEach(t=>b.checked?sel.add(t.t):sel.delete(t.t));drawList()}
  else if(a==='bulk'){const l=[...sel];if(!l.length)return toast('ابتدا عنوان‌ها را تیک بزنید');const v=$('#sc-bulk').value;await run(()=>ops.assign(l,v===''?null:+v));sel.clear();drawList()}});
 o.addEventListener('change',async e=>{const t=e.target;
  if(t.dataset.sel!=null){const x=view[+t.dataset.sel];t.checked?sel.add(x.t):sel.delete(x.t);const h=o.querySelector('[data-sc="all"]');if(h)h.checked=view.length>0&&view.every(t=>sel.has(t.t))}
  else if(t.dataset.asg!=null){const x=view[+t.dataset.asg];await run(()=>ops.assign([x.t],t.value===''?null:+t.value))}
  else if(t.dataset.cn!=null||t.dataset.cc!=null){const id=+(t.dataset.cn||t.dataset.cc),n=o.querySelector(`[data-cn="${id}"]`).value.trim(),c=o.querySelector(`[data-cc="${id}"]`).value;
   if(!n)return toast('نام موضوع خالی نمی‌شود'),draw();await run(()=>ops.upd(id,n,c))}
  else if(t.id==='sc-only'){F.only=t.checked;drawList()}});
 o.addEventListener('input',e=>{if(e.target.id==='sc-q'){F.q=e.target.value;drawList()}});
 document.addEventListener('keydown',kd);document.body.appendChild(o);draw()}

// ---------- کارت خلاصه در صفحه‌ی گزارش ----------
function render(body,rows,ctx){
 const A=window.StopsAgg;if(!A){body.innerHTML='';return}
 const paint=async()=>{if(!body.isConnected){window.removeEventListener('stops-cats-changed',paint);return}
  const st=await load(),items=A.aggregate(rows,ctx).items,g=new Map();
  for(const x of items){let id=st.map.get(x.t);if(!st.cats.some(c=>c.id===id))id=0;const r=g.get(id)||{min:0,cnt:0,n:0};r.min+=x.min;r.cnt+=x.cnt;r.n++;g.set(id,r)}
  const tot=[...g.values()].reduce((s,r)=>s+r.min,0)||1,list=[...st.cats,{id:0,name:'بدون دسته',color:'#94a3b8'}].filter(c=>g.has(c.id)||c.id);
  body.innerHTML=`<div class="card"><div class="card-header"><i class="fa-solid fa-tags"></i> دسته‌بندی توقفات<button class="btn btn-primary btn-sm ms-auto" data-sc-open><i class="fa-solid fa-sliders"></i> مدیریت موضوع‌ها و نسبت دادن عنوان‌ها</button></div>
   <div class="card-body">${st.cats.length?`<div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>موضوع</th><th>عنوان‌ها</th><th>تعداد وقوع</th><th>دقیقه</th><th style="min-width:160px">سهم</th></tr></thead><tbody>`+
   list.map(c=>{const r=g.get(c.id)||{min:0,cnt:0,n:0},p=r.min/tot*100;return`<tr><td><span class="dot" style="background:${E(c.color)}"></span>${E(c.name)}</td><td>${faN(r.n)}</td><td>${faN(r.cnt)}</td><td>${faN(r.min,1)}</td>
    <td><div class="d-flex align-items-center gap-2"><div style="flex:1;height:10px;background:#e9eff6;border-radius:6px;overflow:hidden"><div style="width:${p}%;height:100%;background:${E(c.color)};border-radius:6px"></div></div><span class="small">${faN(p,1)}٪</span></div></td></tr>`}).join('')+'</tbody></table></div>':
   '<div class="text-muted small">هنوز موضوعی تعریف نشده است. با دکمهٔ بالا موضوع بسازید و عنوان‌های توقف را به آن‌ها نسبت دهید؛ سهم هر موضوع (با فیلترهای فعلی) اینجا نشان داده می‌شود.</div>'}</div></div>`};
 body.onclick=e=>{if(e.target.closest('[data-sc-open]'))open().catch(x=>{console.error(x);toast('باز نشد: '+x.message)})};
 window.addEventListener('stops-cats-changed',paint);paint()}
Reports.register({id:'stops-cats',cats:['stops'],bare:true,render});
// ---------- نمودارها به تفکیک موضوع (مثل «سهم دقیقه‌ای و تعداد وقوع»، اما بر اساس دسته‌بندی) ----------
function catItems(rows,ctx,st){const A=window.StopsAgg,g=new Map();
 for(const x of A.aggregate(rows,ctx).items){let id=st.map.get(x.t);const c=st.cats.find(c=>c.id===id);const k=c?c.id:0;
  let r=g.get(k);if(!r)g.set(k,r={t:c?c.name:'بدون دسته',c:c?c.color:'#94a3b8',type:'u',min:0,cnt:0,n:0});r.min+=x.min;r.cnt+=x.cnt;r.n++}
 return[...g.values()]}
function catWidget(id,title,icon,after,draw){
 Reports.register({id,cats:['stops'],title,icon,after,render(body,rows,ctx){
  if(!window.StopsAgg||!window.StopsWidgets){body.innerHTML='';return}
  const paint=async()=>{if(!body.isConnected){window.removeEventListener('stops-cats-changed',paint);return}
   const st=await load(),items=catItems(rows,ctx,st);
   if(!st.cats.length){body.innerHTML='<div class="text-muted small">ابتدا از کارت «دسته‌بندی توقفات» موضوع بسازید و عنوان‌های توقف را به آن‌ها نسبت دهید.</div>';return}
   if(!items.length){body.innerHTML='<div class="text-muted">با فیلترهای فعلی توقفی پیدا نشد.</div>';return}
   body.innerHTML=draw(items,st)};
  window.addEventListener('stops-cats-changed',paint);paint()}})}
const W_=()=>window.StopsWidgets;
catWidget('stops-cat-min','سهم دقیقه‌ای توقفات به تفکیک موضوع','fa-chart-pie','stops-mix',items=>{
 items=items.slice().sort((a,b)=>b.min-a.min||b.cnt-a.cnt);const total=items.reduce((s,x)=>s+x.min,0);
 const list=items.map(x=>`<tr><td><span class="dot" style="background:${E(x.c)}"></span>${E(x.t)}</td><td>${faN(x.n)}</td><td class="text-nowrap">${faN(x.min,1)}</td><td class="text-nowrap">${total?faN(x.min/total*100,1):'۰'}٪</td><td>${faN(x.cnt)}</td></tr>`).join('');
 return`<div class="row g-3"><div class="col-12 col-lg-7 text-center"><div class="fw-bold mb-2">سهم دقیقه‌ای هر موضوع از کل توقفات</div>${total>0?W_().pie(items.filter(x=>x.min>0),total):'<div class="text-muted">دقیقه‌ای ثبت نشده</div>'}</div>
  <div class="col-12 col-lg-5"><div class="fw-bold mb-2">مدت توقفات هر موضوع <span class="small text-muted fw-normal">(مجموع ${faN(total,1)} دقیقه · ${faN(items.length)} موضوع)</span></div>
  <div class="table-responsive" style="max-height:290px;overflow:auto"><table class="table table-sm align-middle mb-0"><thead><tr><th>موضوع</th><th>عنوان‌ها</th><th>دقیقه</th><th>درصد</th><th>تعداد</th></tr></thead><tbody>${list}</tbody></table></div></div></div>`});
catWidget('stops-cat-cnt','تعداد وقوع توقفات به تفکیک موضوع','fa-chart-column','stops-cat-min',items=>{
 const total=items.reduce((s,x)=>s+x.cnt,0);
 return`<div class="row g-3"><div class="col-12 col-lg-3 text-center"><div class="fw-bold mb-2">تعداد کل توقفات</div><div style="font-size:34px;font-weight:700;color:#173250">${faN(total)}</div><div class="small text-muted">در ${faN(items.length)} موضوع</div></div>
  <div class="col-12 col-lg-9"><div class="fw-bold mb-2">تعداد وقوع توقفات هر موضوع</div>${W_().bars(items,999)}</div></div>`});

window.StopCats={load,ops,open};
})();
