// رابط: ورود، منوی بالا، صفحه‌ی فایل‌ها، صفحه‌ی کاربران
(function(){
const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const PERMS={merge:'ادغام و دانلود',files:'صفحه‌ی فایل‌ها (فایل‌های خود)',viewall:'دیدن فایل‌های همه',delete:'حذف فایل‌ها'};
const mv=$('#mv');mv.style.display='none';{const b=document.getElementById('boot');if(b)b.remove()}
const ui=document.createElement('div');ui.className='container py-3';ui.style.maxWidth='1100px';
ui.innerHTML=`<div id="login" class="card login boot mx-auto mt-5" style="max-width:380px"><div class="card-body">
 <img class="lg" src="assets/img/logo.png" alt="بهینه وزین"><h5 class="mb-3">ورود به پنل ادغام اکسل</h5>
 <div id="conn"><button class="btn btn-primary w-100" id="bc">اتصال به پوشه‌ی اشتراکی</button><div class="small text-muted mt-2" id="conn-t">پوشه‌ای را که این برنامه در آن است انتخاب کنید (فقط بار اول).</div></div>
 <div id="lf" style="display:none"><input id="lu" class="form-control mb-2" placeholder="نام کاربری" autocomplete="username"><input id="lp" type="password" class="form-control mb-2" placeholder="رمز عبور" autocomplete="current-password">
 <button class="btn btn-success w-100" id="lb">ورود</button><a href="#" id="fgt" class="small d-block mt-2">رمز عبور را فراموش کرده‌ام</a><a href="#" id="chg" class="small d-block mt-2">تغییر پوشه</a></div>
 <div id="le" class="text-danger small mt-2"></div></div></div>
<div id="bar" class="topbar d-flex gap-2 align-items-center mb-3 flex-wrap" style="display:none!important">
 <span class="brand"><img src="assets/img/logo.png" alt=""> پنل ادغام اکسل</span>
 <button class="nav-pill" data-t="files"><i class="fa-solid fa-folder-open"></i> فایل‌ها</button>
 <button class="nav-pill" data-t="reports"><i class="fa-solid fa-chart-column"></i> گزارشات</button>
 <button class="nav-pill" data-t="users"><i class="fa-solid fa-users"></i> کاربران</button>
 <button class="nav-pill" data-t="log" style="display:none"><i class="fa-solid fa-clipboard-list"></i> لوگ <span id="onb" class="au-bd au-g" style="padding:0 7px"></span></button>
 <span class="ms-auto small who" id="who"></span><button class="btn btn-sm btn-light" id="pw">تغییر رمز</button><button class="btn btn-sm btn-light" id="out">خروج</button></div>
<div id="subnav" class="catseg" style="display:none"></div>
<div id="v-files" style="display:none"></div><div id="v-reports" style="display:none"></div><div id="v-users" style="display:none"></div><div id="v-log" style="display:none"></div>`;
mv.before(ui);
const err=m=>$('#le').textContent=m||'';
let NEED=false;
async function conn(mode){try{const r=await App.connect(mode);if(r==='perm'){NEED=true;$('#conn').style.display='';$('#lf').style.display='none';$('#bc').textContent='اجازه‌ی دسترسی به پوشه (Allow)';$('#conn-t').textContent='برای ورود و بازیابی رمز، ابتدا دسترسی به پوشه‌ی اشتراکی را تایید کنید (پنجره‌ی مرورگر را روی Allow بزنید).';err()}else if(r){NEED=false;$('#conn').style.display='none';$('#lf').style.display='';err()}else err('')}catch(e){err('اتصال ناموفق: '+e.message)}}
$('#bc').onclick=()=>conn('ask');$('#chg').onclick=e=>{e.preventDefault();conn('pick')};
conn('silent').finally(()=>{$('#login').classList.remove('boot');const s=document.getElementById('splash');if(s){s.style.opacity=0;setTimeout(()=>s.remove(),380)}});
const go=async()=>{const u=$('#lu').value,p=$('#lp').value;err();
 try{if(NEED){if(!await App.connect('ask'))return err('برای ورود باید دسترسی به پوشه را تایید کنید (پنجره‌ی مرورگر).');NEED=false}
  const r=await App.login(u,p);if(!r)return err('نام کاربری یا رمز اشتباه است');
  while(r.must){const n=prompt('اولین ورود: یک رمز جدید انتخاب کنید (حداقل ۶ کاراکتر)');if(n===null){App.alog('login_fail','رمز درست بود ولی تغییر رمز اولیه انجام نشد',{id:r.id,username:r.username,name:r.name});App.user=null;return err('برای ورود باید رمز جدید انتخاب شود')}if(n.length>=6){await App.setPw(r.id,n,0);r.must=0;toast('رمز تغییر کرد')}else toast('رمز باید حداقل ۶ کاراکتر باشد')}
  $('#login').style.display='none';const b=$('#bar');b.style.cssText='';$('#who').textContent=r.name+' ('+r.username+')';document.querySelector('[data-t=log]').style.display=r.role==='admin'?'':'none';if(window.Audit)Audit.start(r);
  const seeF=App.can('files')||App.can('viewall')||App.can('merge');
  document.querySelector('[data-t=files]').style.display=seeF?'':'none';
  document.querySelector('[data-t=reports]').style.display=seeF?'':'none';
  document.querySelector('[data-t=users]').style.display=r.role==='admin'?'':'none';
  await show(App.can('merge')?'merge':seeF?'files':'none');
  if(seeF&&window.Reports)Reports.syncAll().catch(console.error)} // ورود خودکار آخرین فایل‌های ادغام‌شده به گزارشات
 catch(e){err('خطا: '+e.message)}};
$('#lb').onclick=go;$('#lp').onkeydown=e=>{if(e.key==='Enter')go()};
$('#out').onclick=async()=>{try{if(window.Audit)await Audit.stop()}catch(e){}location.reload()};
$('#pw').onclick=async()=>{const n=prompt('رمز جدید (حداقل ۶ کاراکتر)');if(n&&n.length>=6){await App.setPw(App.user.id,n,0);toast('رمز تغییر کرد')}};
ui.addEventListener('click',e=>{const t=e.target.closest('[data-t]');if(t)return show(t.dataset.t);const s=e.target.closest('[data-s]');if(s)show(s.dataset.s,s.dataset.c)});
// منوی دو‌سطحی: بالا = فایل‌ها | گزارشات | کاربران ؛ زیرمنو: فایل‌ها ⊃ (لیست فایل‌ها، ادغام) ، گزارشات ⊃ (گزارش‌های روزانه، توقفات)
// show('files') / show('merge') / show('reports',cat) / show('users')
let REPCAT='daily',LOGSUB='online';
function subnav(top,sub){const sn=$('#subnav');let items=[];
 if(top==='files')items=[['files','','fa-folder-open','لیست فایل‌ها'],...(App.can('merge')?[['merge','','fa-table-columns','ادغام']]:[])];
 else if(top==='reports')items=Object.entries(Reports.CATS).map(([c,x])=>['reports',c,x.i,x.n]);
 else if(top==='log')items=[['log','online','fa-signal','آنلاین‌ها (لایو)'],['log','history','fa-clock-rotate-left','تاریخچه و رهگیری']];
 if(!items.length){sn.style.display='none';sn.innerHTML='';return}
 sn.style.display='inline-flex';sn.style.margin='0 0 14px';
 sn.innerHTML=items.map(([s,c,ic,t])=>`<button data-s="${s}" data-c="${c}" class="${(top==='reports'||top==='log'?c===sub:s===sub)?'on':''}"><i class="fa-solid ${ic}"></i> ${t}</button>`).join('')}
async function show(t,c){
 const top=t==='merge'?'files':t,sub=t==='merge'?'merge':t==='files'?'files':t==='reports'?(c||REPCAT):t==='log'?(c||LOGSUB):'';
 if(t==='reports')REPCAT=sub;if(t==='log')LOGSUB=sub;
 document.querySelectorAll('#bar [data-t]').forEach(b=>b.classList.toggle('active',b.dataset.t===top));
 subnav(top,sub);
 mv.style.display=t==='merge'?'':'none';$('#v-files').style.display=t==='files'?'':'none';$('#v-reports').style.display=t==='reports'?'':'none';$('#v-users').style.display=t==='users'?'':'none';$('#v-log').style.display=t==='log'?'':'none';if(window.Audit)Audit.view(t,sub);
 if(t==='files')await files();if(t==='users')await users();if(t==='reports')await Reports.show(sub);if(t==='log'&&window.Audit)await Audit.show(sub)}
const sz=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.ceil(n/1024)+' KB',dt=s=>new Date(s).toLocaleString('fa-IR');
const faN=n=>Number(n).toLocaleString('fa-IR');
const jn=d=>{const p=new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric'}).formatToParts(d),g=t=>+p.find(x=>x.type===t).value;return g('year')*10000+g('month')*100+g('day')};
const dig=t=>String(t).replace(/[\u06F0-\u06F9]/g,d=>d.charCodeAt(0)-0x6F0).replace(/[\u0660-\u0669]/g,d=>d.charCodeAt(0)-0x660);
const pj=t=>{const a=dig(t).trim().split(/[\/\-.]/).map(Number);return a.length===3&&a.every(x=>x>0)?a[0]*10000+a[1]*100+a[2]:0};
const nrm=t=>dig(t).replace(/\u064A|\u0649/g,'\u06CC').replace(/\u0643/g,'\u06A9').toLowerCase();
let FCAT='daily',RAW=null,PICK=null; // PICK={base:[id..],sel:Set('u12','m7')} پنل تلفیق
let FS={q:'',user:'',st:'',from:'',to:'',sort:'new'},SEL=null,DATA=null,UN={};
// پیدا کردن رابطه‌ی «مادر ↔ زیرمجموعه» از روی نام فایل‌های مبدأ ثبت‌شده در هر ادغام
function relate(ups,mgs){const kids={},par={},glob=new Set(),byId=new Map();
 ups.forEach(f=>byId.set(f.id,{f,kind:'u'}));mgs.forEach(f=>byId.set(f.id,{f,kind:'m'}));
 const add=(mid,x)=>{kids[mid].push(x);(par[x.f.id]=par[x.f.id]||[]).push(mid)};
 [...mgs].sort((a,b)=>a.id-b.id).forEach(m=>{kids[m.id]=[];
  let ids=[];try{ids=JSON.parse(m.srcids||'[]')}catch(e){}
  const names=(m.src||'').split(' | ').filter(Boolean);
  if(ids.length){ids.forEach((id,i)=>{const x=byId.get(id);if(x&&x.f.id!==m.id){glob.add(id);add(m.id,x)}else kids[m.id].push({missing:names[i]||('فایل #'+id)})});return}
  // رکوردهای قدیمی (بدون شناسه): تطبیق با نام فایل
  const loc=new Set();
  names.forEach(n=>{
   const u=ups.filter(u=>u.orig===n&&!loc.has(u.id)&&u.ts<=m.ts).sort((a,b)=>(glob.has(a.id)-glob.has(b.id))||a.id-b.id)[0];
   if(u){loc.add(u.id);glob.add(u.id);add(m.id,{f:u,kind:'u'})}else kids[m.id].push({missing:n})})});
 return{kids,par}}
const vis=f=>DATA.all||f.uploader===App.user.username;
const uname=u=>UN[u]||u;
function pass(f,isM){if(FS.user&&f.uploader!==FS.user)return false;
 if(FS.q){const hay=nrm(f.orig+' '+f.uploader+' '+uname(f.uploader)+(isM?' '+(f.src||''):''));if(!FS.q.split(/\s+/).every(w=>hay.includes(nrm(w))))return false}
 const j=jn(new Date(f.ts)),a=pj(FS.from),b=pj(FS.to);if(a&&j<a)return false;if(b&&j>b)return false;
 if(!isM&&FS.st){const m=!!(DATA.rel.par[f.id]||[]).length;if(FS.st==='done'&&!m)return false;if(FS.st==='todo'&&m)return false}
 return true}
const srt=(l)=>l.sort((a,b)=>FS.sort==='old'?a.id-b.id:FS.sort==='name'?a.orig.localeCompare(b.orig,'fa'):FS.sort==='size'?b.size-a.size:b.id-a.id);
function shell(){const v=$('#v-files');v.innerHTML=`
 <div class="cats" id="fcats"></div>
 <div class="card" id="fupc"><div class="card-body py-3"><div class="drop" id="fdrop" style="padding:22px"><i class="fa-solid fa-cloud-arrow-up"></i>
  <div class="mt-1 fw-bold">آپلود فایل جدید در این دسته</div><div class="small text-muted">بعد از آپلود، فایل‌های دیگر بالای صفحه می‌آیند تا تیک بزنید و تلفیق کنید</div></div>
  <input type="file" id="finp" accept=".xlsx,.xlsm,.xls,.csv" multiple hidden></div></div>
 <div id="pickp"></div>
 <div class="stats" id="fstats"></div>
 <div class="card filt"><div class="card-body">
  <div class="row g-2 align-items-end">
   <div class="col-12 col-md-4"><label class="flbl">جستجوی نام فایل / کاربر</label><div class="input-icon"><i class="fa-solid fa-magnifying-glass"></i><input id="fq" class="form-control" placeholder="مثلاً فویلی، امانی..."></div></div>
   <div class="col-6 col-md-2"><label class="flbl">شخص (آپلودکننده)</label><select id="fu" class="form-select"><option value="">همه</option></select></div>
   <div class="col-6 col-md-2"><label class="flbl">از تاریخ (شمسی)</label><input id="ff" class="form-control" placeholder="۱۴۰۵/۰۷/۲۰" inputmode="numeric"></div>
   <div class="col-6 col-md-2"><label class="flbl">تا تاریخ (شمسی)</label><input id="ft2" class="form-control" placeholder="۱۴۰۵/۰۷/۲۲" inputmode="numeric"></div>
   <div class="col-6 col-md-2"><label class="flbl">مرتب‌سازی</label><select id="fs" class="form-select"><option value="new">جدیدترین</option><option value="old">قدیمی‌ترین</option><option value="name">نام</option><option value="size">حجم</option></select></div>
  </div>
  <div class="d-flex flex-wrap gap-2 mt-3 align-items-center">
   <span class="small text-muted">وضعیت:</span>
   <button class="chip on" data-st="">همه</button><button class="chip chip-o" data-st="todo"><i class="fa-solid fa-hourglass-half"></i> ادغام‌نشده</button><button class="chip chip-g" data-st="done"><i class="fa-solid fa-circle-check"></i> ادغام‌شده</button>
   <span class="vr mx-1"></span><span class="small text-muted">بازه:</span>
   <button class="chip" data-d="today">امروز</button><button class="chip" data-d="yest">دیروز</button><button class="chip" data-d="w">۷ روز اخیر</button><button class="chip" data-d="all">همه‌ی زمان‌ها</button>
   <button class="btn btn-sm btn-light ms-auto" id="fclr"><i class="fa-solid fa-filter-circle-xmark"></i> پاک کردن فیلترها</button>
  </div></div></div>
 <div id="relp"></div><div id="tu"></div><div id="tm"></div>`;
 v.dataset.init=1;
 const fd=$('#fdrop'),up=async l=>{if(l.length)await handleUpload(l,FCAT)};
 fd.onclick=()=>$('#finp').click();$('#finp').onchange=e=>{up([...e.target.files]);e.target.value=''};
 ['dragover','dragenter'].forEach(t=>fd.addEventListener(t,e=>{e.preventDefault();fd.classList.add('over')}));
 ['dragleave','drop'].forEach(t=>fd.addEventListener(t,e=>{e.preventDefault();fd.classList.remove('over')}));
 fd.addEventListener('drop',e=>up([...e.dataTransfer.files]));
 const on=(id,ev,fn)=>$(id).addEventListener(ev,fn);
 on('#fq','input',e=>{FS.q=e.target.value.trim();paint()});on('#fu','change',e=>{FS.user=e.target.value;paint()});
 on('#ff','input',e=>{FS.from=e.target.value;paint()});on('#ft2','input',e=>{FS.to=e.target.value;paint()});on('#fs','change',e=>{FS.sort=e.target.value;paint()});
 v.querySelectorAll('[data-st]').forEach(b=>b.onclick=()=>{FS.st=b.dataset.st;paint()});
 v.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{const k=b.dataset.d,d=new Date(),f=n=>{const x=new Date();x.setDate(x.getDate()-n);return x},fmt=x=>{const j=String(jn(x));return j.slice(0,4)+'/'+j.slice(4,6)+'/'+j.slice(6)};
  if(k==='all'){FS.from=FS.to=''}else if(k==='today'){FS.from=FS.to=fmt(d)}else if(k==='yest'){FS.from=FS.to=fmt(f(1))}else{FS.from=fmt(f(6));FS.to=fmt(d)}
  $('#ff').value=FS.from;$('#ft2').value=FS.to;paint()});
 on('#fclr','click',()=>{FS={q:'',user:'',st:'',from:'',to:'',sort:'new'};['#fq','#ff','#ft2'].forEach(s=>$(s).value='');$('#fu').value='';$('#fs').value='new';paint()})}
const cOf=f=>f.cat||'daily';
async function files(){const v=$('#v-files');if(!v.dataset.init)shell();
 RAW={ups:await App.list('upload'),mgs:await App.list('merged')};
 $('#fupc').style.display=App.can('merge')?'':'none';
 try{UN={};(await App.users()).forEach(u=>UN[u.username]=u.name)}catch(e){}
 const ups=RAW.ups.filter(f=>cOf(f)===FCAT),mgs=RAW.mgs.filter(f=>cOf(f)===FCAT);
 DATA={all:App.can('viewall'),ups,mgs,rel:relate(ups,mgs)};
 const us=[...new Set([...ups,...mgs].filter(vis).map(f=>f.uploader))];
 if(FS.user&&!us.includes(FS.user))FS.user='';
 $('#fu').innerHTML='<option value="">همه</option>'+us.map(u=>`<option value="${E(u)}" ${FS.user===u?'selected':''}>${E(uname(u))}</option>`).join('');
 if(SEL&&!(SEL.k==='u'?ups:mgs).some(f=>f.id===SEL.id))SEL=null;
 paint()}
function nodeHtml(f,kind,role,extra){const isM=kind==='m';
 return`<div class="node ${isM?'node-m':(DATA.rel.par[f.id]||[]).length?'node-g':'node-o'} ${SEL&&SEL.k===kind&&SEL.id===f.id?'node-sel':''}" data-jump="${kind}${f.id}">
  <div class="nico"><i class="fa-solid ${isM?'fa-file-circle-check':'fa-file-excel'}"></i></div>
  <div class="nbody"><div class="nname">${E(f.orig)}</div>
   <div class="nmeta"><span><i class="fa-solid fa-user"></i> ${E(uname(f.uploader))}</span><span><i class="fa-regular fa-clock"></i> ${dt(f.ts)}</span><span>${sz(f.size)}</span></div></div>
  <span class="rtag ${isM?'rt-m':'rt-k'}">${role}</span>${extra||''}</div>`}
function treeHtml(mid){const m=DATA.mgs.find(x=>x.id===mid);if(!m)return'';const ks=DATA.rel.kids[mid]||[];let hid=0;
 const kh=ks.map(k=>{if(k.f){if(!vis(k.f)){hid++;return''}return`<div class="kid">${nodeHtml(k.f,k.kind,k.kind==='m'?'فایل مادر قبلی':'زیرمجموعه')}</div>`}
  return`<div class="kid"><div class="node node-x"><div class="nico"><i class="fa-solid fa-file-circle-xmark"></i></div><div class="nbody"><div class="nname">${E(k.missing)}</div><div class="nmeta"><span>فایل مبدأ حذف شده یا پیدا نشد</span></div></div><span class="rtag rt-x">حذف‌شده</span></div></div>`}).join('');
 return`<div class="tree"><div class="mother">${nodeHtml(m,'m','فایل مادر (خروجی ادغام)',`<button class="btn btn-sm btn-primary" data-dl="${m.id}" data-p="${E(m.stored)}" data-n="${E(m.orig)}"><i class="fa-solid fa-download"></i></button>`)}</div>
  <div class="kids"><div class="klbl"><i class="fa-solid fa-diagram-project"></i> ${faN(ks.length)} فایل زیرمجموعه در این ادغام شرکت کرده‌اند</div>${kh}${hid?`<div class="small text-muted mt-1">+ ${faN(hid)} فایل از کاربران دیگر (دسترسی دیدن ندارید)</div>`:''}</div></div>`}
function relPanel(){const p=$('#relp');if(!SEL){p.innerHTML='';return}
 let ids=[],head='';
 if(SEL.k==='m'){ids=[SEL.id];head=`<i class="fa-solid fa-sitemap"></i> این فایل مادر است؛ زیرمجموعه‌هایش را ببینید`}
 else{ids=DATA.rel.par[SEL.id]||[];const u=DATA.ups.find(x=>x.id===SEL.id);
  if(!ids.length){p.innerHTML=`<div class="card relcard rel-o"><div class="card-header"><i class="fa-solid fa-hourglass-half"></i> هنوز ادغام نشده<button class="btn-close ms-auto" data-closerel></button></div><div class="card-body">${nodeHtml(u,'u','ادغام‌نشده')}
   <div class="small text-muted mt-2">این فایل هنوز در هیچ فایل مادری استفاده نشده است.</div>${App.can('merge')?`<button class="btn btn-warning mt-2" data-pk="${u.id}"><i class="fa-solid fa-code-merge"></i> تلفیق این فایل با فایل‌های دیگر</button>`:''}</div></div>`;return}
  head=`<i class="fa-solid fa-sitemap"></i> این فایل زیرمجموعه است؛ فایل مادرش را ببینید`}
 p.innerHTML=`<div class="card relcard rel-g"><div class="card-header">${head}<button class="btn-close ms-auto" data-closerel></button></div><div class="card-body">${ids.map(treeHtml).join('<hr>')}</div></div>`}
function paint(){if(!DATA)return;
 const R=DATA.rel,ups=srt(DATA.ups.filter(vis).filter(f=>pass(f,0))),mgs=srt(DATA.mgs.filter(vis).filter(f=>pass(f,1)));
 const allU=DATA.ups.filter(vis),doneN=allU.filter(f=>(R.par[f.id]||[]).length).length;
 const CI={daily:['fa-clipboard-list','گزارش‌های روزانه'],stops:['fa-stopwatch','توقفات']};
 $('#fcats').innerHTML=Object.keys(CI).map(c=>{const u=RAW.ups.filter(f=>cOf(f)===c&&vis(f)),m=RAW.mgs.filter(f=>cOf(f)===c&&vis(f));
  return`<div class="cat-tab ${FCAT===c?'on':''}" data-cat="${c}"><div class="ci"><i class="fa-solid ${CI[c][0]}"></i></div><div><div class="ct">${CI[c][1]}</div><div class="cs">${faN(u.length)} آپلود · ${faN(m.length)} ادغام‌شده</div></div></div>`}).join('');
 $('#fstats').innerHTML=[['fa-file-excel','آپلودشده',allU.length,'st-b'],['fa-circle-check','ادغام‌شده',doneN,'st-g'],['fa-hourglass-half','ادغام‌نشده',allU.length-doneN,'st-o'],['fa-file-circle-check','فایل مادر (خروجی)',DATA.mgs.filter(vis).length,'st-p']]
  .map(s=>`<div class="stat ${s[3]}"><i class="fa-solid ${s[0]}"></i><div><div class="sn">${faN(s[2])}</div><div class="sl">${s[1]}</div></div></div>`).join('');
 document.querySelectorAll('#v-files [data-st]').forEach(b=>b.classList.toggle('on',b.dataset.st===FS.st));
 const rel=new Set();if(SEL){if(SEL.k==='m')(R.kids[SEL.id]||[]).forEach(k=>k.f&&rel.add(k.kind+k.f.id));else(R.par[SEL.id]||[]).forEach(m=>{rel.add('m'+m);(R.kids[m]||[]).forEach(k=>k.f&&rel.add(k.kind+k.f.id))})}
 const cls=(k)=>(SEL&&SEL.k+SEL.id==k?' sel':'')+(rel.has(k)?' rel':'');
 const acts=(f,kind)=>`<button class="btn btn-sm btn-primary" title="دانلود" data-dl="${f.id}" data-p="${E(f.stored)}" data-n="${E(f.orig)}"><i class="fa-solid fa-download"></i></button>
  ${kind==='u'&&App.can('merge')?((R.par[f.id]||[]).length?`<button class="btn btn-sm btn-outline-success mbtn" data-pk="${f.id}"><i class="fa-solid fa-code-merge"></i> تلفیق مجدد</button>`:`<button class="btn btn-sm btn-warning mbtn" data-pk="${f.id}"><i class="fa-solid fa-code-merge"></i> تلفیق</button>`):''}
  ${App.can('delete')||(f.uploader===App.user.username&&App.can('merge'))?`<button class="btn btn-sm btn-outline-danger" title="حذف" data-rm="${f.id}" data-p="${E(f.stored)}"><i class="fa-solid fa-trash"></i></button>`:''}`;
 const T=(l,kind,title,ic)=>{const isM=kind==='m';
  return`<div class="card"><div class="card-header"><i class="fa-solid ${ic}"></i> ${title} <span class="badge bg-secondary">${faN(l.length)}</span><span class="small text-muted fw-normal ms-2">برای دیدن ارتباط، روی هر ردیف کلیک کنید</span></div><div class="table-responsive"><table class="table align-middle mb-0 ftab"><thead><tr><th>نام فایل</th><th>شخص</th><th>زمان</th><th>حجم</th>${isM?'<th>زیرمجموعه‌ها</th>':'<th>وضعیت</th>'}<th></th></tr></thead><tbody>`+
  (l.length?l.map(f=>{const k=kind+f.id,pm=R.par[f.id]||[],done=isM||pm.length;
   return`<tr data-k="${k}" class="frow ${isM?'row-m':done?'row-g':'row-o'}${cls(k)}"><td class="fw-medium">${E(f.orig)}</td><td>${E(uname(f.uploader))}<div class="small text-muted">${E(f.uploader)}</div></td><td class="small">${dt(f.ts)}</td><td>${sz(f.size)}</td>
   <td>${isM?`<span class="badge b-g">${faN((R.kids[f.id]||[]).length)} فایل</span>`:done?`<span class="badge b-g"><i class="fa-solid fa-circle-check"></i> ادغام شده</span>`:`<span class="badge b-o"><i class="fa-solid fa-hourglass-half"></i> ادغام نشده</span>`}</td>
   <td class="text-nowrap">${acts(f,kind)}</td></tr>`}).join(''):`<tr><td colspan="6" class="text-center text-muted py-4">موردی با این فیلترها پیدا نشد</td></tr>`)+'</tbody></table></div></div>'};
 $('#tu').innerHTML=T(ups,'u','فایل‌های آپلودشده','fa-cloud-arrow-up');$('#tm').innerHTML=T(mgs,'m','فایل‌های ادغام‌شده (مادر)','fa-file-circle-check');relPanel();pickPanel()}
// ===== پنل تلفیق: فایل(های) آپلودشده بالا؛ فایل‌های دیگر با تیک؛ دکمه‌ی «تلفیق» صفحه‌ی ادغام را باز می‌کند =====
const baseRecs=()=>PICK?PICK.base.map(id=>DATA.ups.find(f=>f.id===id)).filter(Boolean):[];
function pickLists(){const bs=new Set(PICK.base);
 return{ups:DATA.ups.filter(f=>!bs.has(f.id)&&vis(f)).sort((a,b)=>b.id-a.id),mgs:DATA.mgs.filter(vis).sort((a,b)=>b.id-a.id)}}
function pickBtn(){const b=document.querySelector('#pickp [data-pkgo]');if(!b)return;const n=baseRecs().length+PICK.sel.size;
 b.disabled=n<2;b.innerHTML=`<i class="fa-solid fa-code-merge"></i> تلفیق (${faN(n)} فایل)`;
 const all=document.querySelector('#pickp #pall');if(all){const t=document.querySelectorAll('#pickp .pk').length;all.checked=t>0&&PICK.sel.size===t}}
function pickPanel(){const p=$('#pickp');if(!PICK){p.innerHTML='';return}
 const base=baseRecs();if(!base.length){PICK=null;p.innerHTML='';return}
 const L=pickLists(),row=(f,kind)=>{const k=kind+f.id,on=PICK.sel.has(k),mt=kind==='m'?'<span class="badge b-g" style="background:#f3e8ff;color:#7e22ce">فایل مادر</span>':(DATA.rel.par[f.id]||[]).length?'<span class="badge b-g">ادغام شده</span>':'<span class="badge b-o">ادغام نشده</span>';
  return`<label class="pk-row ${on?'on':''}"><input type="checkbox" class="pk" value="${k}" ${on?'checked':''}>
   <span class="flex-fill" style="min-width:0"><span class="d-block fw-medium text-truncate">${E(f.orig)}</span><span class="small text-muted">${E(uname(f.uploader))} · ${dt(f.ts)} · ${sz(f.size)}</span></span>${mt}</label>`};
 const empty=!L.ups.length&&!L.mgs.length;
 p.innerHTML=`<div class="card pickcard"><div class="card-header"><i class="fa-solid fa-code-merge"></i> تلفیق فایل<button class="btn-close ms-auto" data-pkx></button></div><div class="card-body">
  <div class="small text-muted mb-2">${base.length>1?'فایل‌های آپلودشده (همه در تلفیق شرکت می‌کنند)':'فایل آپلودشده'}:</div>
  ${base.map(f=>nodeHtml(f,'u','آپلود جدید')).join('<div class="mb-2"></div>')}
  <hr><div class="d-flex align-items-center flex-wrap gap-2 mb-2"><b>با کدام فایل‌ها تلفیق شود؟</b><span class="small text-muted">یک یا چند مورد را تیک بزنید، بعد «تلفیق» را بزنید</span>
   ${empty?'':'<label class="ms-auto small"><input type="checkbox" id="pall"> انتخاب همه</label>'}</div>
  ${empty?'<div class="text-muted small py-3 text-center">فایل دیگری در این دسته نیست.'+(base.length>1?'':' ')+'</div>':`<div class="pk-list">${L.ups.length?'<div class="pk-grp">فایل‌های آپلودشده</div>'+L.ups.map(f=>row(f,'u')).join(''):''}${L.mgs.length?'<div class="pk-grp">فایل‌های ادغام‌شده (مادر)</div>'+L.mgs.map(f=>row(f,'m')).join(''):''}</div>`}
  <div class="d-flex gap-2 mt-3 align-items-center"><button class="btn btn-primary" data-pkgo disabled></button><button class="btn btn-light" data-pkx>انصراف</button>
   <span class="small text-muted" id="pkhint"></span></div></div></div>`;
 pickBtn()}
function startPick(ids){PICK={base:ids,sel:new Set()};SEL=null;paint();const p=$('#pickp');if(p.scrollIntoView)p.scrollIntoView({behavior:'smooth',block:'start'})}
async function afterUpload(saved,cat){FCAT=cat;await show('files');startPick(saved.map(x=>x.id))}
async function pickGo(btn){
 const base=baseRecs(),L=pickLists(),sel=[...L.ups.filter(f=>PICK.sel.has('u'+f.id)),...L.mgs.filter(f=>PICK.sel.has('m'+f.id))],recs=[...base,...sel];
 if(recs.length<2)return toast('حداقل دو فایل لازم است');
 btn.disabled=true;toast('در حال بارگذاری فایل‌ها…');
 try{const items=[];for(const f of recs){const b=await App.get(f.stored);if(!b){toast('فایل «'+f.orig+'» در پوشه پیدا نشد');btn.disabled=false;return}items.push({blob:b,name:f.orig,dbId:f.id})}
  const cat=FCAT;PICK=null;await show('merge');
  if(await loadForMerge(items,cat)){const a=document.querySelector('#app');if(a&&a.scrollIntoView)a.scrollIntoView({behavior:'smooth',block:'start'})}}
 catch(x){console.error(x);toast('خطا: '+x.message);btn.disabled=false}}
function pick(k,scroll){SEL={k:k[0],id:+k.slice(1)};paint();if(scroll)$('#relp').scrollIntoView({behavior:'smooth',block:'start'})}
function jump(k){const r=document.querySelector(`#v-files tr[data-k="${k}"]`);if(!r)return pick(k,true);pick(k,false);const t=document.querySelector(`#v-files tr[data-k="${k}"]`);t.scrollIntoView({behavior:'smooth',block:'center'});t.classList.add('flash');setTimeout(()=>t.classList.remove('flash'),1600)}
$('#v-files').addEventListener('click',async e=>{
 const ct=e.target.closest('[data-cat]');if(ct){FCAT=ct.dataset.cat;SEL=null;PICK=null;await files();return}
 if(e.target.closest('[data-pkx]')){PICK=null;paint();return}
 const pg=e.target.closest('[data-pkgo]');if(pg){await pickGo(pg);return}
 if(e.target.closest('[data-closerel]')){SEL=null;paint();return}
 const b=e.target.closest('button');
 if(!b){const n=e.target.closest('[data-jump]');if(n)return jump(n.dataset.jump);
  const tr=e.target.closest('tr[data-k]');if(tr)pick(tr.dataset.k,true);return}
 const d=b.dataset;
 if(d.pk){startPick([+d.pk]);return}
 try{if(d.dl){const f=await App.get(d.p);if(!f)return toast('فایل در پوشه پیدا نشد');App.alog('download','«'+d.n+'» (لیست فایل‌ها)');
   {const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=d.n;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}}
  else if(d.rm&&confirm('حذف شود؟')){await App.del(+d.rm,d.p);if(PICK){PICK.base=PICK.base.filter(i=>i!==+d.rm);PICK.sel.delete('u'+d.rm);PICK.sel.delete('m'+d.rm)}await files()}}catch(x){toast('خطا: '+x.message)}});
$('#v-files').addEventListener('change',e=>{if(!PICK)return;const t=e.target;
 if(t.id==='pall'){const L=pickLists();PICK.sel=new Set(t.checked?[...L.ups.map(f=>'u'+f.id),...L.mgs.map(f=>'m'+f.id)]:[]);document.querySelectorAll('#pickp .pk').forEach(c=>{c.checked=t.checked;c.closest('.pk-row').classList.toggle('on',t.checked)});pickBtn()}
 else if(t.classList&&t.classList.contains('pk')){t.checked?PICK.sel.add(t.value):PICK.sel.delete(t.value);t.closest('.pk-row').classList.toggle('on',t.checked);pickBtn()}});
window.AppUI={afterUpload,goFiles:()=>show('files')};
async function users(){const l=await App.users(),v=$('#v-users');
 v.innerHTML=`<div class="card"><div class="card-header">کاربران</div><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>کاربر</th><th>نقش</th><th>دسترسی‌ها</th><th>فعال</th><th></th></tr></thead><tbody>`+
 l.map(u=>{const me=u.id===App.user.id;return`<tr data-u="${u.id}"><td>${E(u.name)}<div class="small text-muted">${E(u.username)}</div></td>
 <td><select class="form-select form-select-sm r" ${me?'disabled':''}><option value="user" ${u.role==='user'?'selected':''}>کاربر</option><option value="admin" ${u.role==='admin'?'selected':''}>ادمین</option></select></td>
 <td>${Object.entries(PERMS).map(([k,t])=>`<label class="d-block small"><input type="checkbox" class="p" value="${k}" ${u.role==='admin'||u.perms.split(',').includes(k)?'checked':''}> ${t}</label>`).join('')}</td>
 <td><input type="checkbox" class="a" ${u.active?'checked':''} ${me?'disabled':''}></td>
 <td class="text-nowrap"><button class="btn btn-sm btn-primary" data-s>ذخیره</button> <button class="btn btn-sm btn-light" data-r>رمز</button> ${me?'':'<button class="btn btn-sm btn-outline-danger" data-d>حذف</button>'}</td></tr>`}).join('')+`</tbody></table></div></div>
 <div class="card"><div class="card-header">کاربر جدید</div><div class="card-body row g-2"><div class="col-md-3"><input id="nu" class="form-control" placeholder="نام کاربری (انگلیسی)"></div><div class="col-md-3"><input id="nn" class="form-control" placeholder="نام نمایشی"></div>
 <div class="col-md-3"><input id="np" class="form-control" placeholder="رمز اولیه (حداقل ۶)"></div><div class="col-md-3"><select id="nr" class="form-select"><option value="user">کاربر</option><option value="admin">ادمین</option></select></div>
 <div class="col-12">${Object.entries(PERMS).map(([k,t])=>`<label class="me-3"><input type="checkbox" class="np" value="${k}" ${k==='merge'||k==='files'?'checked':''}> ${t}</label>`).join('')}</div>
 <div class="col-12"><button class="btn btn-success" id="na">افزودن کاربر</button> <span class="small text-muted">کاربر جدید در اولین ورود مجبور به تغییر رمز است.</span></div></div></div>`}
$('#v-users').addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;const tr=b.closest('tr'),id=tr&&+tr.dataset.u;
 try{if(b.id==='na'){const u=$('#nu').value.trim(),p=$('#np').value;if(!/^[a-zA-Z0-9_.-]{3,}$/.test(u)||p.length<6)return toast('نام کاربری (۳+ حرف انگلیسی) و رمز (۶+) را درست وارد کنید');
   await App.addUser(u,$('#nn').value||u,p,$('#nr').value,[...document.querySelectorAll('.np:checked')].map(x=>x.value).join(','));toast('کاربر ساخته شد');await users()}
  else if(b.dataset.s!==undefined){const a=tr.querySelector('.a');await App.updUser(id,tr.querySelector('.r').value,[...tr.querySelectorAll('.p:checked')].map(x=>x.value).join(','),a.checked?1:0);toast('ذخیره شد')}
  else if(b.dataset.r!==undefined){const n=prompt('رمز جدید (کاربر در ورود بعدی آن را عوض می‌کند)');if(n&&n.length>=6){await App.setPw(id,n,1);toast('رمز تغییر کرد')}}
  else if(b.dataset.d!==undefined&&confirm('کاربر حذف شود؟')){await App.delUser(id);await users()}}catch(x){toast('خطا: '+x.message)}});
})();
