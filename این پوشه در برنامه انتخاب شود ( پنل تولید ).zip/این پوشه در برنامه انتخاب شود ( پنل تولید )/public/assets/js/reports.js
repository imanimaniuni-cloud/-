// بخش گزارشات: ورود خودکار آخرین فایل «ادغام‌شده» هر دسته به دیتابیس دائمی (data/reports.sqlite)
// و نمایش داده‌ها. «آخرین فایل ادغام‌شده» برای بازه‌ی تاریخیِ خودش مرجع است: ردیف‌های قدیمیِ همان بازه که دیگر در آن نیستند (ویرایش/حذف‌شده) پاک می‌شوند، ولی ردیف‌های خارج از بازه (مثلاً فروردین تا خرداد وقتی فایل جدید تیر تا شهریور است) همیشه می‌مانند؛ قبل از هر تغییر نسخه‌ی پشتیبان ساخته می‌شود.
(function(){
const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=n=>Number(n).toLocaleString('fa-IR'),dt=s=>new Date(s).toLocaleString('fa-IR');
const AUTH=new Set(['daily','stops']); // دسته‌هایی که آخرین فایل ادغام‌شده، مرجع کامل آن‌هاست
// ردیف‌های قدیمیِ «هم‌بازه» با فایل جدید: فقط ردیف‌هایی که تاریخشان بین کمترین و بیشترین تاریخ فایل جدید است و در آن نیستند.
// ردیف‌های خارج از این بازه (سابقه‌ی ماه‌های قبل) هرگز پاک نمی‌شوند.
function staleIds(rows,bid){const cur=[],old=[];rows.forEach(r=>{if(r.last_batch===bid)cur.push(r);else if(r.last_batch<bid)old.push(r)});
 if(!cur.length||!old.length)return[];
 const names=new Set();cur.forEach(r=>Object.keys(JSON.parse(r.data)).forEach(k=>names.add(k)));
 const dn=[...names].find(n=>/^تاریخ/.test(n));if(!dn)return[];
 let lo=1e9,hi=0;cur.forEach(r=>{const d=pjd(JSON.parse(r.data)[dn]);if(d){if(d<lo)lo=d;if(d>hi)hi=d}});if(!hi)return[];
 return old.filter(r=>{const d=pjd(JSON.parse(r.data)[dn]);return d&&d>=lo&&d<=hi}).map(r=>r.id)}
function dbRows(db,cat){const out=[],st=db.prepare('SELECT id,data,last_batch FROM rpt_rows WHERE cat=?');st.bind([cat]);while(st.step())out.push(st.getAsObject());st.free();return out}
function purgeIds(db,ids){ids.forEach(id=>db.run('DELETE FROM rpt_rows WHERE id=?',[id]));return ids.length}
const CATS={daily:{n:'گزارش‌های روزانه',i:'fa-clipboard-list'},stops:{n:'توقفات',i:'fa-stopwatch'}};
const dig=t=>String(t).replace(/[۰-۹]/g,d=>d.charCodeAt(0)-0x6F0).replace(/[٠-٩]/g,d=>d.charCodeAt(0)-0x660);
const nf=t=>dig(t).replace(/ي|ى/g,'ی').replace(/ك/g,'ک').replace(/[‌​‎‏ ]/g,' ').replace(/\s+/g,' ').trim();
const toast=m=>{if(window.toast)window.toast(m)};
function h53(str){let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<str.length;i++){const c=str.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}
 h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);
 return(4294967296*(2097151&h2)+(h1>>>0)).toString(36)}

// ---------- خواندن شیت داده از فایل ادغام‌شده ----------
function cellVal(c){if(!c||c.t==='z'||c.t==='e')return null;
 if(c.t==='s'){return String(c.v).trim()===''?null:c.v}
 if(c.t==='n'){if(c.z&&c.w&&XLSX.SSF.is_date(c.z))return c.w;return c.v}
 if(c.t==='d')return c.w||(c.v&&c.v.toISOString())||null;
 return c.v==null||c.v===''?null:c.v}
// شیت داده: همان منطق صفحه‌ی ادغام (best) اگر در دسترس بود
function pickSheet(wb){if(typeof best==='function'){try{return best(wb)}catch(e){}}return wb.SheetNames[0]}
function parse(buf,only){
 const wb=XLSX.read(buf,{type:'array',cellNF:true,cellText:true,bookVBA:true}),sheet=only||pickSheet(wb),ws=wb.Sheets[sheet];
 if(!ws)return null;
 const grid=new Map();let maxC=-1;
 for(const k in ws){if(k[0]==='!')continue;const c=ws[k];if(!c)continue;const v=cellVal(c);if(v==null)continue;
  const a=XLSX.utils.decode_cell(k);let r=grid.get(a.r);if(!r)grid.set(a.r,r=new Map());r.set(a.c,{v,f:!!c.f});if(a.c>maxC)maxC=a.c}
 // ردیف سرستون: ردیفی (در ۸ ردیف اول) که بیشترین متن را دارد
 let hr=-1,bn=0;for(let r=0;r<8;r++){const m=grid.get(r);if(!m)continue;let n=0;m.forEach(x=>{if(typeof x.v==='string')n++});if(n>bn){bn=n;hr=r}}
 if(hr<0)throw new Error('سرستون پیدا نشد');
 const used=new Set(),head=[];
 for(let c=0;c<=maxC;c++){const x=grid.get(hr).get(c);let has=false;for(const[r,m]of grid)if(r>hr&&m.has(c)){has=true;break}
  if(!x&&!has)continue;let n=x?nf(x.v):'ستون '+XLSX.utils.encode_col(c);if(!n)n='ستون '+XLSX.utils.encode_col(c);
  let u=n,i=2;while(used.has(u))u=n+' #'+(i++);used.add(u);head.push({c,n:u})}
 const recs=[],seen=new Map(),S=KSPEC(head.map(h=>h.n)),isLog=!!S.reason&&!S.st;
 [...grid.keys()].filter(r=>r>hr).sort((a,b)=>a-b).forEach(r=>{
  const m=grid.get(r);let konst=false;m.forEach(x=>{if(!x.f)konst=true});if(!konst)return; // فقط ردیف‌هایی که حداقل یک خانه‌ی ثابت (ورودی) دارند
  const data={},fp=[];
  for(const h of head){const x=m.get(h.c);if(!x)continue;data[h.n]=x.v;if(!x.f)fp.push(h.c+'='+nf(x.v))}
  // ردیف خالیِ قالب (فقط تاریخ/ماه/شیفت، بدون شناسه، محصول و تجهیز) ردیف داده نیست
  if(S.id&&!isLog&&data[S.id]==null&&data[S.prod]==null&&data[S.eq]==null)return;
  // کلید ردیف = هویت پایدار (شناسه ردیف؛ یا تاریخ+محصول+ساعت شروع/پایان+تجهیز). با ویرایش مقادیر، همان ردیف به‌روز می‌شود و تکراری ساخته نمی‌شود.
  // اگر هویت پایدار نبود: اثر انگشت خانه‌های ثابت (روش قبلی)
  const base=keyBase(data,S,isLog)||h53(fp.join('|')),k=(seen.get(base)||0)+1;seen.set(base,k);
  recs.push({rkey:base+'#'+k,rno:r+1,data:JSON.stringify(data)})});
 return{sheet,header:head.map(h=>h.n),recs}}


// ---------- هویت پایدار ردیف ----------
const KSPEC=names=>{const f=re=>names.find(n=>re.test(n));
 return{id:f(/^شناسه/),reason:f(/^دلیل/),date:f(/^تاریخ/),prod:f(/^(نوع محصول|شرح کالا)/),st:f(/^ساعت شروع/),en:f(/^ساعت پایان/),eq:f(/^(تجهیز$|دستگاه)/),sh:f(/^شیفت/)}};
function keyBase(o,S,isLog){const g=n=>n&&o[n]!=null?nf(o[n]):'';
 const id=g(S.id);if(id)return 'i:'+id+(isLog?'|'+g(S.reason):'');
 if(!isLog&&S.date&&S.prod&&S.st&&S.en&&g(S.date)&&g(S.prod))return 'n:'+h53([g(S.date),g(S.prod),g(S.st),g(S.en),g(S.eq)].join('|'));
 // گزارش روزانه (بدون شناسه و ساعت): تاریخ + شیفت + کالا + دستگاه؛ مستقل از مقدار سایر خانه‌ها و جای ستون‌ها
 if(!isLog&&!S.st&&S.date&&g(S.date)&&(g(S.prod)||g(S.eq)))return 'd:'+h53([g(S.date),g(S.sh),g(S.prod),g(S.eq)].join('|'));
 return null}
// یک‌بار: نسخه‌های قدیمیِ هر ردیف (که با هر ویرایش به‌عنوان ردیف جدید ثبت شده بود) در دیتابیس موجود یکی می‌شوند؛
// جدیدترین نسخه می‌ماند و تاریخ اولین ورود ردیف حفظ می‌شود. قبل از اجرا نسخه‌ی پشتیبان کامل ذخیره می‌شود.
async function migrate(){
 const v=(await App.rq('PRAGMA user_version'))[0];if(!v||v.user_version>=4)return 0;const ver=v.user_version;
 return await App.rtx(db=>{
  const all=[],st=db.prepare('SELECT id,cat,rkey,rno,data,first_batch,last_batch FROM rpt_rows');while(st.step())all.push(st.getAsObject());st.free();
  const by={};all.forEach(r=>(by[r.cat]=by[r.cat]||[]).push(r));let removed=0;
  db.run('BEGIN');
  try{
   if(ver<3)for(const cat in by){
    const names=new Set(),objs=by[cat].map(r=>{const o=JSON.parse(r.data);Object.keys(o).forEach(k=>names.add(k));return{r,o}});
    const S=KSPEC([...names]),isLog=!!S.reason&&!S.st,groups=new Map();
    for(const x of objs){const b=keyBase(x.o,S,isLog);if(b===null)continue;if(!groups.has(b))groups.set(b,[]);groups.get(b).push(x)}
    for(const[b,list]of groups){
     const L=Math.max(...list.map(x=>x.r.last_batch)),fb=Math.min(...list.map(x=>x.r.first_batch));
     const cur=list.filter(x=>x.r.last_batch===L).sort((a,c)=>(a.r.rno-c.r.rno)||(a.r.id-c.r.id));
     list.filter(x=>x.r.last_batch!==L).forEach(x=>{db.run('DELETE FROM rpt_rows WHERE id=?',[x.r.id]);removed++});
     cur.forEach((x,i)=>db.run('UPDATE rpt_rows SET rkey=?,first_batch=? WHERE id=?',[b+'#'+(i+1),fb,x.r.id]))}}
   // نسخه ۴: نسخه‌های قدیمیِ ردیف‌های ویرایش‌شده (۱۲۴ به‌جای ۱۱۲) که هم‌بازه با آخرین فایل‌اند پاک می‌شوند؛ سابقه‌ی خارج از بازه می‌ماند
   for(const cat of AUTH){const lb=db.exec('SELECT MAX(id) FROM rpt_batches WHERE cat=?',[cat]),L=lb.length?lb[0].values[0][0]:null;if(L==null)continue;
    removed+=purgeIds(db,staleIds(dbRows(db,cat),L))}
   db.run('PRAGMA user_version=4');db.run('COMMIT');return removed
  }catch(e){try{db.run('ROLLBACK')}catch(_){}throw e}},{backup:true})}
// ---------- ورود به دیتابیس ----------
async function ingest(cat,rec,first,only){
 const blob=await App.get(rec.stored);if(!blob)return{err:'فایل «'+rec.orig+'» در پوشه پیدا نشد'};
 const P=parse(await blob.arrayBuffer(),only)||{sheet:only||'',header:[],recs:[]};
 return await App.rtx(db=>{
  const dup=db.exec('SELECT 1 FROM rpt_batches WHERE cat=? AND file_id=? AND ts=?',[cat,rec.id,rec.ts]);if(dup.length)return{skipped:true};
  db.run('BEGIN');
  try{
   const ex=new Map(),st=db.prepare('SELECT rkey,data FROM rpt_rows WHERE cat=?');st.bind([cat]);while(st.step()){const o=st.get();ex.set(o[0],o[1])}st.free();
   db.run('INSERT INTO rpt_batches(cat,file_id,fname,ts,uploader,sheet,header,nrows) VALUES(?,?,?,?,?,?,?,?)',[cat,rec.id,rec.orig,rec.ts,rec.uploader,P.sheet,JSON.stringify(P.header),P.recs.length]);
   const bid=db.exec('SELECT last_insert_rowid()')[0].values[0][0];
   const ins=db.prepare('INSERT INTO rpt_rows(cat,rkey,rno,data,first_batch,last_batch) VALUES(?,?,?,?,?,?)'),
    upd=db.prepare('UPDATE rpt_rows SET rno=?,data=?,last_batch=? WHERE cat=? AND rkey=?');
   let added=0,changed=0;
   for(const r of P.recs){const old=ex.get(r.rkey);
    if(old===undefined){ins.run([cat,r.rkey,r.rno,r.data,bid,bid]);added++}
    else{if(old!==r.data)changed++;upd.run([r.rno,r.data,bid,cat,r.rkey])}}
   ins.free();upd.free();
   // ردیفِ قدیمیِ هم‌بازه که در فایل جدید نیست (ویرایش‌شده با هویت جدید یا حذف‌شده) پاک می‌شود؛ سابقه‌ی خارج از بازه‌ی تاریخ فایل می‌ماند. فایل بدون ردیف (خطای خواندن) چیزی پاک نمی‌کند.
   const missing=AUTH.has(cat)&&P.recs.length?purgeIds(db,staleIds(dbRows(db,cat),bid)):db.exec('SELECT COUNT(*) FROM rpt_rows WHERE cat=? AND last_batch<?',[cat,bid])[0].values[0][0];
   db.run('UPDATE rpt_batches SET added=?,changed=?,missing=? WHERE id=?',[added,changed,missing,bid]);
   db.run('COMMIT');return{added,changed,missing,total:P.recs.length,fname:rec.orig}
  }catch(e){try{db.run('ROLLBACK')}catch(_){}throw e}},{backup:first})}

// شناسه‌ی فایل در جدول files ممکن است بعد از بازسازی/بازگردانی data.sqlite دوباره از ۱ شروع شود و با file_idهای قدیمیِ reports.sqlite تداخل کند
// (فایل جدید «قبلاً وارد شده» حساب می‌شد و آخرین فایل ادغام‌شده وارد نمی‌شد). پس هویت فایل = شناسه + زمان ذخیره.
const fk=(id,ts)=>id+'|'+ts;
let busy=false;
// همه‌ی فایل‌های «ادغام‌شده»ی این دسته که هنوز وارد نشده‌اند، از قدیم به جدید (آخرین فایل = وضعیت «جاری»)
// لاگ توقفات پیش‌بینی‌نشده (شیت unplanned_log): از همه‌ی فایل‌های دسته‌ی توقفات (آپلودی و ادغام‌شده) جمع می‌شود
// چون ادغام فقط شیت داده را ادغام می‌کند و لاگ کاربران دیگر در فایل ادغام‌شده نمی‌آید؛ ردیف‌های مشابه یکی می‌شوند.
async function syncLog(){
 const all=await App.q("SELECT * FROM files WHERE cat='stops' AND kind IN ('merged','upload') ORDER BY id");
 const done=new Set((await App.rq("SELECT file_id,ts FROM rpt_batches WHERE cat='stops_log'")).map(x=>fk(x.file_id,x.ts)));
 let first=true,n=0;
 for(const f of all){if(done.has(fk(f.id,f.ts))||!/\.(xlsx|xlsm)$/i.test(f.orig))continue;
  try{const r=await ingest('stops_log',f,first,'unplanned_log');first=false;if(!r.err&&!r.skipped)n++}catch(e){console.error('لاگ توقفات',f.orig,e)}}
 const pr=await purgeLog();if(pr)toast('لاگ توقفات مطابق آخرین فایل ادغام‌شده شد: '+faN(pr)+' ردیف قدیمی حذف شد');
 return n}
// لاگ توقفات: فایل ادغام‌شده همه‌ی لاگ‌ها را دارد (و ستون‌های کد محصول/تجهیز آن فرمول‌اند). پس آخرین فایل ادغام‌شده مرجع است؛
// ردیف‌های قدیمیِ هم‌بازه‌ی آن که در آن نیستند (نسخه‌های قدیمیِ ردیف‌های ویرایش‌شده) حذف می‌شوند. ردیف‌های آپلودهای جدیدتر از ادغام دست‌نخورده می‌مانند.
async function purgeLog(){
 const mg=await App.q("SELECT id,ts FROM files WHERE cat='stops' AND kind='merged' ORDER BY id DESC LIMIT 1");if(!mg.length)return 0;
 const bt=(await App.rq("SELECT id,nrows FROM rpt_batches WHERE cat='stops_log' AND file_id=? AND ts=?",[mg[0].id,mg[0].ts]))[0];if(!bt||!bt.nrows)return 0;
 const ids=staleIds(await App.rq("SELECT id,data,last_batch FROM rpt_rows WHERE cat='stops_log'"),bt.id);if(!ids.length)return 0;
 const k=await App.rtx(db=>purgeIds(db,ids),{backup:true});if(k)App.alog('rpt_purge','لاگ توقفات مطابق آخرین فایل ادغام‌شده شد: '+k+' ردیف قدیمی حذف شد');return k}
async function sync(cat){
 if(busy)return null;busy=true;
 try{
  const rem=await migrate();if(rem){toast('تکراری‌های قدیمی یکی شد: '+faN(rem)+' ردیف');App.alog('rpt_purge','یکی‌شدن ردیف‌های تکراری قدیمی: '+rem+' ردیف')}
  const mg=await App.q("SELECT * FROM files WHERE kind='merged' AND cat=? ORDER BY id",[cat]);
  const done=new Set((await App.rq('SELECT file_id,ts FROM rpt_batches WHERE cat=?',[cat])).map(x=>fk(x.file_id,x.ts)));
  const todo=mg.filter(f=>!done.has(fk(f.id,f.ts)));
  let first=true,last=null,n=0;
  for(const f of todo){const r=await ingest(cat,f,first);first=false;if(r.err){toast(r.err);continue}if(!r.skipped){n++;last=r}}
  if(cat==='stops')await syncLog();
   if(n&&last)App.alog('rpt_sync','گزارشات «'+CATS[cat].n+'»: '+n+' فایل وارد شد | کل ردیف: '+last.total+' | جدید: '+last.added+(last.missing?' | حذف‌شده‌ی قدیمی: '+last.missing:''));
  return n?{n,last}:{uptodate:true,n:0}}
 finally{busy=false}}
async function syncAll(quiet){const out={};
 for(const c of Object.keys(CATS)){try{const r=await sync(c);out[c]=r;
   if(r&&r.n&&!quiet)toast('گزارشات «'+CATS[c].n+'» به‌روز شد: '+faN(r.last.total)+' ردیف (جدید: '+faN(r.last.added)+(r.last.missing?'، حذف‌شده‌ی قدیمی: '+faN(r.last.missing):'')+')')}
  catch(e){console.error(e);toast('همگام‌سازی گزارشات ('+CATS[c].n+') ناموفق: '+e.message)}}
 return out}

// ---------- نمایش ----------
let CAT='daily',ROWS=[],HEAD=[],META=null,CM={},VIEW=[],LOG=[],LCM={},LVIEW=[];
let DOPEN=false;const PG=100,FLT={},MON=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const COLS={daily:{date:/^تاریخ/,prod:/^شرح کالا/,eq:/^دستگاه/},stops:{date:/^تاریخ/,prod:/^نوع محصول/,eq:/^تجهیز$/,id:/^شناسه ردیف/,rate:/^نرخ تولید/}};
const newF=()=>({from:'',to:'',months:new Set(),prods:new Set(),eqs:new Set(),q:'',sort:'',dir:1,scope:'cur',page:0});
const pjd=v=>{if(v==null)return 0;const a=dig(v).trim().split(/[\/\-.]/).map(Number);return a.length===3&&a.every(x=>x>0)?a[0]*10000+a[1]*100+a[2]:0};
async function load(cat){
 const b=await App.rq('SELECT * FROM rpt_batches WHERE cat=? ORDER BY id DESC',[cat]);
 const latest=b[0]||null;
 const rows=latest?await App.rq('SELECT id,rno,data,first_batch,last_batch FROM rpt_rows WHERE cat=? ORDER BY first_batch,rno',[cat]):[];
 HEAD=latest?JSON.parse(latest.header):[];
 const known=new Set(HEAD);for(const bt of b.slice(1)){try{JSON.parse(bt.header).forEach(h=>{if(!known.has(h)){known.add(h);HEAD.push(h)}})}catch(e){}}
 CM={};for(const k in COLS[cat])CM[k]=HEAD.find(h=>COLS[cat][k].test(h));
 const mk=(r,cm,cur0)=>{const cur=true;const o=JSON.parse(r.data),d=pjd(o[cm.date]);
  return{id:r.id,rno:r.rno,o,cur,d,m:d?Math.floor(d/100)%100:0,p:cm.prod&&o[cm.prod]!=null?String(o[cm.prod]).trim():'',e:cm.eq&&o[cm.eq]!=null?String(o[cm.eq]).trim():'',hay:nf(r.data).toLowerCase()}};
 ROWS=rows.map(r=>mk(r,CM,!!latest&&r.last_batch===latest.id));
 LOG=[];LCM={};
 if(cat==='stops'){const lb=(await App.rq("SELECT header FROM rpt_batches WHERE cat='stops_log' AND nrows>0 ORDER BY id DESC LIMIT 1"))[0];
  if(lb){const lh=JSON.parse(lb.header),re={date:/^تاریخ/,prod:/^محصول$/,eq:/^تجهیز$/,reason:/^دلیل/,min:/^مدت/,id:/^شناسه/};for(const k in re)LCM[k]=lh.find(h=>re[k].test(h));
   LOG=(await App.rq("SELECT id,rno,data FROM rpt_rows WHERE cat='stops_log' ORDER BY first_batch,rno")).map(r=>mk(r,LCM,true))}}
 META={batches:b,latest,total:rows.length,cur:ROWS.filter(r=>r.cur).length};
 if(!FLT[cat])FLT[cat]=newF()}
// ===== فیلتر/مرتب‌سازی مشترک: خروجی همه‌ی نمودارها و جدول‌ها از همین‌جا می‌آید =====
function apply(){const F=FLT[CAT],a=pjd(F.from),b=pjd(F.to),t=nf(F.q).toLowerCase().split(' ').filter(Boolean);
 const pf=r=>(!a||r.d>=a)&&(!b||(r.d&&r.d<=b))&&(!F.months.size||F.months.has(r.m))&&(!F.prods.size||F.prods.has(r.p))&&(!F.eqs.size||F.eqs.has(r.e))&&t.every(w=>r.hay.includes(w));
 LVIEW=LOG.filter(pf); // لاگ توقفات: همان فیلترها (بدون محدوده‌ی «آخرین فایل»؛ همه‌ی فایل‌ها جمع می‌شوند)
 let l=ROWS.filter(pf);
 if(F.sort){const s=F.sort,dc=s===CM.date,dir=F.dir;
  l=l.slice().sort((x,y)=>{let c;if(dc)c=x.d-y.d;else{const u=x.o[s],v=y.o[s];c=(u==null)-(v==null);if(!c&&u!=null){c=typeof u==='number'&&typeof v==='number'?u-v:String(u).localeCompare(String(v),'fa',{numeric:true})}}
   return(c*dir)||(x.rno-y.rno)})}
 VIEW=l;return l}
const WID=[],OPEN={};
function renderWidgets(){const box=$('#rp-rep');if(!box)return;
 const ctx={cat:CAT,head:HEAD,cols:CM,months:MON,total:ROWS.length,log:LVIEW,logCols:LCM,all:ROWS};
 box.innerHTML=WID.length?'':`<div class="card"><div class="card-header"><i class="fa-solid fa-chart-column"></i> گزارش‌ها</div><div class="card-body text-muted small">گزارش‌های «${CATS[CAT].n}» اینجا اضافه می‌شوند. همه‌ی نمودارها و جدول‌ها خودکار از همین فیلترها (تاریخ، ماه، محصول، تجهیز، جستجو و مرتب‌سازی) پیروی می‌کنند.</div></div>`;
 WID.filter(w=>!w.cats||w.cats.includes(CAT)).forEach(w=>{
  if(w.bare){const b=document.createElement('div');b.className='rp-bare mb-3';box.appendChild(b);try{w.render(b,VIEW,ctx)}catch(e){console.error(e);b.textContent='خطا در ساخت گزارش: '+e.message}return}
  if(w.collapse){const d=document.createElement('details');d.className='card rp-det';d.open=!!OPEN[w.id];
   d.innerHTML=`<summary class="card-header" style="cursor:pointer"><i class="fa-solid ${w.icon||'fa-chart-column'}"></i> ${E(w.title)}<span class="small text-muted fw-normal ms-2">برای باز و بسته کردن کلیک کنید</span></summary><div class="card-body"></div>`;
   d.addEventListener('toggle',()=>{OPEN[w.id]=d.open});box.appendChild(d);
   try{w.render(d.querySelector('.card-body'),VIEW,ctx)}catch(e){console.error(e);d.querySelector('.card-body').textContent='خطا در ساخت گزارش: '+e.message}return}
  const c=document.createElement('div');c.className='card';c.innerHTML=`<div class="card-header"><i class="fa-solid ${w.icon||'fa-chart-column'}"></i> ${E(w.title)}</div><div class="card-body"></div>`;box.appendChild(c);
  try{w.render(c.querySelector('.card-body'),VIEW,ctx)}catch(e){console.error(e);c.querySelector('.card-body').textContent='خطا در ساخت گزارش: '+e.message}})}
function shellHtml(){return`<div id="rp-stats-w"><div class="stats" id="rp-stats"></div></div><div id="rp-src"></div><div id="rp-fb"></div><div id="rp-rep"></div><div id="rp-data"></div>`}
function paintTop(){
 const m=META,l=m.latest;
 $('#rp-stats').innerHTML=[['fa-database','ردیف‌های داده (مطابق آخرین فایل ادغام‌شده)',m.total,'st-b'],['fa-layer-group','دفعات ورود داده',m.batches.length,'st-p']]
  .map(s=>`<div class="stat ${s[3]}"><i class="fa-solid ${s[0]}"></i><div><div class="sn">${faN(s[2])}</div><div class="sl">${s[1]}</div></div></div>`).join('');
 const hist=m.batches.slice(0,8).map(b=>`<tr><td>${E(b.fname)}</td><td class="small">${dt(b.ts)}</td><td>${E(b.sheet)}</td><td>${faN(b.nrows)}</td><td><span class="badge b-g">+${faN(b.added||0)}</span></td><td>${faN(b.changed||0)}</td><td>${faN(b.missing||0)}</td></tr>`).join('');
 $('#rp-src').innerHTML=`<details class="card mb-3 rp-det"><summary class="card-header" style="cursor:pointer"><i class="fa-solid fa-plug"></i> منبع داده: آخرین فایل ادغام‌شده‌ی «${CATS[CAT].n}»${l?` <span class="small fw-normal text-muted">· ${E(l.fname)} · ${dt(l.ts)}</span>`:''}</summary><div class="card-body">
  ${l?`<div class="mb-2"><b>${E(l.fname)}</b> <span class="small text-muted">· شیت «${E(l.sheet)}» · ${dt(l.ts)}</span></div>`:'<div class="text-muted mb-2">هنوز فایل ادغام‌شده‌ای برای این دسته وارد نشده است. بعد از اولین «ثبت ادغام»، داده‌ها خودکار اینجا می‌آیند.</div>'}
  <div class="d-flex flex-wrap gap-2 align-items-center">
   ${App.can('merge')?'<button class="btn btn-success btn-sm" data-rp="sync"><i class="fa-solid fa-rotate"></i> همگام‌سازی با آخرین ادغام</button>':''}
   <button class="btn btn-primary btn-sm" data-rp="xl"><i class="fa-solid fa-file-excel"></i> دانلود فایل یکپارچه (بدون تکرار)</button>
   <button class="btn btn-light btn-sm" data-rp="dl"><i class="fa-solid fa-database"></i> دانلود پشتیبان دیتابیس گزارشات</button>
   <button class="btn btn-light btn-sm" data-rp="bk"><i class="fa-solid fa-clock-rotate-left"></i> فهرست پشتیبان‌ها</button>
   <span class="small text-muted">ورود داده خودکار است: بعد از هر «ثبت ادغام» و هنگام ورود به پنل.</span></div>
  <div id="rp-bk" class="mt-2"></div>
  ${hist?`<div class="table-responsive mt-3"><table class="table table-sm align-middle mb-0"><thead><tr><th>فایل</th><th>زمان فایل</th><th>شیت</th><th>ردیف</th><th>جدید</th><th>ویرایش‌شده</th><th>حذف‌شده از داده</th></tr></thead><tbody>${hist}</tbody></table></div>`:''}
  </div></details>`}
// نوار فیلتر (یک‌بار ساخته می‌شود؛ تغییرها فقط داده/نمودارها را تازه می‌کنند)
function distinct(k){const m=new Map();ROWS.forEach(r=>{const v=r[k];if(v!==''&&v!==0)m.set(v,(m.get(v)||0)+1)});return[...m.entries()]}
function msHtml(key,label,items){const F=FLT[CAT],set=F[key];
 return`<details class="ms" data-k="${key}"><summary class="form-select"><span class="ms-l">${label}</span> <span class="badge bg-secondary ms-n"></span></summary><div class="ms-box">
  <input class="form-control form-control-sm mb-2 ms-s" placeholder="جستجو…"><div class="ms-list">${items.map(([v,t,n])=>`<label class="d-flex gap-2 align-items-center py-1"><input type="checkbox" value="${E(v)}" ${set.has(v)?'checked':''}><span class="flex-fill">${E(t)}</span><span class="small text-muted">${faN(n)}</span></label>`).join('')||'<div class="small text-muted">موردی نیست</div>'}</div>
  <button class="btn btn-sm btn-light mt-2" data-msclr="${key}">پاک کردن</button></div></details>`}
function paintFilters(){const F=FLT[CAT],box=$('#rp-fb');if(!META.latest){box.innerHTML='';return}
 const mon=distinct('m').sort((a,b)=>a[0]-b[0]).map(([v,n])=>[v,MON[v-1]||('ماه '+v),n]),
  pr=distinct('p').sort((a,b)=>a[0].localeCompare(b[0],'fa',{numeric:true})).map(([v,n])=>[v,v,n]),
  eq=distinct('e').sort((a,b)=>a[0].localeCompare(b[0],'fa',{numeric:true})).map(([v,n])=>[v,v,n]);
 box.innerHTML=`<div class="card filt"><div class="card-body"><div class="row g-2 align-items-end">
  <div class="col-6 col-md-2"><label class="flbl">از تاریخ (شمسی)</label><input id="rf-from" class="form-control" placeholder="۱۴۰۵/۰۷/۰۱" inputmode="numeric" value="${E(F.from)}"></div>
  <div class="col-6 col-md-2"><label class="flbl">تا تاریخ (شمسی)</label><input id="rf-to" class="form-control" placeholder="۱۴۰۵/۰۷/۳۰" inputmode="numeric" value="${E(F.to)}"></div>
  <div class="col-6 col-md-2"><label class="flbl">ماه</label>${msHtml('months','ماه',mon)}</div>
  <div class="col-6 col-md-3"><label class="flbl">${E(CATS[CAT].n==='توقفات'?'محصول':'کالا')}</label>${msHtml('prods','محصول',pr)}</div>
  <div class="col-12 col-md-3"><label class="flbl">${CAT==='stops'?'تجهیز':'دستگاه'}</label>${msHtml('eqs',CAT==='stops'?'تجهیز':'دستگاه',eq)}</div>
  <div class="col-12 col-md-4"><label class="flbl">جستجو در همه‌ی ستون‌ها</label><div class="input-icon"><i class="fa-solid fa-magnifying-glass"></i><input id="rf-q" class="form-control" placeholder="هر کلمه‌ای…" value="${E(F.q)}"></div></div>
  <div class="col-8 col-md-3"><label class="flbl">مرتب‌سازی بر اساس</label><select id="rf-sort" class="form-select"><option value="">ترتیب اصلی</option>${HEAD.map(h=>`<option ${F.sort===h?'selected':''} value="${E(h)}">${E(h)}</option>`).join('')}</select></div>
  <div class="col-4 col-md-2"><label class="flbl">جهت</label><select id="rf-dir" class="form-select"><option value="1" ${F.dir>0?'selected':''}>صعودی</option><option value="-1" ${F.dir<0?'selected':''}>نزولی</option></select></div>
  </div><div class="d-flex align-items-center gap-3 mt-3"><span class="small" id="rf-cnt"></span><button class="btn btn-sm btn-light ms-auto" data-rfclr><i class="fa-solid fa-filter-circle-xmark"></i> پاک کردن همه‌ی فیلترها</button></div></div></div>`;
 syncMs()}
function syncMs(){const F=FLT[CAT];document.querySelectorAll('#rp-fb .ms').forEach(d=>{const n=F[d.dataset.k].size,b=d.querySelector('.ms-n');b.textContent=n?faN(n):'';b.style.display=n?'':'none';d.classList.toggle('act',!!n)})}
function refresh(keepPage){const F=FLT[CAT];if(!keepPage)F.page=0;apply();
 const c=$('#rf-cnt');if(c)c.innerHTML=`<b>${faN(VIEW.length)}</b> ردیف از ${faN(F.scope==='all'?ROWS.length:F.scope==='old'?META.total-META.cur:META.cur)}`;
 syncMs();renderWidgets();paintData();window.dispatchEvent(new CustomEvent('reports:filtered',{detail:{cat:CAT,rows:VIEW}}))}
function paintData(){
 const m=META,F=FLT[CAT];if(!m.latest){$('#rp-data').innerHTML='';return}
 const list=VIEW,pages=Math.max(1,Math.ceil(list.length/PG));if(F.page>=pages)F.page=pages-1;
 const sl=list.slice(F.page*PG,F.page*PG+PG),arrow=h=>F.sort===h?(F.dir>0?' ▲':' ▼'):'';
 const body=sl.map(r=>{const d=r.o;
  return`<tr class="${r.cur?'':'rp-old'}"><td class="text-muted">${faN(r.rno)}</td>${HEAD.map(h=>`<td>${d[h]==null?'':E(typeof d[h]==='number'?+d[h].toFixed(4):d[h])}</td>`).join('')}<td>${r.cur?'':'<span class="badge b-o">قدیمی</span>'}</td></tr>`}).join('');
 const was=document.querySelector('#rp-data details');if(was)DOPEN=was.open;
 $('#rp-data').innerHTML=`<details class="card rp-det" ${DOPEN?'open':''}><summary class="card-header" style="cursor:pointer"><i class="fa-solid fa-table-list"></i> داده‌ی ذخیره‌شده <span class="badge bg-secondary">${faN(list.length)}</span><span class="small text-muted fw-normal ms-2">برای باز و بسته کردن کلیک کنید · برای مرتب‌سازی روی عنوان ستون کلیک کنید</span></summary><div class="card-body">
  <div class="pv rp-tbl"><table class="table table-sm table-bordered mb-0"><thead><tr><th>ردیف</th>${HEAD.map(h=>`<th data-sh="${E(h)}" style="cursor:pointer">${E(h)}${arrow(h)}</th>`).join('')}<th></th></tr></thead><tbody>${body||`<tr><td colspan="${HEAD.length+2}" class="text-center text-muted py-4">موردی با این فیلترها پیدا نشد</td></tr>`}</tbody></table></div>
  <div class="d-flex gap-2 mt-3 align-items-center"><button class="btn btn-light btn-sm" data-pg="-1" ${F.page?'':'disabled'}>قبلی</button><button class="btn btn-light btn-sm" data-pg="1" ${F.page<pages-1?'':'disabled'}>بعدی</button><span class="small text-muted">صفحه ${faN(F.page+1)} از ${faN(pages)}</span></div></div></details>`}
async function show(cat){
 if(cat)CAT=cat;const v=$('#v-reports');if(!v.dataset.init){v.innerHTML=shellHtml();v.dataset.init=1}
 try{if(App.can('merge'))await sync(CAT)}catch(e){console.error(e);toast('همگام‌سازی ناموفق: '+e.message)}
 await load(CAT);paintTop();paintFilters();refresh(true)}
// رویدادهای فیلتر
const fbEv=e=>{const t=e.target,F=FLT[CAT];if(!F||!t.closest('#rp-fb'))return;
 if(t.id==='rf-from')F.from=t.value;else if(t.id==='rf-to')F.to=t.value;else if(t.id==='rf-q')F.q=t.value;
 else if(t.id==='rf-sort')F.sort=t.value;else if(t.id==='rf-dir')F.dir=+t.value;
 else if(t.closest('.ms-s')||t.classList.contains('ms-s')){const q=nf(t.value).toLowerCase();t.closest('.ms-box').querySelectorAll('.ms-list label').forEach(l=>l.style.display=nf(l.textContent).toLowerCase().includes(q)?'':'none');return}
 else if(t.type==='checkbox'){const k=t.closest('.ms').dataset.k,v=k==='months'?+t.value:t.value;t.checked?F[k].add(v):F[k].delete(v)}
 else return;refresh()};
document.addEventListener('input',fbEv);document.addEventListener('change',e=>{if(e.target.type==='checkbox'||e.target.tagName==='SELECT')fbEv(e)});
document.addEventListener('click',e=>{if(!e.target.closest('.ms'))document.querySelectorAll('#rp-fb .ms[open]').forEach(d=>d.open=false);
 else{const me=e.target.closest('.ms');document.querySelectorAll('#rp-fb .ms[open]').forEach(d=>{if(d!==me)d.open=false})}});
document.addEventListener('click',async e=>{
 const v=e.target.closest('#v-reports');if(!v)return;
 const F=FLT[CAT];
 const sc=e.target.closest('[data-sc]');if(sc){F.scope=sc.dataset.sc;paintFilters();refresh();return}
 const pg=e.target.closest('[data-pg]');if(pg){F.page+=+pg.dataset.pg;paintData();return}
 const sh=e.target.closest('[data-sh]');if(sh){const h=sh.dataset.sh;if(F.sort===h)F.dir*=-1;else{F.sort=h;F.dir=1}paintFilters();refresh();return}
 const mc=e.target.closest('[data-msclr]');if(mc){F[mc.dataset.msclr].clear();mc.closest('.ms').querySelectorAll('input[type=checkbox]').forEach(c=>c.checked=false);refresh();return}
 if(e.target.closest('[data-rfclr]')){FLT[CAT]=newF();paintFilters();refresh();return}
 const b=e.target.closest('[data-rp]');if(!b)return;
 try{
  if(b.dataset.rp==='sync'){b.disabled=true;const r=await sync(CAT);await load(CAT);paintTop();paintFilters();refresh(true);toast(r&&r.n?'به‌روز شد: '+faN(r.last.total)+' ردیف (جدید: '+faN(r.last.added)+(r.last.missing?'، حذف‌شده‌ی قدیمی: '+faN(r.last.missing):'')+')':'همه‌چیز به‌روز است')}
  else if(b.dataset.rp==='xl'){
   const rows=ROWS.slice().sort((a,c)=>(a.d-c.d)||(a.rno-c.rno)),wb=XLSX.utils.book_new();
   const sheet=(head,list)=>{const ws=XLSX.utils.aoa_to_sheet([head].concat(list.map(r=>head.map(h=>r.o[h]==null?'':r.o[h]))));
    ws['!cols']=head.map(h=>({wch:Math.min(34,Math.max(10,String(h).length*0.9))}));ws['!freeze']={xSplit:0,ySplit:1};return ws};
   XLSX.utils.book_append_sheet(wb,sheet(HEAD,rows),CATS[CAT].n.slice(0,31));
   if(CAT==='stops'&&LOG.length){const lh=[];LOG.forEach(r=>Object.keys(r.o).forEach(k=>{if(!lh.includes(k))lh.push(k)}));
    XLSX.utils.book_append_sheet(wb,sheet(lh,LOG.slice().sort((a,c)=>(a.d-c.d)||(a.rno-c.rno))),'لاگ توقفات')}
   wb.Workbook={Views:[{RTL:true}]};
   dl(new Blob([XLSX.write(wb,{type:'array',bookType:'xlsx'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),'unified-'+CAT+'-'+new Date().toISOString().slice(0,10)+'.xlsx');
   toast('فایل یکپارچه ساخته شد: '+faN(rows.length)+' ردیف یکتا')}
  else if(b.dataset.rp==='dl'){const f=await App.rfile();if(!f)return toast('هنوز دیتابیس گزارشات ساخته نشده');dl(f,'reports-backup-'+new Date().toISOString().slice(0,10)+'.sqlite')}
  else if(b.dataset.rp==='bk'){const l=await App.backups();$('#rp-bk').innerHTML=l.length?`<div class="small">${l.slice(0,40).map(x=>`<a href="#" data-bkd="${E(x.name)}" class="me-3 d-inline-block">${E(x.name)}</a>`).join('')}</div>`:'<div class="small text-muted">هنوز پشتیبانی ساخته نشده (بعد از اولین ورود داده ساخته می‌شود).</div>'}
 }catch(x){console.error(x);toast('خطا: '+x.message);b.disabled=false}});
document.addEventListener('click',async e=>{const a=e.target.closest('[data-bkd]');if(!a)return;e.preventDefault();const f=await App.getBackup(a.dataset.bkd);if(f)dl(f,a.dataset.bkd)});
function dl(f,name){if(window.App&&App.alog)App.alog('download','«'+name+'» (گزارشات)');const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
window.Reports={show,sync,syncAll,CATS,_parse:parse,rows:()=>VIEW,data:()=>({rows:ROWS,log:LOG,head:HEAD,cm:CM,lcm:LCM}),register:w=>{const ai=w.after?WID.findIndex(x=>x.id===w.after):-1;if(w.first)WID.unshift(w);else if(ai>=0)WID.splice(ai+1,0,w);else WID.push(w);if($('#rp-rep')&&META)renderWidgets()}};
})();
