// خروجی دقیق: فایل اول (قالب) به‌صورت zip باز می‌شود و فقط <sheetData> شیت داده جایگزین می‌شود.
// استایل، تم، شیت‌ها، فرمول‌ها، ماکرو، شرط‌های رنگی، اعتبارسنجی، عرض ستون و ... دست‌نخورده می‌مانند.
(function (root) {
  const esc = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const ERR = { 0: '#NULL!', 7: '#DIV/0!', 15: '#VALUE!', 23: '#REF!', 29: '#NAME?', 36: '#NUM!', 42: '#N/A' };
  const isX = n => /\.(xlsx|xlsm)$/i.test(n);
  const attrs = str => { const o = {}, re = /([\w:.-]+)="([^"]*)"/g; let m; while ((m = re.exec(str))) o[m[1]] = m[2]; return o; };

  function colNum(l) { let n = 0; for (const ch of l) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; }
  function colName(c) { let s = ''; c++; while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = Math.floor((c - m) / 26); } return s; }
  function decode(ref) { const m = /^([A-Z]+)(\d+)$/.exec(ref); return m ? { c: colNum(m[1]), r: +m[2] - 1 } : null; }

  async function sheetPath(zip, name) {
    const wbx = await zip.file('xl/workbook.xml').async('string');
    const rel = await zip.file('xl/_rels/workbook.xml.rels').async('string');
    let rid = null; const re = /<sheet\b([^>]*?)\/?>/g; let m;
    while ((m = re.exec(wbx))) { const a = attrs(m[1]); const nm = a.name && a.name.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'"); if (nm === name) { rid = a['r:id']; break; } }
    if (!rid) throw new Error('sheet-not-found:' + name);
    const rr = /<Relationship\b([^>]*?)\/?>/g;
    while ((m = rr.exec(rel))) { const a = attrs(m[1]); if (a.Id === rid) { let t = a.Target; t = t[0] === '/' ? t.slice(1) : 'xl/' + t; return t; } }
    throw new Error('rel-not-found');
  }

  // از XML شیت: استایل (s) هر خانه و ویژگی‌های هر ردیف (ارتفاع، مخفی بودن، ...)
  function sheetInfo(xml) {
    const cells = new Map(), rows = new Map(); let m;
    const rr = /<row\b([^>]*?)\/?>/g;
    while ((m = rr.exec(xml))) {
      const a = attrs(m[1]); if (!a.r) continue; delete a.spans;
      const r = +a.r - 1; delete a.r;
      rows.set(r, Object.entries(a).map(([k, v]) => ` ${k}="${v}"`).join(''));
    }
    const cr = /<c\b([^>]*?)\/?>/g;
    while ((m = cr.exec(xml))) {
      const a = attrs(m[1]); const p = a.r && decode(a.r); if (!p) continue;
      if (a.s != null) cells.set(p.r + ',' + p.c, a.s);
    }
    return { cells, rows };
  }

  function cellXml(ref, s, m) {
    const sa = s != null ? ` s="${s}"` : '';
    const f = (m.f != null && m.f !== '') ? (m.F ? `<f t="array" ref="${esc(m.F)}">${esc(m.f)}</f>` : `<f>${esc(m.f)}</f>`) : '';
    if (m.t === 'z') return `<c r="${ref}"${sa}>${f}</c>`;
    if (m.t === 'n') return m.v == null || m.v === '' ? `<c r="${ref}"${sa}>${f}</c>` : `<c r="${ref}"${sa}>${f}<v>${m.v}</v></c>`;
    if (m.t === 'b') return `<c r="${ref}"${sa} t="b">${f}<v>${m.v ? 1 : 0}</v></c>`;
    if (m.t === 'e') return `<c r="${ref}"${sa} t="e">${f}<v>${esc(ERR[m.v] || m.w || '#VALUE!')}</v></c>`;
    if (m.v == null) return `<c r="${ref}"${sa}>${f}</c>`;
    const txt = String(m.v);
    if (f) return `<c r="${ref}"${sa} t="str">${f}<v>${esc(txt)}</v></c>`;
    return `<c r="${ref}"${sa} t="inlineStr"><is><t xml:space="preserve">${esc(txt)}</t></is></c>`;
  }

  function mergeRef(m) {
    if (typeof m === 'string') return m.trim();
    if (!m || !m.s || !m.e) return '';
    return `${colName(m.s.c)}${m.s.r + 1}:${colName(m.e.c)}${m.e.r + 1}`;
  }
  function refBounds(ref) {
    const m = /^([A-Z]+\d+)(?::([A-Z]+\d+))?$/i.exec(ref || '');
    if (!m) return null;
    const a = decode(m[1].toUpperCase()), b = decode((m[2] || m[1]).toUpperCase());
    return a && b ? { r: Math.max(a.r, b.r), c: Math.max(a.c, b.c) } : null;
  }
  function mergeRefs(xml, resultMerges) {
    const refs = [], seen = new Set();
    const add = ref => {
      ref = String(ref || '').trim();
      if (!/^[A-Z]+\d+:[A-Z]+\d+$/i.test(ref)) return;
      const key = ref.toUpperCase();
      if (!seen.has(key)) { seen.add(key); refs.push(key); }
    };
    const block = /<mergeCells\b[^>]*>([\s\S]*?)<\/mergeCells\s*>|<mergeCells\b[^>]*\/>/i.exec(xml);
    if (block && block[1]) {
      const re = /<mergeCell\b([^>]*?)\/?\s*>/gi; let m;
      while ((m = re.exec(block[1]))) add(attrs(m[1]).ref);
    }
    for (const m of (resultMerges || [])) add(mergeRef(m));
    return refs;
  }
  function putMergeCells(xml, refs) {
    const tag = refs.length ? `<mergeCells count="${refs.length}">${refs.map(r => `<mergeCell ref="${r}"/>`).join('')}</mergeCells>` : '';
    const old = /<mergeCells\b[^>]*>[\s\S]*?<\/mergeCells\s*>|<mergeCells\b[^>]*\/>/i;
    if (old.test(xml)) return xml.replace(old, tag);
    if (!tag) return xml;
    const sd = /<sheetData\b[^>]*?(?:\/>|>[\s\S]*?<\/sheetData\s*>)/i.exec(xml);
    if (!sd) throw new Error('no-sheetData');
    const after = sd.index + sd[0].length;
    const tail = xml.slice(after);
    const beforeMerge = new Set(['sheetCalcPr','sheetProtection','protectedRanges','scenarios','autoFilter','sortState','dataConsolidate','customSheetViews']);
    const tags = /<(?!\?|!--|\/)([A-Za-z][\w.-]*)\b[^>]*?(?:\/>|>)/g; let m, pos = tail.length;
    while ((m = tags.exec(tail))) {
      if (!beforeMerge.has(m[1])) { pos = m.index; break; }
    }
    return xml.slice(0, after + pos) + tag + xml.slice(after + pos);
  }

  const isEmp = v => v == null || (typeof v === 'string' && v.trim() === '');
  // جدول‌های (Table) یک شیت: [{path, ref}]
  async function tableRefs(zip, sheetP, xml) {
    const out = [], re = /<tablePart\b[^>]*?r:id="([^"]+)"/g; let m;
    const dir = sheetP.replace(/[^/]+$/, ''), file = sheetP.slice(dir.length);
    const rp = dir + '_rels/' + file + '.rels';
    if (!zip.file(rp)) return out;
    const rels = await zip.file(rp).async('string');
    while ((m = re.exec(xml))) {
      const rid = m[1], rr = /<Relationship\b([^>]*?)\/?>/g; let x;
      while ((x = rr.exec(rels))) {
        const a = attrs(x[1]); if (a.Id !== rid) continue;
        let tp = a.Target; tp = tp[0] === '/' ? tp.slice(1) : (dir + tp).replace(/[^/]+\/\.\.\//g, '');
        if (!zip.file(tp)) continue;
        const tx = await zip.file(tp).async('string'), rf = /<table\b[^>]*?\sref="([^"]+)"/.exec(tx);
        if (rf) out.push({ path: tp, ref: rf[1], xml: tx });
      }
    }
    return out;
  }
  function rangeOf(ref) {
    const m = /^([A-Z]+\d+):([A-Z]+\d+)$/i.exec(ref || ''); if (!m) return null;
    const a = decode(m[1].toUpperCase()), b = decode(m[2].toUpperCase());
    return a && b ? { r1: a.r, c1: a.c, r2: b.r, c2: b.c } : null;
  }
  // آخرین ستونِ پر در ردیف سرستون: ردیفی (در ۸ ردیف اول) که بیشترین خانه‌ی پر را دارد
  function guessHeader(cells) {
    const cnt = new Map(), last = new Map();
    cells.forEach((m, key) => { const [r, c] = key.split(',').map(Number); if (r > 7 || m.f || isEmp(m.v)) return; cnt.set(r, (cnt.get(r) || 0) + 1); last.set(r, Math.max(last.get(r) || 0, c)); });
    let b = -1, n = 0; cnt.forEach((v, r) => { if (v > n) { n = v; b = r; } });
    return b < 0 ? { hr: 0, lc: 0 } : { hr: b, lc: last.get(b) };
  }

  // ===== ادغام شیت unplanned_log (لاگ توقفات پیش‌بینی‌نشده) =====
  // ردیف‌های لاگ همه‌ی فایل‌ها (به‌صورت multiset: هر ردیف تکراریِ واقعی حفظ می‌شود) به انتهای لاگ قالب اضافه می‌شود.
  function logEntries(ws, X) {
    if (!ws || !ws['!ref']) return { list: [], last: 0 };
    const rg = X.utils.decode_range(ws['!ref']), list = []; let last = 0;
    for (let r = 1; r <= rg.e.r; r++) {
      const a = ws[X.utils.encode_cell({ r, c: 0 })];
      if (!a || isEmp(a.v)) continue;
      const cells = [], parts = [];
      for (let c = 0; c < 6; c++) {
        const x = ws[X.utils.encode_cell({ r, c })];
        cells.push(x && !isEmp(x.v) ? x : null);
        parts.push(x && x.v != null ? String(x.v).trim() : '');
      }
      list.push({ key: parts.join('|'), cells }); last = r;
    }
    return { list, last };
  }
  const shiftF = (f, from, to) => f.replace(new RegExp('(?<![A-Za-z$0-9_.])([A-Z]{1,3})' + from + '(?![0-9])', 'g'), '$1' + to);
  async function mergeLog(tz, files, notes, X) {
    const NAME = 'unplanned_log';
    const hasSheet = f => f.wb && f.wb.Sheets && f.wb.Sheets[NAME];
    if (!hasSheet(files[0]) || files.length < 2) return;
    const lp = await sheetPath(tz, NAME);
    let lx = await tz.file(lp).async('string');
    const linfo = sheetInfo(lx);
    const base = logEntries(files[0].wb.Sheets[NAME], X);
    const have = new Map(); base.list.forEach(e => have.set(e.key, (have.get(e.key) || 0) + 1));
    const add = [];
    for (let i = 1; i < files.length; i++) {
      if (!hasSheet(files[i])) continue;
      const cnt = new Map(), cur = logEntries(files[i].wb.Sheets[NAME], X);
      cur.list.forEach(e => {
        const k = (cnt.get(e.key) || 0) + 1; cnt.set(e.key, k);
        if (k > (have.get(e.key) || 0)) { have.set(e.key, k); add.push(e); }
      });
    }
    if (!add.length) return;
    // فرمول‌های ستون G..I از اولین ردیف دادهٔ لاگ قالب (و در نبودش ردیف ۲)
    const t0 = files[0].wb.Sheets[NAME], fr = base.list.length ? base.last : 1;
    const fm = [6, 7, 8].map(c => { const x = t0[X.utils.encode_cell({ r: 1, c })]; return x && x.f ? x.f : null; });
    const styleOf = (r, c) => { const k = r + ',' + c; return linfo.cells.get(k) ?? linfo.cells.get(fr + ',' + c); };
    let n0 = base.last + 1, lastRow = 0;
    add.forEach((e, i) => {
      const r = n0 + i, rn = r + 1; lastRow = rn;
      let cx = '';
      for (let c = 0; c < 6; c++) {
        const x = e.cells[c]; if (!x) continue;
        cx += cellXml(colName(c) + rn, styleOf(r, c), { t: x.t, v: x.v, f: null });
      }
      [6, 7, 8].forEach((c, j) => { if (fm[j]) cx += cellXml(colName(c) + rn, styleOf(r, c), { t: 's', v: '', f: shiftF(fm[j], 2, rn) }); });
      const row = `<row r="${rn}" spans="1:9">${cx}</row>`;
      const rr = new RegExp('<row r="' + rn + '"[^>]*?(?:/>|>[\\s\\S]*?</row>)');
      if (rr.test(lx)) lx = lx.replace(rr, () => row); else lx = lx.replace(/<\/sheetData\s*>/, () => row + '</sheetData>');
    });
    const dm = /<dimension\b[^>]*\bref="([^"]+)"[^>]*\/>/i.exec(lx), db = dm && refBounds(dm[1]);
    if (db && lastRow - 1 > db.r) lx = lx.replace(dm[0], `<dimension ref="A1:${colName(db.c)}${lastRow}"/>`);
    tz.file(lp, lx);
    notes.push(`لاگ توقفات پیش‌بینی‌نشده: ${add.length} ردیف جدید از فایل‌های دیگر به شیت unplanned_log اضافه شد.`);
  }
  async function build({ files, result, an, JSZip }) {
    const t = files[0], notes = [];
    if (!isX(t.name) || !t.buf) throw new Error('template-not-xlsx');
    const tz = await JSZip.loadAsync(t.buf);
    const tp = await sheetPath(tz, t.sheet);
    const txml = await tz.file(tp).async('string');
    const tinfo = sheetInfo(txml);
    const tsty = tz.file('xl/styles.xml') ? await tz.file('xl/styles.xml').async('string') : '';

    // ناحیهٔ داده: فقط از ردیف بعد از سرستون قالب (جدول) به پایین از فایل‌های ادغام‌شده می‌آید؛
    // سطرهای بالا (عنوان/سرستون) و ستون‌های بیرون از جدول قالب دست‌نخورده از خود قالب می‌مانند.
    const tbls = await tableRefs(tz, tp, txml);
    const tr = tbls.length ? rangeOf(tbls[0].ref) : null;
    const gh = guessHeader(t.data.cells);
    const dataStart = (tr ? tr.r1 : gh.hr) + 1, lastTC = tr ? tr.c2 : Math.max(gh.lc, t.data.maxC);
    const rc = new Map(); let dropped = 0, maxDataRow = -1;
    t.data.cells.forEach((m, key) => { const [r] = key.split(',').map(Number); if (r < dataStart) rc.set(key, Object.assign({}, m, { fi: 0 })); });
    result.cells.forEach((m, key) => {
      const [r, c] = key.split(',').map(Number);
      if (r < dataStart) return;
      if (c > lastTC) { if (!m.f && !isEmp(m.v)) dropped++; return; }
      rc.set(key, m);
      if (c === 0 && !m.f && !isEmp(m.v) && r > maxDataRow) maxDataRow = r;
    });
    if (dropped) notes.push(`${dropped} خانه‌ی داده در ستون‌های بیرون از جدول قالب بود و منتقل نشد.`);

    // اطلاعات استایل سایر فایل‌ها (فقط در صورت یکسان بودن styles.xml با قالب قابل اتکاست)
    const infos = [{ cells: tinfo.cells, same: true }];
    for (let i = 1; i < files.length; i++) {
      const f = files[i];
      if (!isX(f.name) || !f.buf) { infos.push(null); notes.push(`«${f.name}» xlsx/xlsm نیست؛ استایل خانه‌هایش از قالب گرفته شد.`); continue; }
      try {
        const z = await JSZip.loadAsync(f.buf), p = await sheetPath(z, f.sheet);
        const info = sheetInfo(await z.file(p).async('string'));
        const sty = z.file('xl/styles.xml') ? await z.file('xl/styles.xml').async('string') : '';
        info.same = sty === tsty;
        if (!info.same) notes.push(`استایل‌های «${f.name}» با قالب فرق دارد؛ برای خانه‌هایش استایل قالب استفاده شد.`);
        infos.push(info);
      } catch (e) { infos.push(null); }
    }
    const pick = (fi, r, c) => {
      const k = r + ',' + c, inf = infos[fi];
      if (inf && inf.same) { const s = inf.cells.get(k); if (s != null) return s; }
      return tinfo.cells.get(k);
    };

    // ردیف‌ها = ردیف‌های داده‌ی ادغام‌شده + ردیف/خانه‌های استایل‌دار قالب
    const byRow = new Map();
    rc.forEach((m, key) => { const [r, c] = key.split(',').map(Number); if (!byRow.has(r)) byRow.set(r, new Map()); byRow.get(r).set(c, m); });
    const tRowCols = new Map();
    tinfo.cells.forEach((s, key) => { const [r, c] = key.split(',').map(Number); if (!tRowCols.has(r)) tRowCols.set(r, new Set()); tRowCols.get(r).add(c); });
    const rowSet = new Set([...byRow.keys(), ...tRowCols.keys(), ...tinfo.rows.keys()]);
    let maxR = 0, maxC = 0, out = '';
    for (const r of [...rowSet].sort((a, b) => a - b)) {
      const mm = byRow.get(r) || new Map(), cols = new Set([...mm.keys(), ...(tRowCols.get(r) || [])]);
      let cx = '';
      for (const c of [...cols].sort((a, b) => a - b)) {
        const ref = colName(c) + (r + 1), m = mm.get(c);
        if (m) { cx += cellXml(ref, pick(m.fi == null ? 0 : m.fi, r, c), m); }
        else { const s = tinfo.cells.get(r + ',' + c); if (s != null && s !== '0') cx += `<c r="${ref}" s="${s}"/>`; else continue; }
        if (r > maxR) maxR = r; if (c > maxC) maxC = c;
      }
      const ra = tinfo.rows.get(r) || '';
      if (cx) out += `<row r="${r + 1}"${ra}>${cx}</row>`;
      else if (ra) out += `<row r="${r + 1}"${ra}/>`;
    }
    const sdRe = /<sheetData\b[^>]*?(?:\/>|>[\s\S]*?<\/sheetData\s*>)/i;
    if (!sdRe.test(txml)) throw new Error('no-sheetData');
    let nx = txml.replace(sdRe, () => `<sheetData>${out}</sheetData>`);

    // ابعاد اصلی قالب (و نواحی ادغام‌شده) را هم نگه دار؛ dimension فقط به دادهٔ خروجی محدود نشود.
    const originalDim = /<dimension\b[^>]*\bref="([^"]+)"[^>]*\/>/i.exec(txml);
    const dimBounds = originalDim && refBounds(originalDim[1]);
    if (dimBounds) { maxR = Math.max(maxR, dimBounds.r); maxC = Math.max(maxC, dimBounds.c); }
    const merges = mergeRefs(txml, result.merges);
    for (const ref of merges) { const b = refBounds(ref); if (b) { maxR = Math.max(maxR, b.r); maxC = Math.max(maxC, b.c); } }
    if (/<dimension\b[^>]*\/>/i.test(nx)) {
      nx = nx.replace(/<dimension\b[^>]*\/>/i, `<dimension ref="A1:${colName(maxC)}${maxR + 1}"/>`);
    }
    nx = putMergeCells(nx, merges);
    tz.file(tp, nx);

    // اگر داده از انتهای جدول قالب جلوتر رفت، بازهٔ جدول (و فیلتر آن) کشیده شود
    if (tr && maxDataRow + 1 > tr.r2 + 1) {
      const nr = tbls[0].ref.replace(/(\d+)$/, String(maxDataRow + 1));
      const tx = tbls[0].xml.split('"' + tbls[0].ref + '"').join('"' + nr + '"');
      tz.file(tbls[0].path, tx);
      notes.push(`بازهٔ جدول به ${nr} گسترش یافت.`);
    }
    try { await mergeLog(tz, files, notes, root.XLSX || (typeof XLSX !== 'undefined' ? XLSX : null)); }
    catch (e) { console.error(e); notes.push('ادغام شیت unplanned_log ناموفق بود: ' + e.message); }

    // محاسبه‌ی دوباره‌ی همه‌ی فرمول‌ها هنگام باز شدن + حذف calcChain قدیمی (وگرنه اکسل پیام «تعمیر» می‌دهد)
    let wbx = await tz.file('xl/workbook.xml').async('string');
    if (/<calcPr\b/.test(wbx)) wbx = wbx.replace(/<calcPr\b([^>]*?)(\/?)>/, (_, a, sl) => `<calcPr${a.replace(/\s+fullCalcOnLoad="[^"]*"/, '')} fullCalcOnLoad="1"${sl}>`);
    else {
      const tag = '<calcPr fullCalcOnLoad="1"/>', mm = /<(oleSize|customWorkbookViews|pivotCaches|webPublishing|fileRecoveryPr|extLst)\b/.exec(wbx);
      wbx = mm ? wbx.slice(0, mm.index) + tag + wbx.slice(mm.index) : wbx.replace('</workbook>', tag + '</workbook>');
    }
    tz.file('xl/workbook.xml', wbx);
    if (tz.file('xl/calcChain.xml')) {
      tz.remove('xl/calcChain.xml');
      const ct = await tz.file('[Content_Types].xml').async('string');
      tz.file('[Content_Types].xml', ct.replace(/<Override\b[^>]*calcChain[^>]*\/>/, ''));
      const rl = await tz.file('xl/_rels/workbook.xml.rels').async('string');
      tz.file('xl/_rels/workbook.xml.rels', rl.replace(/<Relationship\b[^>]*calcChain[^>]*\/>/, ''));
    }
    const data = await tz.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
    return { data, ext: /\.xlsm$/i.test(t.name) ? 'xlsm' : 'xlsx', notes };
  }

  const api = { build };
  if (typeof module !== 'undefined') module.exports = api; else root.ExportXlsx = api;
})(typeof window !== 'undefined' ? window : globalThis);
