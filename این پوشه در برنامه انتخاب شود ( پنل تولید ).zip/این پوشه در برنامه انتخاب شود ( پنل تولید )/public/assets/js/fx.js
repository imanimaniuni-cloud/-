(function(){
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,FINE=matchMedia('(pointer:fine)').matches;
const bg=document.createElement('div');bg.id='fx-bg';bg.innerHTML='<i class="blob b1"></i><i class="blob b2"></i><i class="blob b3"></i><i class="blob b4"></i><div class="floor"></div>';document.body.prepend(bg);
;const rs=()=>{};
let dot,ring;
addEventListener('mousemove',e=>{
  let t=e.target.closest&&e.target.closest('.card,.stat,.cat-tab');if(t&&t.closest('#v-reports'))t=null;
 document.querySelectorAll('.tilting').forEach(n=>{if(n!==t){n.classList.remove('tilting');n.style.setProperty('--rx','0deg');n.style.setProperty('--ry','0deg');n.style.setProperty('--go',0)}});
 if(t&&!RM){const r=t.getBoundingClientRect(),px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height,big=t.classList.contains('card')&&r.height>140,m=big?1.6:9;
  t.classList.add('tilting');t.style.setProperty('--ry',((px-.5)*-m*(document.dir==='rtl'?-1:1)*-1).toFixed(2)+'deg');t.style.setProperty('--rx',((py-.5)*m).toFixed(2)+'deg');
  t.style.setProperty('--mx',px*100+'%');t.style.setProperty('--my',py*100+'%');t.style.setProperty('--go',1)}
 const b=e.target.closest&&e.target.closest('.btn,.nav-pill');
 document.querySelectorAll('.mag').forEach(n=>{if(n!==b){n.classList.remove('mag');n.style.translate=''}});
 if(b&&!RM&&!b.disabled){const r=b.getBoundingClientRect();b.classList.add('mag');b.style.translate=((e.clientX-r.left-r.width/2)*.18)+'px '+((e.clientY-r.top-r.height/2)*.28)+'px'}});
// ریپل
document.addEventListener('click',e=>{const b=e.target.closest('.btn,.nav-pill,.chip,.catseg button');if(!b)return;
 const r=b.getBoundingClientRect(),s=Math.max(r.width,r.height),i=document.createElement('i');i.className='rip';
 i.style.cssText=`width:${s}px;height:${s}px;left:${e.clientX-r.left-s/2}px;top:${e.clientY-r.top-s/2}px`;
 if(getComputedStyle(b).position==='static')b.style.position='relative';b.style.overflow='hidden';b.appendChild(i);setTimeout(()=>i.remove(),650)});
// ورود تدریجی فقط یک بار هنگام باز شدن صفحه
document.querySelectorAll('.card:not(.login),.stat,.cat-tab').forEach((x,i)=>{x.style.setProperty('--i',i);x.classList.add('rv');setTimeout(()=>x.classList.remove('rv'),1400)});
})();
