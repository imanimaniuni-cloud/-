// گزارش‌های توقفات (بخش ۳):
//  ۱) کارت‌های خلاصه‌ی بالای صفحه (مقدار واقعی تولید، تولید در زمان در دسترس، مدت زمان در دسترس)
//  ۲) «گزارش تجهیز» هم‌شکل شیت «گزارش تجهیز» در فایل اکسل (به تفکیک محصول و به تفکیک تجهیز)
// همه‌ی عددها از همان ردیف‌های فیلترشده‌ی پنل (تاریخ، ماه، محصول، تجهیز، جستجو) می‌آیند.
(function(){
const E=s=>String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const faN=(n,d=0)=>Number(n).toLocaleString('fa-IR',{maximumFractionDigits:d});
const pct=(a,b,d=1)=>b>0?faN(a/b*100,d)+'٪':'—';
const num=v=>{const n=typeof v==='number'?v:parseFloat(String(v??'').replace(/[^\d.\-]/g,''));return isFinite(n)?n:0};
const find=(head,re)=>head.find(h=>re.test(h))||null;
const sumC=(rows,c)=>c?rows.reduce((s,r)=>s+num(r.o[c]),0):0;
const ZW=/[\u200e\u200f\u200c]/g;

// ستون‌های ردیف داده (نام‌ها از سرستون فایل اکسل حدس زده می‌شود)
function cols(head){return{
 kg:find(head,/^مقدار بسته ?بندی/),            // مقدار بسته‌بندی‌شده = تولید واقعی
 cap:find(head,/^ظرفیت تولید/),                // ظرفیت تولید بر مبنای زمان کارکرد (= «برنامه» در گزارش تجهیز اکسل)
 plan:find(head,/^برنامه تولید/),              // برنامه‌ی دریافتی
 lost:find(head,/^کیلوگرم از دست رفته\s*$/),   // کیلوگرم از دست رفته نسبت به ظرفیت کارکرد
 lostPlan:find(head,/^کیلوگرم از دست رفته طبق برنامه/),
 rpct:find(head,/^درصد تحقق برنامه/),           // «درصد تحقق برنامه دریافتی» هر ردیف (کسر؛ مثلاً ۰٫۸۵ = ۸۵٪)
 rate:find(head,/^نرخ تولید در دقیقه/),         // نرخ تولید ردیف (کیلوگرم در دقیقه)
 st:find(head,/^ساعت شروع/),en:find(head,/^ساعت پایان/),
 tmin:find(head,/^زمان توقفات مکرر\s*\(\s*خودکار/),
 stopPlan:find(head,/^زمان توقفات مکرر طبق برنامه/),
 ecode:find(head,/^کد تجهیز/)}}

// x = {n:عدد برای شمارش انیمیشنی, f:'n'|'hm'|'pct', d:اعشار, bar:۰..۱ نوار پیشرفت, ring:۰..۱ حلقه}
function card(cls,icon,label,val,sub,tip,text,x){
 x=x||{};
 const v=x.n!=null?`<span data-n="${x.n}" data-f="${x.f||'n'}" data-d="${x.d||0}">${val}</span>`:val;
 const lead=x.ring!=null
  ?`<span class="sring"><svg viewBox="0 0 56 56"><circle class="rt" cx="28" cy="28" r="23"/><circle class="rv2" cx="28" cy="28" r="23" data-ring="${Math.max(0,Math.min(1,x.ring))}"/></svg><em class="fa-solid ${icon}"></em></span>`
  :`<i class="fa-solid ${icon}"></i>`;
 const bar=x.bar!=null?`<span class="sbar"><b data-bar="${Math.max(0,Math.min(1,x.bar))}"></b></span>`:'';
 return`<div class="stat ${cls}"${tip?` title="${E(tip)}"`:''}>${lead}<div class="sb"><div class="sn${text?' sn-t':''}">${v}</div><div class="sl">${label}</div>${sub?`<div class="ssub">${sub}</div>`:''}${bar}</div></div>`}

// انیمیشن: شمارش عددها، پر شدن نوار و حلقه
function animate(body){
 const rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 const fmt=(el,v)=>{const f=el.dataset.f,d=+el.dataset.d||0;el.textContent=f==='hm'?hm(Math.round(v)):f==='pct'?faN(v,d)+'٪':faN(v,d)};
 body.querySelectorAll('[data-n]').forEach(el=>{const to=+el.dataset.n;if(rm||!isFinite(to)){fmt(el,to);return}
  const t0=performance.now(),D=1100;fmt(el,0);
  const step=t=>{const k=Math.min(1,(t-t0)/D),e=1-Math.pow(1-k,3);fmt(el,to*e);if(k<1)requestAnimationFrame(step);else fmt(el,to)};requestAnimationFrame(step)});
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  body.querySelectorAll('[data-bar]').forEach(b=>b.style.width=(+b.dataset.bar*100)+'%');
  body.querySelectorAll('[data-ring]').forEach(c=>{const C=2*Math.PI*23;c.style.strokeDasharray=C;c.style.strokeDashoffset=C*(1-(+c.dataset.ring))})}))}

function top(list,key){let b=null;for(const x of list)if(!b||x[key]>b[key])b=x;return b&&b[key]>0?b:null}

// ساعت (متن «7:00» یا کسر روز) → دقیقه‌ی روز
function tmin(v){if(typeof v==='number'&&v>=0&&v<=1.5)return Math.round(v*1440);
 const m=/^\s*(\d{1,2})\s*:\s*(\d{2})/.exec(String(v??'').replace(/[۰-۹]/g,d=>d.charCodeAt(0)-0x6F0));return m?(+m[1])*60+(+m[2]):null}
// کل زمان اعلامیِ ردیف (شروع تا پایان، بدون کم کردن توقفات؛ شیفت شب که پایانش کوچک‌تر است از نیمه‌شب رد می‌شود)
function span(r,c){const a=tmin(r.o[c.st]),b=tmin(r.o[c.en]);return a==null||b==null?0:(b-a+1440)%1440}
// توقفات هر ردیف (دقیقه) = تعویض فویل + تعویض PS + صرف وعده + نظافت دستگاه + مدت توقفات پیش‌بینی‌نشده
// (همان چیزی که اکسل از کل زمان اعلامی کم می‌کند تا «زمان کارکرد تجهیز» بماند)
const PLANCOL=[/^تعویض فویل/,/^تعویض PS/,/^صرف وعده/,/^نظافت دستگاه/];   // توقفات پیش‌بینی‌شده
const UNPLCOL=[/^مدت توقفات پیش/];                                          // توقفات پیش‌بینی‌نشده
const STOPCOL=PLANCOL.concat(UNPLCOL);
const mv=v=>typeof v==='string'&&v.includes(':')?(tmin(v)||0):num(v);
const hm=m=>faN(Math.floor(m/60))+' ساعت'+(m%60?' و '+faN(m%60)+' دقیقه':'');

// کارت‌های خلاصه: ۱) مقدار واقعی تولید  ۲) مقدار تولید (زمان در دسترس)  ۳) مدت زمان در دسترس  ۴) مقدار از دست رفته بابت توقفات  ۵) مقدار از دست رفته (پیش‌بینی‌شده / پیش‌بینی‌نشده) با کل مدت هر کدام  ۶) زمان از دست رفته بابت توقفات
function cardsRender(body,rows,ctx){
 const c=cols(ctx.head);
 if(!rows.length){body.innerHTML='';return}
 const kg=sumC(rows,c.kg);                       // مجموع ستون «مقدار بسته‌بندی‌شده» (ستون I اکسل)
 const sc=ctx.head.filter(h=>STOPCOL.some(re=>re.test(h)));
 const pc=ctx.head.filter(h=>PLANCOL.some(re=>re.test(h))),uc=ctx.head.filter(h=>UNPLCOL.some(re=>re.test(h)));
 let planMin=0,unplMin=0,planKg=0,unplKg=0;
 let availKg=0,availMin=0,noRate=0,stopMin=0,lostKg=0; // نرخ هر ردیف × کل زمان اعلامی همان ردیف؛ و نرخ × توقفات همان ردیف؛ جمع همه‌ی ردیف‌ها
 for(const r of rows){const d=span(r,c),sm=sc.reduce((t,h)=>t+mv(r.o[h]),0),rt=c.rate?r.o[c.rate]:null;availMin+=d;stopMin+=sm;
  const pm=pc.reduce((t,h)=>t+mv(r.o[h]),0),um=uc.reduce((t,h)=>t+mv(r.o[h]),0);planMin+=pm;unplMin+=um;
  if(typeof rt==='number'&&isFinite(rt)){availKg+=rt*d;lostKg+=rt*sm;planKg+=rt*pm;unplKg+=rt*um}else if(d>0)noRate++}
 const nr=noRate?' · '+faN(noRate)+' ردیف بدون نرخ':'';
 const share=v=>availKg>0?v/availKg:null;
 const ratio=availMin>0?stopMin/availMin:0;
 const cards=[
  card('st-b','fa-boxes-stacked','مقدار واقعی تولید (کیلوگرم)',faN(kg),faN(rows.length)+' ردیف','مجموع «مقدار بسته‌بندی‌شده» همه‌ی ردیف‌ها',0,{n:kg,bar:share(kg)}),
  card('st-g','fa-gauge-high','مقدار تولید (زمان در دسترس) — کیلوگرم',faN(availKg),'نرخ هر ردیف × کل زمان اعلامی'+nr,'برای هر ردیف: نرخ تولید در دقیقه × (ساعت پایان − ساعت شروع)؛ مجموع همه‌ی ردیف‌ها. توقفات کم نمی‌شود',0,{n:availKg}),
  card('st-p','fa-clock','مدت زمان در دسترس',hm(availMin),faN(availMin)+' دقیقه','مجموع کل زمان‌های اعلامی (ساعت شروع تا پایان) همه‌ی ردیف‌ها',1,{n:availMin,f:'hm'}),
  card('st-red','fa-triangle-exclamation','مقدار از دست رفته بابت توقفات (کیلوگرم)',faN(lostKg),(availKg>0?pct(lostKg,availKg)+' از تولید در زمان در دسترس':'')+nr,'برای هر ردیف: نرخ تولید در دقیقه × مجموع توقفات همان ردیف (تعویض فویل، تعویض PS، صرف وعده، نظافت، توقفات پیش‌بینی‌نشده)؛ مجموع همه‌ی ردیف‌ها',0,{n:lostKg,bar:share(lostKg)}),
  card('st-amb','fa-calendar-check','مقدار از دست رفته بابت توقفات پیش‌بینی‌شده (کیلوگرم)',faN(planKg),'<b>کل مدت توقفات پیش‌بینی‌شده: '+hm(planMin)+'</b> · '+faN(planMin)+' دقیقه'+(availKg>0?' · '+pct(planKg,availKg)+' از تولید در زمان در دسترس':''),'نرخ تولید در دقیقه × مجموع (تعویض فویل + تعویض PS + صرف وعده + نظافت دستگاه) هر ردیف؛ مجموع همه‌ی ردیف‌ها',0,{n:planKg,bar:share(planKg)}),
  card('st-ros','fa-calendar-xmark','مقدار از دست رفته بابت توقفات پیش‌بینی‌نشده (کیلوگرم)',faN(unplKg),'<b>کل مدت توقفات پیش‌بینی‌نشده: '+hm(unplMin)+'</b> · '+faN(unplMin)+' دقیقه'+(availKg>0?' · '+pct(unplKg,availKg)+' از تولید در زمان در دسترس':''),'نرخ تولید در دقیقه × «مدت توقفات پیش بینی نشده» هر ردیف؛ مجموع همه‌ی ردیف‌ها',0,{n:unplKg,bar:share(unplKg)}),
  card('st-ora','fa-hourglass-half','زمان از دست رفته بابت توقفات',hm(stopMin),pct(stopMin,availMin)+' از کل زمان در دسترس · '+faN(stopMin)+' دقیقه','مجموع توقفات همه‌ی ردیف‌ها ÷ مجموع کل زمان‌های اعلامی',1,{n:stopMin,f:'hm',bar:availMin>0?ratio:null}),
  card('st-vio','fa-gauge-simple-high','نسبت زمان از دست رفته به کل زمان در دسترس',availMin>0?faN(ratio*100,1)+'٪':'—',faN(stopMin)+' دقیقه توقف ÷ '+faN(availMin)+' دقیقه کل زمان (جمع همه‌ی ردیف‌ها)','مجموع توقفات (پیش‌بینی‌شده + پیش‌بینی‌نشده) ÷ مجموع کل زمان‌های اعلامی، برای همه‌ی ردیف‌های فیلترشده',0,availMin>0?{n:ratio*100,f:'pct',d:1,ring:ratio}:{ring:0})
 ];
 body.innerHTML='<div class="stats mb-0 stats-anim">'+cards.map((h,i)=>h.replace('<div class="stat ','<div style="--i:'+i+'" class="stat ')).join('')+'</div>';
 animate(body)}

// ---------- گزارش تجهیز (هم‌شکل شیت اکسل) ----------
function equipRender(body,rows,ctx){
 const c=cols(ctx.head),lc=ctx.logCols||{};
 if(!c.kg&&!ctx.log.length){body.innerHTML='<div class="text-muted">با فیلترهای فعلی داده‌ای پیدا نشد.</div>';return}
 const mk=()=>({kg:0,cap:0,lostMin:0,n:0,min:0,code:'',zx:0,zp:0,av:0,pk:0,uk:0,kr:0}),P=new Map(),Q=new Map();
 const pcs=ctx.head.filter(h=>PLANCOL.some(re=>re.test(h))),ucs=ctx.head.filter(h=>UNPLCOL.some(re=>re.test(h)));
 const get=(M,k)=>{k=k||'(نامشخص)';let x=M.get(k);if(!x)M.set(k,x=mk());return x};
 for(const r of rows){const p=get(P,r.p),q=get(Q,r.e),kg=c.kg?num(r.o[c.kg]):0,cap=c.cap?num(r.o[c.cap]):0,
   lm=(c.lost&&c.tmin&&num(r.o[c.lost])>0)?num(r.o[c.tmin]):0; // مثل اکسل: فقط ردیف‌هایی که کیلوگرم از دست رفته دارند
  // درصد تحقق: از ستون Z دیتابیس («درصد تحقق برنامه دریافتی») با وزن ستون X («برنامه تولید»)؛ ردیف بدون Z حساب نمی‌شود
  const zv=c.rpct?r.o[c.rpct]:null,xv=c.plan?r.o[c.plan]:null,zok=typeof zv==='number'&&isFinite(zv)&&typeof xv==='number'&&isFinite(xv)&&xv>0;
  // تفکیک پیش‌بینی‌شده / پیش‌بینی‌نشده: نرخ × زمان (مثل کارت‌های بالا)
  const rt=c.rate?r.o[c.rate]:null,dd=span(r,c),ok=typeof rt==='number'&&isFinite(rt)&&dd>0,
   pm=pcs.reduce((t,h)=>t+mv(r.o[h]),0),um=ucs.reduce((t,h)=>t+mv(r.o[h]),0);
  for(const x of[p,q]){x.kg+=kg;x.cap+=cap;x.lostMin+=lm;
   if(zok){x.zx+=zv*xv;x.zp+=xv}
   if(ok){x.av+=rt*dd;x.pk+=rt*pm;x.uk+=rt*um;x.kr+=kg}}
  if(c.ecode&&r.e&&!q.code){const cd=String(r.o[c.ecode]??'').replace(ZW,'').trim();if(cd)q.code=cd}}
 for(const r of ctx.log){const m=lc.min?num(r.o[lc.min]):0,p=get(P,r.p),q=get(Q,r.e);for(const x of[p,q]){x.n++;x.min+=m}}
 const live=M=>[...M].filter(([,x])=>x.kg||x.cap||x.n||x.min).sort((a,b)=>b[1].kg-a[1].kg||b[1].min-a[1].min);
 const tot=l=>l.reduce((t,[,x])=>{for(const k of['kg','cap','lostMin','n','min','zx','zp','av','pk','uk','kr'])t[k]+=x[k];return t},mk());
 const real=x=>x.zp>0?x.zx/x.zp:null,realP=x=>x.av-x.pk>0?x.kr/(x.av-x.pk):null,realU=x=>x.av-x.uk>0?x.kr/(x.av-x.uk):null,pf=v=>v==null?'—':faN(v*100,1)+'٪',rc=v=>v==null?'':v>=1?' style="color:#2fd46a"':v<.95?' style="color:#fbbf24"':'';
 const tr=(name,code,x,bold)=>{const v=real(x),vp=realP(x),vu=realU(x);return`<tr${bold?' class="fw-bold"':''}><td>${E(name)}</td>${code===undefined?'':`<td class="text-nowrap" dir="ltr" style="text-align:right">${E(code)}</td>`}<td>${faN(x.kg)}</td><td>${faN(x.cap)}</td><td${rc(v)}>${pf(v)}</td><td${rc(vp)}>${pf(vp)}</td><td${rc(vu)}>${pf(vu)}</td><td>${faN(x.lostMin,2)}</td><td>${faN(x.n)}</td><td>${faN(x.min,1)}</td></tr>`};
 const th=(first,withCode)=>'<tr><th>'+first+'</th>'+(withCode?'<th>کد تجهیز</th>':'')+'<th>تولید (کیلوگرم)</th><th>برنامه (کیلوگرم)</th><th title="از ستون Z دیتابیس: درصد تحقق برنامه دریافتی (میانگین وزنی با ستون X)">درصد تحقق</th><th title="تولید ÷ (زمان در دسترس − توقفات پیش‌بینی‌شده)، با نرخ هر ردیف">تحقق (پیش‌بینی‌شده)</th><th title="تولید ÷ (زمان در دسترس − توقفات پیش‌بینی‌نشده)، با نرخ هر ردیف">تحقق (پیش‌بینی‌نشده)</th><th>زمان از دست رفته (دقیقه)</th><th>تعداد توقف مکرر</th><th>مجموع توقف مکرر (دقیقه)</th></tr>';
 const table=(first,l,withCode)=>`<div class="table-responsive" style="max-height:380px;overflow:auto"><table class="table table-sm align-middle mb-0"><thead>${th(first,withCode)}</thead><tbody>${tr('جمع',withCode?'':undefined,tot(l),1)}${l.map(([k,x])=>tr(k,withCode?x.code:undefined,x)).join('')}</tbody></table></div>`;
 const lp=live(P),lq=live(Q);
 body.innerHTML=`<div class="fw-bold mb-2">۱) به تفکیک محصول <span class="small text-muted fw-normal">(${faN(lp.length)} محصول)</span></div>${table('محصول',lp,false)}
  <div class="fw-bold mt-4 mb-2">۲) به تفکیک تجهیز <span class="small text-muted fw-normal">(${faN(lq.length)} تجهیز)</span></div>${table('تجهیز',lq,true)}
  <div class="small text-muted mt-2">درصد تحقق = ستون Z دیتابیس (درصد تحقق برنامه دریافتی، میانگین وزنی با ستون X). تحقق پیش‌بینی‌شده/پیش‌بینی‌نشده = تولید ÷ (زمان در دسترس منهای فقط همان نوع توقف). · همان تعریف‌های شیت «گزارش تجهیز» اکسل: تولید = مقدار بسته‌بندی‌شده؛ برنامه = ظرفیت تولید بر مبنای زمان کارکرد؛ زمان از دست رفته = مجموع «زمان توقفات مکرر» ردیف‌هایی که کیلوگرم از دست رفته دارند؛ تعداد و مجموع توقف مکرر از لاگ توقفات پیش‌بینی‌نشده. محصول/تجهیزی که تولید و توقفی ندارد نمایش داده نمی‌شود.</div>`}

Reports.register({id:'stops-cards',cats:['stops'],first:true,bare:true,render:cardsRender});
Reports.register({id:'stops-equip',cats:['stops'],collapse:true,title:'گزارش تجهیز: تولید، برنامه و توقفات',icon:'fa-industry',render:equipRender});
})();
